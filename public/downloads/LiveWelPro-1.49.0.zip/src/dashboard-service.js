const OFFSCREEN_URL = chrome.runtime.getURL('offscreen/audio.html');
const LIVE_URLS = ['*://*.tiktok.com/*', '*://*.tiktokshop.com/*', '*://seller.tiktok.com/*', '*://*.seller.tiktokshop.com/*'];
const AUDIO_ENGINE_VERSION = '3.8.0';
const AUDIO_ENGINE_PORT = 'livewel-audio-offscreen-v3';
const AUDIO_DASHBOARD_PORT = 'livewel-dashboard-audio-rpc-v1';
let audioEngineInitialized = false;
let audioEnginePort = null;
let audioRequestSequence = 0;
let audioEnsurePromise = null;
const audioPending = new Map();
let audioShouldBePlaying = false;
let audioRecoveryTimer = 0;

async function liveTab() {
  const tabs = await chrome.tabs.query({ url: LIVE_URLS });
  return tabs.find((tab) => tab.active) || tabs.at(-1) || null;
}

async function persistAudioStatus(status = {}) {
  await chrome.storage.local.set({
    livewelAudioStatus: {
      playing: Boolean(status.playing),
      loaded: Number(status.loaded || 0),
      total: Number(status.total || 0),
      monitoring: status.monitoring === true,
      currentTrackName: String(status.currentTrackName || ''),
      updatedAt: Date.now()
    }
  });
}

function bindAudioEnginePort(port) {
  audioEnginePort = port;
  port.onMessage.addListener((message) => {
    if (message?.kind === 'status') {
      void persistAudioStatus(message.status);
      return;
    }
    if (message?.kind !== 'response' || !message.requestId) return;
    const pending = audioPending.get(message.requestId);
    if (!pending) return;
    audioPending.delete(message.requestId);
    clearTimeout(pending.timer);
    pending.resolve(message.result);
  });
  port.onDisconnect.addListener(() => {
    if (audioEnginePort !== port) return;
    audioEnginePort = null;
    audioEngineInitialized = false;
    scheduleAudioEngineRecovery();
    for (const [requestId, pending] of audioPending) {
      audioPending.delete(requestId);
      clearTimeout(pending.timer);
      pending.reject(new Error('O motor de áudio foi reiniciado. Tente novamente.'));
    }
  });
}

async function waitForAudioEnginePort(timeoutMs = 2500) {
  const deadline = Date.now() + timeoutMs;
  while (!audioEnginePort && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 50));
  if (!audioEnginePort) throw new Error('O motor de áudio não abriu o canal privado.');
  return audioEnginePort;
}

async function sendAudioEngine(payload, timeoutMs = 7000) {
  const port = await waitForAudioEnginePort();
  const requestId = `audio_${Date.now().toString(36)}_${++audioRequestSequence}`;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      audioPending.delete(requestId);
      reject(new Error('O motor de áudio demorou para responder.'));
    }, timeoutMs);
    audioPending.set(requestId, { resolve, reject, timer });
    try {
      port.postMessage({ kind: 'command', requestId, payload });
    } catch (error) {
      audioPending.delete(requestId);
      clearTimeout(timer);
      reject(error);
    }
  });
}

async function createOrValidateAudioOffscreen() {
  const contexts = await chrome.runtime.getContexts?.({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [OFFSCREEN_URL] });
  if (contexts?.length) {
    if (audioEngineInitialized && audioEnginePort) return;
    const status = await waitForAudioEnginePort(700).then(() => sendAudioEngine({ type: 'OFFSCREEN_AUDIO_STATUS' })).catch(() => null);
    if (status?.engineVersion === AUDIO_ENGINE_VERSION) {
      audioEngineInitialized = true;
      return;
    }
    await chrome.offscreen.closeDocument().catch(() => {});
    audioEnginePort = null;
    audioEngineInitialized = false;
  }
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen/audio.html', reasons: ['AUDIO_PLAYBACK', 'BLOBS'],
      justification: 'Reprodução contínua e processamento de arquivos Blob para o microfone virtual.'
    });
  } catch (error) {
    if (!/already exists|single offscreen/i.test(String(error))) throw error;
  }
  await waitForAudioEnginePort(3500);
  const status = await sendAudioEngine({ type: 'OFFSCREEN_AUDIO_STATUS' });
  if (status?.engineVersion !== AUDIO_ENGINE_VERSION) throw new Error('A versão do motor de áudio não foi atualizada. Recarregue a extensão.');
  audioEngineInitialized = true;
}

async function ensureAudioOffscreen() {
  if (audioEngineInitialized && audioEnginePort) return;
  if (!audioEnsurePromise) {
    audioEnsurePromise = createOrValidateAudioOffscreen().finally(() => { audioEnsurePromise = null; });
  }
  return audioEnsurePromise;
}

function scheduleAudioEngineRecovery(delayMs = 400) {
  if (!audioShouldBePlaying) return;
  clearTimeout(audioRecoveryTimer);
  audioRecoveryTimer = setTimeout(() => {
    audioRecoveryTimer = 0;
    recoverContinuousAudio().catch(() => scheduleAudioEngineRecovery(1200));
  }, delayMs);
}

async function recoverContinuousAudio() {
  if (!audioShouldBePlaying) return;
  await ensureAudioOffscreen();
  if (!audioShouldBePlaying) return;
  const stored = await chrome.storage.local.get(null);
  const library = Array.isArray(stored.audioLibrary) ? stored.audioLibrary : [];
  await sendAudioEngine({ type: 'OFFSCREEN_AUDIO_LOAD', library }, 45000);
  await sendAudioEngine(storedAudioConfig(stored));
  if (!audioShouldBePlaying) return;
  await sendAudioEngine({ type: 'OFFSCREEN_AUDIO_PLAY' });
}

function storedAudioConfig(stored) {
  const audioLibrary = Array.isArray(stored.audioLibrary) ? stored.audioLibrary : [];
  const singleLongTrack = audioLibrary.length === 1 && (
    audioLibrary[0]?.streaming === true
    || Number(audioLibrary[0]?.duration || 0) >= 5 * 60
    || Number(audioLibrary[0]?.size || 0) >= 8 * 1024 * 1024
  );
  return {
    type: 'OFFSCREEN_AUDIO_CONFIG',
    minSec: Number(stored.audioSegmentMinSec ?? 4),
    maxSec: Number(stored.audioSegmentMaxSec ?? 12),
    gapSec: Number(stored.audioGapSec ?? 1),
    volume: Number(stored.audioVolume ?? .9),
    playMode: !singleLongTrack && stored.audioPlayMode === 'segments' ? 'segments' : 'full',
    voiceSpeed: Number(stored.audioVoiceSpeed ?? 1),
    voiceTone: Number(stored.audioVoiceTone ?? 0),
    ambientEnabled: stored.audioAmbientEnabled !== false,
    ambientLevel: Number(stored.audioAmbientLevel ?? 10),
    monitorEnabled: stored.audioMonitorEnabled === true
  };
}

async function audioCommand(command, overrideConfig = {}) {
  const normalizedCommand = String(command || 'STATUS').toUpperCase();
  if (normalizedCommand === 'PLAY' || normalizedCommand === 'START') audioShouldBePlaying = true;
  if (normalizedCommand === 'PAUSE' || normalizedCommand === 'STOP' || normalizedCommand === 'KILL') {
    audioShouldBePlaying = false;
    clearTimeout(audioRecoveryTimer);
    audioRecoveryTimer = 0;
  }
  await ensureAudioOffscreen();
  const stored = { ...(await chrome.storage.local.get(null)), ...(overrideConfig || {}) };
  const library = Array.isArray(stored.audioLibrary) ? stored.audioLibrary : [];
  if (normalizedCommand === 'PLAY' || normalizedCommand === 'START') {
    await sendAudioEngine({ type: 'OFFSCREEN_AUDIO_LOAD', library }, 45000);
    await sendAudioEngine(storedAudioConfig(stored));
  } else if (normalizedCommand === 'CONFIG') {
    return sendAudioEngine(storedAudioConfig(stored));
  } else if (normalizedCommand === 'RELOAD' || normalizedCommand === 'LIBRARY') {
    return sendAudioEngine({ type: 'OFFSCREEN_AUDIO_LOAD', library }, 45000);
  }
  return sendAudioEngine({ type: `OFFSCREEN_AUDIO_${normalizedCommand}` });
}

globalThis.LiveWelAudioService = { command: audioCommand, ensure: ensureAudioOffscreen };

chrome.action.setPopup({ popup: '' }).catch(() => {});
chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(() => chrome.action.setPopup({ popup: '' }).catch(() => {}));
chrome.runtime.onInstalled.addListener(() => chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {}));
chrome.runtime.onStartup.addListener(() => {
  chrome.action.setPopup({ popup: '' }).catch(() => {});
  chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.storage.onChanged.addListener(() => queueMicrotask(() => chrome.action.setPopup({ popup: '' }).catch(() => {})));
setInterval(() => chrome.action.setPopup({ popup: '' }).catch(() => {}), 750);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'OFFSCREEN_AUDIO_STATUS' && message?.source === 'livewel-offscreen') {
    void persistAudioStatus(message);
    return;
  }
  if (message?.type === 'LIVEWEL_OPEN_DASHBOARD') {
    chrome.windows.getCurrent().then((window) => chrome.sidePanel.open({ windowId: window.id })).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type === 'LIVEWEL_DASH_COMMAND') {
    liveTab()
      .then((tab) => tab?.id ? chrome.tabs.sendMessage(tab.id, message) : Promise.reject(new Error('Abra o TikTok Shop LIVE no navegador.')))
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
  if (message?.type === 'LIVEWEL_DASH_AUDIO') {
    audioCommand(message.command, message.config).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === AUDIO_ENGINE_PORT) {
    bindAudioEnginePort(port);
    return;
  }
  if (port.name !== AUDIO_DASHBOARD_PORT) return;
  port.onMessage.addListener((message) => {
    if (!message?.requestId) return;
    audioCommand(message.command, message.config)
      .then((result) => port.postMessage({ requestId: message.requestId, ...(result || { ok: true }) }))
      .catch((error) => port.postMessage({ requestId: message.requestId, ok: false, error: String(error?.message || error) }));
  });
});
