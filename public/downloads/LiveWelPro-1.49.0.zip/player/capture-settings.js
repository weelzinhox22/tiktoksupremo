const STORAGE_KEY = 'liveosCommandCenterV1';
const VIDEO_PIPELINE_VERSION = 3;
const defaults = { videoFrameMode: 'fit', captureProfile: 'performance', safeScale: 1, outputFps: 30 };

const frameMode = document.getElementById('captureFrameMode');
const profile = document.getElementById('captureProfile');
const fill = document.getElementById('fillStage');
const safeScale = document.getElementById('captureSafeScale');
const safeScaleValue = document.getElementById('captureSafeScaleValue');
const outputFps = document.getElementById('captureOutputFps');

function normalized(settings = {}) {
  return {
    videoFrameMode: settings.videoFrameMode === 'crop' ? 'crop' : 'fit',
    captureProfile: ['quality', 'smooth'].includes(settings.captureProfile)
      ? settings.captureProfile : 'performance',
    safeScale: Math.max(0.5, Math.min(1.5, Number(settings.safeScale) || 1)),
    outputFps: Number(settings.outputFps) === 60 ? 60 : 30
  };
}

function apply(settings, resizeWindow = false) {
  const value = normalized(settings);
  document.body.dataset.captureFrame = value.videoFrameMode;
  if (frameMode) frameMode.value = value.videoFrameMode;
  if (profile) profile.value = value.captureProfile;
  if (safeScale) safeScale.value = String(value.safeScale);
  if (safeScaleValue) safeScaleValue.textContent = `${Math.round(value.safeScale * 100)}%`;
  if (outputFps) outputFps.value = String(value.outputFps);
  if (fill) {
    fill.checked = value.videoFrameMode === 'crop';
    fill.dispatchEvent(new Event('change', { bubbles: true }));
  }
  document.querySelectorAll('.feed-video').forEach((video) => {
    video.style.setProperty('object-fit', value.videoFrameMode === 'crop' ? 'cover' : 'contain', 'important');
    video.style.setProperty('object-position', 'center', 'important');
    video.style.setProperty('transform', `scale(${value.safeScale})`, 'important');
  });
  document.querySelector('.video-stack')?.style.setProperty('animation', 'none', 'important');

  if (resizeWindow && document.body.classList.contains('capture-mode')) {
    const innerHeight = value.captureProfile === 'quality' ? 960 : 800;
    const innerWidth = Math.round(innerHeight * 9 / 16);
    const chromeWidth = Math.max(0, window.outerWidth - window.innerWidth);
    const chromeHeight = Math.max(0, window.outerHeight - window.innerHeight);
    window.resizeTo(innerWidth + chromeWidth, innerHeight + chromeHeight);
  }
}

async function read() {
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    const saved = stored[STORAGE_KEY]?.settings || {};
    const migrated = Number(saved.videoPipelineVersion) >= VIDEO_PIPELINE_VERSION
      ? { ...defaults, ...saved }
      : {
          ...defaults,
          videoFrameMode: saved.videoFrameMode,
          safeScale: saved.safeScale
        };
    return normalized(migrated);
  } catch { return defaults; }
}

async function save() {
  const stored = await chrome.storage.local.get(STORAGE_KEY).catch(() => ({}));
  const root = stored[STORAGE_KEY] || { version: 1 };
  root.settings = {
    ...(root.settings || {}),
    videoFrameMode: frameMode?.value === 'crop' ? 'crop' : 'fit',
    captureProfile: ['quality', 'smooth'].includes(profile?.value)
      ? profile.value : 'performance',
    safeScale: Math.max(0.5, Math.min(1.5, Number(safeScale?.value) || 1)),
    outputFps: Number(outputFps?.value) === 60 ? 60 : 30,
    videoPipelineVersion: VIDEO_PIPELINE_VERSION
  };
  await chrome.storage.local.set({ [STORAGE_KEY]: root }).catch(() => {});
  apply(root.settings, true);
}

frameMode?.addEventListener('change', save);
profile?.addEventListener('change', save);
safeScale?.addEventListener('change', save);
safeScale?.addEventListener('input', () => {
  if (safeScaleValue) safeScaleValue.textContent = `${Math.round(Number(safeScale.value) * 100)}%`;
  apply({ captureProfile: profile?.value, videoFrameMode: frameMode?.value, safeScale: safeScale.value, outputFps: outputFps?.value });
});
outputFps?.addEventListener('change', save);

const observer = new MutationObserver(() => void read().then((settings) => apply(settings, true)));
observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
apply(await read());
