import { idbPutBlob, idbGetBlob, idbDeleteBlob } from '../src/shared/idb.js';

const $ = (id) => document.getElementById(id);
const canvas = $('output');
const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
const connection = $('connection');
const players = [$('videoA'), $('videoB')];
const urls = new Map();
const mediaLayerSources = new Map();
const STORE_KEY = 'livewelStudioV2';
const TRANSITION_ENGINE_VERSION = 2;
const PRELOAD_LEAD_SECONDS = 4;
const TRANSITION_START_MARGIN_SECONDS = .12;

const defaultOverlays = () => [
  { id: 'live', type: 'badge', name: 'Indicador ao vivo', text: 'AO VIVO', x: .13, y: .07, size: 22, color: '#ffffff', bg: '#ef3340', enabled: true },
  { id: 'viewers', type: 'viewers', name: 'Espectadores', text: '2,2 mil assistindo', x: .18, y: .12, size: 17, color: '#ffffff', bg: '#111827cc', enabled: true },
  { id: 'benefits', type: 'banner', name: 'Benefícios', text: 'Garantia|Pronta entrega|Envio rápido', x: .5, y: .76, size: 20, color: '#111827', bg: '#ffffffee', interval: 3, enabled: true },
  { id: 'timer', type: 'timer', name: 'Cronômetro da oferta', text: 'OFERTA RELÂMPAGO ENCERRA EM', x: .5, y: .88, size: 22, color: '#ffffff', bg: '#dc2637ee', duration: 299, enabled: true }
];

const defaults = {
  videos: [], mediaLayers: [], ghost: null, currentId: null, shuffle: true, fit: 'contain', transition: 'fade', fadeMs: 500, transitionEngineVersion: TRANSITION_ENGINE_VERSION,
  ghostOpacity: 12, ghostBlend: 'screen', scanEnabled: false, scanModel: 'classic', scanColor: '#ffffff', scanOpacity: 10, scanThickness: 70, scanSpeed: 8, scanDirection: 'down', scanBlend: 'screen',
  emojiEnabled: false, emojiSet: '❤️ 👍 ✨', overlays: defaultOverlays()
};
let state = structuredClone(defaults);
let activePlayer = 0;
let previousPlayer = null;
let fadeStartedAt = 0;
let playing = false;
let bag = [];
let lastId = null;
let frameBusy = false;
let lastFrameSent = 0;
let timerStartedAt = performance.now();
let particles = [];
let lastParticleAt = 0;
let queuedTake = null;
let preparingTake = null;
let takeSwitchPromise = null;
let playbackRevision = 0;
let fadePausedAt = 0;
let playbackRecoveryTimer = 0;
let selectedMediaLayerId = null;
let lastRelayStatusAt = 0;
let fallbackRequestSequence = 0;
let rtcPort = null;
let rtcReconnectTimer = 0;
let rtcOutputStream = null;
const rtcPeers = new Map();
const rtcConnectedReceivers = new Set();
const OUTPUT_FPS = 30;
const FRAME_INTERVAL_MS = 1000 / OUTPUT_FPS;
let lastRenderedAt = 0;

function setConnectionState(mode, text) {
  connection.classList.toggle('warning', mode === 'warning');
  connection.classList.toggle('error', mode === 'error');
  connection.classList.toggle('online', mode === 'online');
  connection.lastChild.textContent = ` ${text}`;
}

function handleRelayResult(response) {
  if (performance.now() - lastRelayStatusAt < 700) return;
  lastRelayStatusAt = performance.now();
  if (rtcConnectedReceivers.size) setConnectionState('online', 'Vídeo fluido conectado · WebRTC 30 FPS');
  else if (response?.ok) setConnectionState('online', 'Vídeo conectado ao TikTok · modo compatível');
  else {
    const error = String(response?.error || 'Aguardando a página da LIVE');
    setConnectionState('warning', /unknown_message/i.test(error) ? 'Reconectando o canal de vídeo…' : error);
  }
}

function reportPlayerStatus(online = true) {
  const meta = state.videos.find((video) => video.id === state.currentId);
  const message = {
    type: 'player-status',
    online,
    playing,
    take: meta?.name || '',
    transport: rtcConnectedReceivers.size ? 'webrtc' : 'frames'
  };
  if (rtcPortMessage(message)) return;
  chrome.runtime.sendMessage({ ...message, type: 'LIVEWEL_PLAYER_STATUS' }).catch(() => {});
}

function rtcPortMessage(message) {
  if (!rtcPort) return false;
  try {
    rtcPort.postMessage(message);
    return true;
  } catch {
    return false;
  }
}

function closeRtcPeer(receiverId) {
  const entry = rtcPeers.get(receiverId);
  if (entry) {
    try { entry.peer.close(); } catch {}
    rtcPeers.delete(receiverId);
  }
  rtcConnectedReceivers.delete(receiverId);
}

function closeAllRtcPeers() {
  for (const receiverId of [...rtcPeers.keys()]) closeRtcPeer(receiverId);
}

function ensureRtcOutputStream() {
  if (rtcOutputStream?.getVideoTracks().some((track) => track.readyState === 'live')) return rtcOutputStream;
  rtcOutputStream = canvas.captureStream(30);
  const track = rtcOutputStream.getVideoTracks()[0];
  if (track) {
    try { track.contentHint = 'motion'; } catch {}
  }
  return rtcOutputStream;
}

function preferRealtimeCodec(transceiver) {
  try {
    const codecs = RTCRtpSender.getCapabilities('video')?.codecs || [];
    const preferred = [
      ...codecs.filter((codec) => /video\/h264/i.test(codec.mimeType)),
      ...codecs.filter((codec) => /video\/vp9/i.test(codec.mimeType)),
      ...codecs.filter((codec) => /video\/vp8/i.test(codec.mimeType)),
      ...codecs.filter((codec) => !/video\/(h264|vp9|vp8)/i.test(codec.mimeType))
    ];
    transceiver?.setCodecPreferences?.(preferred);
  } catch {}
}

async function startRtcPeer(receiverId) {
  if (!receiverId || typeof RTCPeerConnection === 'undefined') return;
  closeRtcPeer(receiverId);
  const peer = new RTCPeerConnection({ iceServers: [] });
  const entry = { peer, pendingCandidates: [] };
  rtcPeers.set(receiverId, entry);
  const stream = ensureRtcOutputStream();
  const track = stream.getVideoTracks()[0];
  if (!track) return closeRtcPeer(receiverId);
  const sender = peer.addTrack(track, stream);
  const transceiver = peer.getTransceivers().find((item) => item.sender === sender);
  preferRealtimeCodec(transceiver);
  try {
    const parameters = sender.getParameters();
    if (parameters.encodings?.[0]) {
      parameters.encodings[0].maxBitrate = canvas.width * canvas.height >= 1_500_000
        ? 5_000_000
        : 3_500_000;
      parameters.encodings[0].maxFramerate = OUTPUT_FPS;
      parameters.encodings[0].scaleResolutionDownBy = 1;
    }
    parameters.degradationPreference = 'maintain-framerate';
    await sender.setParameters(parameters);
  } catch {}
  peer.onicecandidate = (event) => {
    if (event.candidate) {
      rtcPortMessage({
        type: 'signal',
        receiverId,
        signal: { candidate: event.candidate.toJSON() }
      });
    }
  };
  peer.onconnectionstatechange = () => {
    if (rtcPeers.get(receiverId)?.peer !== peer) return;
    if (peer.connectionState === 'connected') {
      rtcConnectedReceivers.add(receiverId);
      if (playing) setConnectionState('online', 'Vídeo fluido conectado · WebRTC 30 FPS');
      reportPlayerStatus();
    } else if (peer.connectionState === 'failed' || peer.connectionState === 'closed') {
      closeRtcPeer(receiverId);
    } else if (peer.connectionState === 'disconnected') {
      rtcConnectedReceivers.delete(receiverId);
    }
  };
  const offer = await peer.createOffer();
  await peer.setLocalDescription(offer);
  rtcPortMessage({
    type: 'signal',
    receiverId,
    signal: { description: { type: peer.localDescription.type, sdp: peer.localDescription.sdp } }
  });
}

async function handleRtcSignal(receiverId, signal) {
  const entry = rtcPeers.get(receiverId);
  if (!entry || !signal) return;
  if (signal.description?.type === 'answer') {
    await entry.peer.setRemoteDescription(signal.description);
    for (const candidate of entry.pendingCandidates.splice(0)) {
      await entry.peer.addIceCandidate(candidate).catch(() => {});
    }
    return;
  }
  if (signal.candidate) {
    if (entry.peer.remoteDescription) await entry.peer.addIceCandidate(signal.candidate).catch(() => {});
    else entry.pendingCandidates.push(signal.candidate);
  }
}

function connectRtcTransport() {
  if (typeof RTCPeerConnection === 'undefined' || rtcPort) return;
  clearTimeout(rtcReconnectTimer);
  try {
    const port = chrome.runtime.connect({ name: 'LIVEWEL_PLAYER_RTC' });
    rtcPort = port;
    port.onMessage.addListener((message) => {
      if (message?.type === 'fallback-frame-result') {
        handleRelayResult(message);
        return;
      }
      const receiverId = String(message?.receiverId || '');
      if (message?.type === 'receiver-ready') startRtcPeer(receiverId).catch(() => closeRtcPeer(receiverId));
      if (message?.type === 'signal') handleRtcSignal(receiverId, message.signal).catch(() => closeRtcPeer(receiverId));
      if (message?.type === 'receiver-closed') closeRtcPeer(receiverId);
      if (message?.type === 'receiver-status' && message.status === 'connected') {
        rtcConnectedReceivers.add(receiverId);
        if (playing) setConnectionState('online', 'Vídeo fluido conectado · WebRTC 30 FPS');
      }
    });
    port.onDisconnect.addListener(() => {
      if (rtcPort === port) rtcPort = null;
      closeAllRtcPeers();
      rtcReconnectTimer = setTimeout(connectRtcTransport, 1000);
    });
  } catch {
    rtcPort = null;
    rtcReconnectTimer = setTimeout(connectRtcTransport, 1500);
  }
}

function save() {
  chrome.storage.local.set({ [STORE_KEY]: state });
}

async function restore() {
  const stored = await chrome.storage.local.get(STORE_KEY);
  const persisted = stored[STORE_KEY] || {};
  state = { ...structuredClone(defaults), ...persisted };
  if (Number(persisted.transitionEngineVersion) < TRANSITION_ENGINE_VERSION) {
    state.transition = 'fade';
    state.transitionEngineVersion = TRANSITION_ENGINE_VERSION;
    save();
  }
  state.transition = state.transition === 'cut' ? 'cut' : 'fade';
  state.fadeMs = Math.max(100, Math.min(1500, Number(state.fadeMs) || defaults.fadeMs));
  state.overlays = Array.isArray(state.overlays) ? state.overlays : defaultOverlays();
  state.mediaLayers = Array.isArray(state.mediaLayers) ? state.mediaLayers.map(normalizeMediaLayer) : [];
  if (state.ghost?.id && !state.mediaLayers.some((item) => item.id === state.ghost.id)) {
    state.mediaLayers.push(normalizeMediaLayer({
      ...state.ghost,
      type: 'video',
      x: .5,
      y: .5,
      size: 100,
      opacity: Number(state.ghostOpacity) || 12,
      blend: state.ghostBlend || 'screen',
      enabled: true,
      loop: true
    }));
    state.ghost = null;
    save();
  }
  applyControls();
  renderVideoList();
  renderOverlayEditor();
  renderMediaLayerEditor();
  renderDragLayer();
  await Promise.all(state.mediaLayers.map((item) => loadMediaLayer(item).catch((error) => {
    console.warn('[LiveWelPro] camada não carregada:', item.name, error);
  })));
  if (state.currentId && state.videos.some((v) => v.id === state.currentId)) await selectVideo(state.currentId, false);
  updateTransport();
}

function applyControls() {
  for (const id of ['shuffle','scanEnabled','emojiEnabled']) $(id).checked = Boolean(state[id]);
  for (const id of ['fit','transition','emojiSet','scanModel','scanColor','scanDirection','scanBlend']) $(id).value = state[id];
  for (const id of ['fadeMs','scanOpacity','scanThickness','scanSpeed']) $(id).value = state[id];
  $('fadeValue').value = `${state.fadeMs} ms`;
  $('scanOpacityValue').value = `${state.scanOpacity}%`;
  $('scanThicknessValue').value = `${state.scanThickness} px`;
  $('scanSpeedValue').value = `${state.scanSpeed} s`;
}

function escapeHtml(value) {
  return String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}

function mediaId(prefix = 'vid') {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomUUID().slice(0, 8)}`;
}

async function objectUrl(id) {
  if (urls.has(id)) return urls.get(id);
  const stored = await idbGetBlob(id);
  if (!stored?.blob) throw new Error('Arquivo não encontrado na biblioteca local.');
  const url = URL.createObjectURL(stored.blob);
  urls.set(id, url);
  return url;
}

function waitForVideoReady(video, minimumReadyState = 3, timeoutMs = 12000) {
  if (video.readyState >= minimumReadyState) return Promise.resolve();
  return new Promise((resolve, reject) => {
    let timer = 0;
    const cleanup = () => {
      clearTimeout(timer);
      video.removeEventListener('loadeddata', onReady);
      video.removeEventListener('canplay', onReady);
      video.removeEventListener('error', onError);
    };
    const onReady = () => {
      if (video.readyState < minimumReadyState) return;
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error('Formato ou codec de vídeo não suportado pelo Chrome.'));
    };
    timer = setTimeout(() => {
      cleanup();
      reject(new Error('O vídeo demorou demais para ficar pronto.'));
    }, timeoutMs);
    video.addEventListener('loadeddata', onReady);
    video.addEventListener('canplay', onReady);
    video.addEventListener('error', onError);
  });
}

async function loadTake(video, id, timeoutMs = 12000) {
  const url = await objectUrl(id);
  video.pause();
  video.src = url;
  video.currentTime = 0;
  const ready = waitForVideoReady(video, 3, timeoutMs);
  video.load();
  await ready;
}

function waitForFirstVideoFrame(video, timeoutMs = 750) {
  if (typeof video.requestVideoFrameCallback !== 'function') {
    return new Promise((resolve) => setTimeout(resolve, 80));
  }
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve();
    }, timeoutMs);
    video.requestVideoFrameCallback(() => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve();
    });
  });
}

async function startTakePlayback(video) {
  await video.play();
  if (video.paused) throw new Error('O Chrome não iniciou a reprodução do próximo vídeo.');
  await waitForFirstVideoFrame(video);
  if (video.paused) throw new Error('O próximo vídeo pausou antes do primeiro quadro.');
}

function fadeDurationMs() {
  return Math.max(100, Math.min(1500, Number(state.fadeMs) || defaults.fadeMs));
}

function finishFade(prepareFollowingTake = true) {
  if (previousPlayer === null) return;
  const previous = players[previousPlayer];
  if (previous !== players[activePlayer]) previous.pause();
  previousPlayer = null;
  fadePausedAt = 0;
  if (prepareFollowingTake && playing) void prepareNextTake();
}

function schedulePlaybackRecovery(video) {
  if (playbackRecoveryTimer || !playing || video !== players[activePlayer] || video.ended) return;
  playbackRecoveryTimer = setTimeout(async () => {
    playbackRecoveryTimer = 0;
    if (!playing || video !== players[activePlayer] || !video.paused || video.ended) return;
    try {
      await video.play();
    } catch (error) {
      console.warn('[LiveWelPro] retomando vídeo que pausou inesperadamente', error);
      setConnectionState('warning', 'Retomando o vídeo automaticamente…');
      schedulePlaybackRecovery(video);
    }
  }, 120);
}

async function importVideos(files) {
  for (const file of files) {
    const id = mediaId();
    await idbPutBlob(id, file, { fileName: file.name, type: file.type });
    state.videos.push({ id, name: file.name, size: file.size });
  }
  bag = [];
  save();
  renderVideoList();
  if (!state.currentId && state.videos[0]) await selectVideo(state.videos[0].id, false);
}

function pickNext(direction = 1) {
  if (!state.videos.length) return null;
  if (!state.shuffle) {
    const current = Math.max(0, state.videos.findIndex((v) => v.id === state.currentId));
    return state.videos[(current + direction + state.videos.length) % state.videos.length].id;
  }
  if (!bag.length) {
    bag = state.videos.map((v) => v.id);
    for (let i = bag.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [bag[i], bag[j]] = [bag[j], bag[i]];
    }
    if (bag.length > 1 && bag[bag.length - 1] === lastId) [bag[0], bag[bag.length - 1]] = [bag[bag.length - 1], bag[0]];
  }
  const candidate = bag.pop();
  if (state.videos.length > 1 && candidate === state.currentId) {
    if (!bag.length) return pickNext(direction);
    const alternative = bag.pop();
    bag.unshift(candidate);
    return alternative;
  }
  return candidate;
}

async function selectVideo(id, autoplay = playing) {
  const meta = state.videos.find((v) => v.id === id);
  if (!meta) return;
  if (takeSwitchPromise) await takeSwitchPromise;
  finishFade(false);
  const revision = ++playbackRevision;
  queuedTake = null;
  const nextIndex = activePlayer === 0 ? 1 : 0;
  const nextPlayer = players[nextIndex];
  await loadTake(nextPlayer, id);
  if (revision !== playbackRevision) return;
  if (autoplay && playing) await startTakePlayback(nextPlayer);
  if (revision !== playbackRevision) {
    nextPlayer.pause();
    return;
  }
  if (!autoplay || !playing) nextPlayer.pause();
  const oldIndex = activePlayer;
  const canFade = state.transition === 'fade' && autoplay && playing && players[oldIndex].readyState >= 2;
  previousPlayer = canFade ? oldIndex : null;
  fadeStartedAt = performance.now();
  fadePausedAt = 0;
  activePlayer = nextIndex;
  state.currentId = id;
  lastId = id;
  if (!canFade) players[oldIndex].pause();
  save();
  renderVideoList();
  updateTransport();
  reportPlayerStatus();
  if (playing && !canFade) void prepareNextTake();
}

async function next(direction = 1) {
  if (takeSwitchPromise) return takeSwitchPromise;
  if (previousPlayer !== null) finishFade(false);
  if (direction === 1 && queuedTake) return commitQueuedTake();
  const id = pickNext(direction);
  if (id) await selectVideo(id, playing);
}

function prepareNextTake() {
  if (queuedTake) return Promise.resolve(queuedTake);
  if (preparingTake) return preparingTake;
  if (!playing || takeSwitchPromise || previousPlayer !== null || !state.videos.length) return Promise.resolve(null);
  const revision = playbackRevision;
  const currentId = state.currentId;
  const index = activePlayer === 0 ? 1 : 0;
  const task = (async () => {
    try {
      const id = pickNext(1);
      const meta = state.videos.find((video) => video.id === id);
      if (!id || !meta) return null;
      if (state.videos.length > 1 && id === currentId) return null;
      const video = players[index];
      await loadTake(video, id);
      if (revision !== playbackRevision || index === activePlayer || previousPlayer !== null) return null;
      queuedTake = { id, meta, index, revision };
      return queuedTake;
    } catch (error) {
      console.warn('[LiveWelPro] não foi possível pré-carregar o próximo take', error);
      return null;
    }
  })();
  preparingTake = task;
  task.finally(() => {
    if (preparingTake === task) preparingTake = null;
  });
  return task;
}

function commitQueuedTake() {
  if (takeSwitchPromise) return takeSwitchPromise;
  const queued = queuedTake;
  queuedTake = null;
  if (!queued) return Promise.resolve(false);
  const task = (async () => {
    const oldIndex = activePlayer;
    const oldPlayer = players[oldIndex];
    const video = players[queued.index];
    ++playbackRevision;
    try {
      if (!playing || queued.index === oldIndex || !state.videos.some((item) => item.id === queued.id)) return false;
      if (video.readyState < 3) await waitForVideoReady(video, 3, 4000);
      video.currentTime = 0;
      await startTakePlayback(video);
      if (!playing) {
        video.pause();
        queuedTake = queued;
        return false;
      }
      const canFade = state.transition === 'fade' && oldPlayer.readyState >= 2;
      previousPlayer = canFade ? oldIndex : null;
      fadeStartedAt = performance.now();
      fadePausedAt = 0;
      activePlayer = queued.index;
      state.currentId = queued.id;
      lastId = queued.id;
      if (!canFade) oldPlayer.pause();
      save();
      renderVideoList();
      updateTransport();
      reportPlayerStatus();
      return true;
    } catch (error) {
      video.pause();
      console.warn('[LiveWelPro] falha ao iniciar o próximo take; tentando continuar a sequência', error);
      setConnectionState('warning', 'Recuperando a sequência de vídeos…');
      if (playing && oldPlayer.ended) setTimeout(() => advanceFinishedTake(oldPlayer), 0);
      return false;
    }
  })();
  const trackedTask = task.finally(() => {
    if (takeSwitchPromise === trackedTask) {
      takeSwitchPromise = null;
      if (playing && previousPlayer === null && !queuedTake) void prepareNextTake();
    }
  });
  takeSwitchPromise = trackedTask;
  return trackedTask;
}

async function advanceFinishedTake(video) {
  if (!playing || video !== players[activePlayer]) return false;
  if (takeSwitchPromise) return takeSwitchPromise;
  await prepareNextTake();
  if (!playing || video !== players[activePlayer]) return false;
  if (queuedTake) return commitQueuedTake();
  const id = pickNext(1);
  if (!id) return false;
  await selectVideo(id, true);
  return true;
}

function monitorPlaybackBoundary() {
  if (!playing || takeSwitchPromise || previousPlayer !== null) return;
  const video = players[activePlayer];
  if (!video || video.paused || video.ended || !Number.isFinite(video.duration)) return;
  const remaining = Math.max(0, video.duration - video.currentTime);
  const fadeSeconds = fadeDurationMs() / 1000;
  if (!queuedTake && remaining <= Math.max(PRELOAD_LEAD_SECONDS, fadeSeconds + 1)) void prepareNextTake();
  if (state.transition === 'fade' && queuedTake && remaining <= fadeSeconds + TRANSITION_START_MARGIN_SECONDS) {
    void commitQueuedTake();
  }
}

function togglePlay() {
  if (!state.videos.length) return;
  playing = !playing;
  state.mediaLayers.forEach(syncMediaLayerPlayback);
  if (playing) {
    if (previousPlayer !== null && fadePausedAt) fadeStartedAt += performance.now() - fadePausedAt;
    fadePausedAt = 0;
    const active = players[activePlayer];
    if (active.ended) void advanceFinishedTake(active);
    else active.play().catch(() => schedulePlaybackRecovery(active));
    if (previousPlayer !== null) {
      const previous = players[previousPlayer];
      if (!previous.ended) previous.play().catch(() => {});
    }
    void prepareNextTake();
    setConnectionState('warning', 'Conectando ao TikTok Shop…');
  } else {
    clearTimeout(playbackRecoveryTimer);
    playbackRecoveryTimer = 0;
    if (previousPlayer !== null) fadePausedAt = performance.now();
    players.forEach((video) => video.pause());
    setConnectionState('online', 'Saída pausada');
  }
  reportPlayerStatus();
  updateTransport();
}

function updateTransport() {
  const meta = state.videos.find((v) => v.id === state.currentId);
  $('btnPlay').textContent = playing ? 'Pausar transmissão' : 'Iniciar transmissão';
  $('nowPlaying').textContent = meta?.name || 'Aguardando vídeos';
  const index = Math.max(0, state.videos.findIndex((v) => v.id === state.currentId));
  $('takeCounter').textContent = `${state.videos.length ? index + 1 : 0} / ${state.videos.length}`;
  $('emptyState').classList.toggle('hidden', Boolean(meta));
}

function renderVideoList() {
  $('videoList').innerHTML = state.videos.length ? state.videos.map((video, index) => `<div class="media-item ${video.id === state.currentId ? 'active' : ''}" data-id="${video.id}"><span class="media-index">${index + 1}</span><div class="media-copy"><strong title="${escapeHtml(video.name)}">${escapeHtml(video.name)}</strong><span>${(video.size / 1048576).toFixed(1)} MB</span></div><button type="button" data-remove="${video.id}" title="Remover">×</button></div>`).join('') : '<div class="empty-list">Importe vários vídeos de uma vez para criar a sequência.</div>';
}

async function removeVideo(id) {
  const wasCurrent = state.currentId === id;
  state.videos = state.videos.filter((video) => video.id !== id);
  bag = bag.filter((item) => item !== id);
  await idbDeleteBlob(id);
  if (urls.has(id)) URL.revokeObjectURL(urls.get(id));
  urls.delete(id);
  if (wasCurrent) {
    state.currentId = null;
    players.forEach((video) => { video.pause(); video.removeAttribute('src'); video.load(); });
    if (state.videos[0]) await selectVideo(state.videos[0].id, playing);
  }
  save();
  renderVideoList();
  updateTransport();
}

function normalizeMediaLayer(layer = {}) {
  const blends = new Set(['source-over', 'screen', 'overlay', 'soft-light', 'multiply']);
  const type = layer.type === 'image' ? 'image' : 'video';
  const x = Number(layer.x);
  const y = Number(layer.y);
  const opacity = Number(layer.opacity);
  return {
    id: String(layer.id || mediaId(type === 'image' ? 'layer_img' : 'layer_vid')),
    type,
    name: String(layer.name || (type === 'image' ? 'Imagem' : 'Vídeo')),
    sizeBytes: Math.max(0, Number(layer.sizeBytes ?? layer.size) || 0),
    x: Math.max(0, Math.min(1, Number.isFinite(x) ? x : .5)),
    y: Math.max(0, Math.min(1, Number.isFinite(y) ? y : .5)),
    size: Math.max(5, Math.min(100, Number(layer.size) || 42)),
    opacity: Math.max(0, Math.min(100, Number.isFinite(opacity) ? opacity : 100)),
    blend: blends.has(layer.blend) ? layer.blend : 'source-over',
    enabled: layer.enabled !== false,
    loop: layer.loop !== false,
    aspect: Math.max(.05, Math.min(20, Number(layer.aspect) || 1))
  };
}

function mediaLayerBox(item) {
  const size = Math.max(.05, Math.min(1, Number(item.size) / 100 || .42));
  const sourceAspect = Math.max(.05, Number(item.aspect) || 1);
  const canvasAspect = Math.max(.05, canvas.width / canvas.height);
  if (sourceAspect >= canvasAspect) {
    return { width: size, height: size * canvasAspect / sourceAspect };
  }
  return { width: size * sourceAspect / canvasAspect, height: size };
}

async function loadMediaLayer(item) {
  if (!item?.id) return null;
  const current = mediaLayerSources.get(item.id);
  if (current?.element) return current;
  const sourceUrl = await objectUrl(item.id);
  let element;
  if (item.type === 'image') {
    element = new Image();
    element.decoding = 'async';
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('A imagem demorou demais para carregar.')), 12000);
      element.onload = () => { clearTimeout(timer); resolve(); };
      element.onerror = () => { clearTimeout(timer); reject(new Error('Formato de imagem não suportado.')); };
      element.src = sourceUrl;
    });
    item.aspect = element.naturalWidth / Math.max(1, element.naturalHeight);
  } else {
    element = document.createElement('video');
    element.className = 'media-source media-layer-source';
    element.preload = 'auto';
    element.playsInline = true;
    element.muted = true;
    element.loop = item.loop !== false;
    element.src = sourceUrl;
    (document.body || document.documentElement).appendChild(element);
    await new Promise((resolve, reject) => {
      if (element.readyState >= 2) return resolve();
      const timer = setTimeout(() => reject(new Error('O vídeo da camada demorou demais para carregar.')), 12000);
      element.addEventListener('loadeddata', () => { clearTimeout(timer); resolve(); }, { once: true });
      element.addEventListener('error', () => { clearTimeout(timer); reject(new Error('Codec da camada não suportado pelo Chrome.')); }, { once: true });
      element.load();
    });
    item.aspect = element.videoWidth / Math.max(1, element.videoHeight);
  }
  const entry = { element, type: item.type };
  mediaLayerSources.set(item.id, entry);
  syncMediaLayerPlayback(item);
  save();
  renderMediaLayerEditor();
  renderDragLayer();
  return entry;
}

function syncMediaLayerPlayback(item) {
  const entry = mediaLayerSources.get(item?.id);
  if (!entry || entry.type !== 'video') return;
  entry.element.loop = item.loop !== false;
  if (playing && item.enabled !== false) entry.element.play().catch(() => {});
  else entry.element.pause();
}

async function importMediaLayers(files, type) {
  for (const file of files) {
    if (!file || (type === 'image' ? !file.type.startsWith('image/') : !file.type.startsWith('video/'))) continue;
    const id = mediaId(type === 'image' ? 'layer_img' : 'layer_vid');
    await idbPutBlob(id, file, { fileName: file.name, type: file.type, layerType: type });
    const item = normalizeMediaLayer({
      id,
      type,
      name: file.name,
      sizeBytes: file.size,
      x: .5,
      y: .5,
      size: type === 'image' ? 35 : 45,
      opacity: 100,
      blend: 'source-over',
      enabled: true,
      loop: true
    });
    state.mediaLayers.push(item);
    selectedMediaLayerId = id;
    save();
    renderMediaLayerEditor();
    renderDragLayer();
    await loadMediaLayer(item);
  }
}

async function removeMediaLayer(id) {
  const entry = mediaLayerSources.get(id);
  if (entry?.type === 'video') {
    entry.element.pause();
    entry.element.removeAttribute('src');
    entry.element.load();
    entry.element.remove();
  }
  mediaLayerSources.delete(id);
  state.mediaLayers = state.mediaLayers.filter((item) => item.id !== id);
  if (selectedMediaLayerId === id) selectedMediaLayerId = null;
  await idbDeleteBlob(id).catch(() => {});
  if (urls.has(id)) URL.revokeObjectURL(urls.get(id));
  urls.delete(id);
  save();
  renderMediaLayerEditor();
  renderDragLayer();
}

function moveMediaLayer(id, direction) {
  const index = state.mediaLayers.findIndex((item) => item.id === id);
  const target = Math.max(0, Math.min(state.mediaLayers.length - 1, index + direction));
  if (index < 0 || target === index) return;
  const [item] = state.mediaLayers.splice(index, 1);
  state.mediaLayers.splice(target, 0, item);
  selectedMediaLayerId = id;
  save();
  renderMediaLayerEditor();
  renderDragLayer();
}

function updateMediaLayer(id, field, value) {
  const item = state.mediaLayers.find((entry) => entry.id === id);
  if (!item) return;
  if (field === 'enabled' || field === 'loop') item[field] = Boolean(value);
  else if (field === 'opacity') item.opacity = Math.max(0, Math.min(100, Number(value) || 0));
  else if (field === 'size') item.size = Math.max(5, Math.min(100, Number(value) || 5));
  else if (field === 'blend') item.blend = normalizeMediaLayer({ ...item, blend: value }).blend;
  selectedMediaLayerId = id;
  syncMediaLayerPlayback(item);
  save();
  renderDragLayer();
}

function renderMediaLayerEditor() {
  $('mediaLayerList').innerHTML = state.mediaLayers.length ? state.mediaLayers.map((item, index) => `
    <details class="media-layer-card ${item.id === selectedMediaLayerId ? 'selected' : ''}" data-layer-id="${item.id}" ${item.id === selectedMediaLayerId ? 'open' : ''}>
      <summary>
        <input type="checkbox" data-layer-field="enabled" ${item.enabled ? 'checked' : ''} title="Exibir camada" />
        <span class="layer-type">${item.type === 'image' ? 'IMG' : 'VID'}</span>
        <span class="layer-copy"><strong title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</strong><small>Camada ${index + 1} · ${item.type === 'image' ? 'imagem' : 'vídeo em loop'}</small></span>
        <span class="layer-summary-actions"><button type="button" data-layer-action="down" title="Enviar para trás">↓</button><button type="button" data-layer-action="up" title="Trazer para frente">↑</button><button type="button" data-layer-action="remove" title="Remover">×</button></span>
      </summary>
      <div class="layer-controls">
        <label>Opacidade <output>${Math.round(item.opacity)}%</output><input type="range" min="0" max="100" value="${item.opacity}" data-layer-field="opacity" /></label>
        <label>Tamanho <output>${Math.round(item.size)}%</output><input type="range" min="5" max="100" value="${item.size}" data-layer-field="size" /></label>
        <label class="wide">Mesclagem<select data-layer-field="blend"><option value="source-over" ${item.blend === 'source-over' ? 'selected' : ''}>Normal</option><option value="screen" ${item.blend === 'screen' ? 'selected' : ''}>Screen</option><option value="overlay" ${item.blend === 'overlay' ? 'selected' : ''}>Overlay</option><option value="soft-light" ${item.blend === 'soft-light' ? 'selected' : ''}>Soft light</option><option value="multiply" ${item.blend === 'multiply' ? 'selected' : ''}>Multiply</option></select></label>
        ${item.type === 'video' ? `<label class="wide switch-row"><span><strong>Repetir continuamente</strong><small>A camada reinicia quando chegar ao final</small></span><input type="checkbox" data-layer-field="loop" ${item.loop ? 'checked' : ''} /></label>` : ''}
        <div class="layer-buttons"><button type="button" data-layer-action="center">Centralizar</button><button type="button" data-layer-action="remove" class="danger-text">Remover camada</button></div>
      </div>
    </details>`).join('') : '<div class="empty-list">Nenhuma camada de mídia adicionada.</div>';
}

function renderOverlayEditor() {
  $('overlayList').innerHTML = state.overlays.length ? state.overlays.map((item) => `<details class="overlay-card" data-id="${item.id}"><summary><input type="checkbox" data-field="enabled" ${item.enabled ? 'checked' : ''}/><strong>${escapeHtml(item.name)}</strong><button type="button" data-delete="${item.id}" title="Remover">Remover</button></summary><div class="overlay-controls">${overlayEditorControls(item)}</div></details>`).join('') : '<div class="empty-list">Nenhum overlay ativo.</div>';
}

function overlayEditorControls(item) {
  if (item.type === 'price-marquee') {
    const size = Math.max(14, Math.min(80, Number(item.size) || 28));
    const speed = Math.max(2, Math.min(30, Number(item.speed) || 6));
    return `<label class="wide">Preço promocional (POR)<input type="text" data-field="promoPrice" value="${escapeHtml(item.promoPrice || '')}" placeholder="R$ 17,99" /></label><label class="wide">Preço original (DE)<input type="text" data-field="originalPrice" value="${escapeHtml(item.originalPrice || '')}" placeholder="R$ 64,99" /></label><label class="wide">Tamanho da fonte<div class="overlay-range-pair"><input type="range" min="14" max="80" data-field="size" value="${size}" /><input type="number" min="14" max="80" data-field="size" value="${size}" /></div></label><label class="wide">Duração de cada volta<div class="overlay-range-pair"><input type="range" min="2" max="30" step="0.5" data-field="speed" value="${speed}" /><input type="number" min="2" max="30" step="0.5" data-field="speed" value="${speed}" /></div><small>Menos segundos deixa o texto mais rápido.</small></label><label>Cor da fonte<input type="color" data-field="color" value="${String(item.color || '#ff0000').slice(0,7)}" /></label><label>Cor do fundo<input type="color" data-field="bg" value="${String(item.bg || '#fff200').slice(0,7)}" /></label>`;
  }
  return `<label class="wide">Texto<input type="text" data-field="text" value="${escapeHtml(item.text)}" /></label><label>Tamanho<input type="number" min="10" max="80" data-field="size" value="${item.size}" /></label><label>Intervalo<input type="number" min="1" max="60" data-field="interval" value="${item.interval || 3}" ${item.type === 'banner' ? '' : 'disabled'} /></label><label>Texto<input type="color" data-field="color" value="${String(item.color).slice(0,7)}" /></label><label>Fundo<input type="color" data-field="bg" value="${String(item.bg).slice(0,7)}" /></label>${item.type === 'timer' ? `<label class="wide">Duração em segundos<input type="number" min="10" max="7200" data-field="duration" value="${item.duration || 299}" /></label>` : ''}`;
}

function dragLabel(item) {
  if (item.type === 'timer') return `${item.text} 04:59`;
  if (item.type === 'banner') return item.text.split('|')[0];
  if (item.type === 'price-marquee') return `POR: ${item.promoPrice || ''} · DE: ${item.originalPrice || ''}`;
  return item.text;
}

function renderDragLayer() {
  const media = state.mediaLayers.filter((item) => item.enabled).map((item) => {
    const box = mediaLayerBox(item);
    return `<div class="drag-item media-drag-item" data-kind="media" data-id="${item.id}" data-selected="${item.id === selectedMediaLayerId}" style="left:${item.x * 100}%;top:${item.y * 100}%;width:${box.width * 100}%;height:${box.height * 100}%;opacity:${Math.max(.25, item.opacity / 100)}"><span>${item.type === 'image' ? 'IMG' : 'VID'} · ${escapeHtml(item.name)}</span></div>`;
  }).join('');
  const text = state.overlays.filter((item) => item.enabled).map((item) => item.type === 'price-marquee'
    ? `<div class="drag-item price-drag-item" data-kind="text" data-id="${item.id}" title="Arraste para mover a faixa de preço" style="left:${item.x * 100}%;top:${item.y * 100}%;font-size:${Math.max(8,item.size/3)}px"></div>`
    : `<div class="drag-item" data-kind="text" data-id="${item.id}" style="left:${item.x * 100}%;top:${item.y * 100}%;font-size:${Math.max(8,item.size/3)}px;color:${item.color}">${escapeHtml(dragLabel(item))}</div>`).join('');
  $('dragLayer').innerHTML = media + text;
}

function updateOverlay(id, field, value) {
  const item = state.overlays.find((entry) => entry.id === id);
  if (!item) return;
  if (field === 'enabled') item.enabled = Boolean(value);
  else if (['size','interval','duration','speed'].includes(field)) item[field] = Number(value);
  else item[field] = value;
  if (field === 'duration') timerStartedAt = performance.now();
  save();
  renderDragLayer();
}

function roundedRect(context, x, y, width, height, radius) {
  context.beginPath(); context.roundRect(x, y, width, height, radius); context.fill();
}

function drawFit(video, alpha = 1) {
  if (!video?.videoWidth || video.readyState < 2) return;
  const scale = state.fit === 'cover' ? Math.max(canvas.width / video.videoWidth, canvas.height / video.videoHeight) : Math.min(canvas.width / video.videoWidth, canvas.height / video.videoHeight);
  const width = video.videoWidth * scale, height = video.videoHeight * scale;
  ctx.globalAlpha = alpha;
  ctx.drawImage(video, (canvas.width - width) / 2, (canvas.height - height) / 2, width, height);
  ctx.globalAlpha = 1;
}

function drawMediaLayer(item) {
  if (!item?.enabled) return;
  const entry = mediaLayerSources.get(item.id);
  const source = entry?.element;
  const ready = entry?.type === 'image'
    ? Boolean(source?.complete && source.naturalWidth)
    : Boolean(source?.readyState >= 2 && source.videoWidth);
  if (!ready) return;
  const box = mediaLayerBox(item);
  const width = box.width * canvas.width;
  const height = box.height * canvas.height;
  const x = item.x * canvas.width - width / 2;
  const y = item.y * canvas.height - height / 2;
  ctx.save();
  ctx.globalAlpha = Math.max(0, Math.min(1, item.opacity / 100));
  ctx.globalCompositeOperation = item.blend || 'source-over';
  ctx.drawImage(source, x, y, width, height);
  ctx.restore();
}

function drawTextOverlay(item, now) {
  if (item.type === 'price-marquee') {
    drawPriceMarquee(item, now);
    return;
  }
  let text = item.text;
  if (item.type === 'timer') {
    const duration = Math.max(10, Number(item.duration) || 299);
    const elapsed = Math.floor((now - timerStartedAt) / 1000);
    const remaining = duration - (elapsed % (duration + 1));
    text = `${item.text}\n${String(Math.floor(remaining / 60)).padStart(2,'0')}:${String(remaining % 60).padStart(2,'0')}`;
  } else if (item.type === 'banner') {
    const phrases = item.text.split('|').map((s) => s.trim()).filter(Boolean);
    text = phrases[Math.floor(now / ((item.interval || 3) * 1000)) % Math.max(1, phrases.length)] || '';
  }
  const lines = text.split('\n');
  ctx.font = `700 ${item.size}px Inter, system-ui`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const widths = lines.map((line) => ctx.measureText(line).width);
  const width = Math.max(...widths, 40) + 34, height = lines.length * item.size * 1.25 + 22;
  const x = item.x * canvas.width, y = item.y * canvas.height;
  ctx.fillStyle = item.bg;
  roundedRect(ctx, x - width/2, y - height/2, width, height, Math.min(18, height/3));
  ctx.fillStyle = item.color;
  lines.forEach((line, index) => ctx.fillText(line, x, y + (index - (lines.length-1)/2) * item.size * 1.2));
}

function drawPriceMarquee(item, now) {
  const size = Math.max(14, Math.min(80, Number(item.size) || 28));
  const duration = Math.max(2, Math.min(30, Number(item.speed) || 6)) * 1000;
  const lines = [`POR: ${item.promoPrice || ''}`, `DE: ${item.originalPrice || ''}`];
  const lineHeight = size * 1.16;
  const contentHeight = lineHeight * lines.length;
  const paddingX = size * .56;
  const paddingY = size * .34;
  const x = item.x * canvas.width;
  const y = item.y * canvas.height;

  ctx.save();
  ctx.font = `900 ${size}px Inter, system-ui`;
  const width = Math.max(...lines.map((line) => ctx.measureText(line).width), 70) + paddingX * 2;
  const height = contentHeight + paddingY * 2;
  const left = x - width / 2;
  const top = y - height / 2;
  const radius = Math.min(12, height / 5);

  ctx.fillStyle = item.bg || '#fff200';
  roundedRect(ctx, left, top, width, height, radius);
  ctx.beginPath();
  ctx.roundRect(left, top, width, height, radius);
  ctx.clip();
  ctx.fillStyle = item.color || '#ff0000';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';

  const gap = lineHeight * .65;
  const travel = height + contentHeight + gap;
  const movingTop = top - contentHeight + ((now % duration) / duration) * travel;
  for (let copy = -1; copy <= 1; copy += 1) {
    const blockTop = movingTop + copy * travel;
    lines.forEach((line, index) => ctx.fillText(line, left + paddingX, blockTop + lineHeight * (index + .5)));
  }
  ctx.restore();
}

function drawEffects(now) {
  if (state.scanEnabled) {
    const progressRaw = (now % (state.scanSpeed * 1000)) / (state.scanSpeed * 1000);
    const progress = state.scanDirection === 'up' ? 1 - progressRaw : progressRaw;
    const thick = state.scanThickness || 70;
    const alpha = state.scanOpacity / 100;
    const color = state.scanColor || '#ffffff';
    ctx.save(); ctx.globalCompositeOperation = state.scanBlend || 'screen';
    if (state.scanModel === 'crt') {
      ctx.globalAlpha = alpha * .45; ctx.fillStyle = color;
      for (let y = 0; y < canvas.height; y += Math.max(3, Math.round(thick / 12))) ctx.fillRect(0, y, canvas.width, 1);
    } else if (state.scanModel === 'glitch') {
      ctx.globalAlpha = alpha;
      const y = progress * canvas.height;
      for (let i = 0; i < 8; i++) { const gy = y + (i - 4) * thick * .18; ctx.fillStyle = i % 2 ? color : '#00e5ff'; ctx.fillRect((i % 3) * 18, gy, canvas.width - (i % 4) * 25, Math.max(2, thick * .08)); }
    } else if (state.scanModel === 'tracking') {
      const y = progress * canvas.height; ctx.globalAlpha = alpha;
      for (let i = 0; i < 16; i++) { ctx.fillStyle = i % 3 ? color : '#ff4fd8'; ctx.fillRect(Math.random() * 40, y + Math.random() * thick - thick / 2, canvas.width - Math.random() * 80, 1 + Math.random() * 3); }
    } else {
      const horizontal = state.scanDirection === 'horizontal';
      const pos = progress * (horizontal ? canvas.width : canvas.height);
      const gradient = horizontal ? ctx.createLinearGradient(pos-thick,0,pos+thick,0) : ctx.createLinearGradient(0,pos-thick,0,pos+thick);
      gradient.addColorStop(0,'transparent'); gradient.addColorStop(.5, color); gradient.addColorStop(1,'transparent');
      ctx.globalAlpha = alpha; ctx.fillStyle = gradient;
      if (horizontal) ctx.fillRect(pos-thick,0,thick*2,canvas.height); else ctx.fillRect(0,pos-thick,canvas.width,thick*2);
      if (state.scanModel === 'dual') { const second = (pos + (horizontal ? canvas.width : canvas.height)/2) % (horizontal ? canvas.width : canvas.height); if(horizontal) ctx.fillRect(second-thick,0,thick*2,canvas.height); else ctx.fillRect(0,second-thick,canvas.width,thick*2); }
      if (state.scanModel === 'beam') ctx.globalAlpha = Math.min(1, alpha * 1.8);
    }
    ctx.restore();
  }
  if (state.emojiEnabled) {
    if (now - lastParticleAt > 700) {
      const symbols = state.emojiSet.trim().split(/\s+/).filter(Boolean);
      if (symbols.length) particles.push({ text: symbols[Math.floor(Math.random()*symbols.length)], x: .1 + Math.random()*.8, born: now, drift: (Math.random()-.5)*.12 });
      lastParticleAt = now;
    }
    particles = particles.filter((p) => now - p.born < 4000);
    ctx.textAlign = 'center'; ctx.font = '36px system-ui';
    for (const particle of particles) {
      const age = (now - particle.born) / 4000;
      ctx.globalAlpha = Math.sin(Math.PI * age) * .8;
      ctx.fillText(particle.text, (particle.x + particle.drift * age) * canvas.width, (1.02 - age * .8) * canvas.height);
    }
    ctx.globalAlpha = 1;
  }
}

function render(now) {
  if (lastRenderedAt && now - lastRenderedAt < FRAME_INTERVAL_MS - 1) {
    scheduleRender();
    return;
  }
  lastRenderedAt = now;
  monitorPlaybackBoundary();
  if (previousPlayer !== null && state.transition !== 'fade') finishFade();
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (previousPlayer !== null && state.transition === 'fade') {
    const linearProgress = Math.min(1, (now - fadeStartedAt) / fadeDurationMs());
    const easedProgress = linearProgress * linearProgress * (3 - 2 * linearProgress);
    drawFit(players[previousPlayer], 1);
    drawFit(players[activePlayer], easedProgress);
    if (linearProgress >= 1) finishFade();
  } else drawFit(players[activePlayer], 1);
  if (!state.currentId || players[activePlayer].readyState < 2) {
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#07141a'); gradient.addColorStop(.55, '#090b11'); gradient.addColorStop(1, '#101722');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#55e5bb'; ctx.beginPath(); ctx.arc(canvas.width / 2, canvas.height / 2 - 90, 32, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#07120f'; ctx.font = '900 17px system-ui'; ctx.textAlign = 'center'; ctx.fillText('LW', canvas.width / 2, canvas.height / 2 - 84);
    ctx.fillStyle = '#f4f7fa'; ctx.font = '700 29px system-ui'; ctx.fillText('LiveWelPro pronto', canvas.width / 2, canvas.height / 2 - 24);
    ctx.fillStyle = '#9eabb9'; ctx.font = '19px system-ui'; ctx.fillText('Importe um vídeo e inicie a transmissão', canvas.width / 2, canvas.height / 2 + 18);
  }
  state.mediaLayers.forEach(drawMediaLayer);
  drawEffects(now);
  state.overlays.filter((item) => item.enabled).forEach((item) => drawTextOverlay(item, now));
  // WebP exists only as a compatibility path. Keeping it at 10 FPS avoids
  // saturating weaker CPUs while WebRTC reconnects.
  const fallbackInterval = rtcConnectedReceivers.size ? 1000 : 100;
  if (playing && now - lastFrameSent > fallbackInterval && !frameBusy) transmitFrame(now);
  scheduleRender();
}

function scheduleRender() {
  const video = players[activePlayer];
  if (document.hidden && video?.requestVideoFrameCallback && !video.paused) video.requestVideoFrameCallback((now) => render(now));
  else requestAnimationFrame(render);
}

function transmitFrame(now) {
  frameBusy = true;
  lastFrameSent = now;
  canvas.toBlob((blob) => {
    if (!blob) {
      frameBusy = false;
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const frame = reader.result;
      if (rtcPortMessage({
        type: 'fallback-frame',
        requestId: `frame_${++fallbackRequestSequence}`,
        frame
      })) {
        frameBusy = false;
        return;
      }
      chrome.runtime.sendMessage({
      type: 'LIVEWEL_PLAYER_FRAME',
      frame
    }).then((response) => {
      if (performance.now() - lastRelayStatusAt < 700) return;
      lastRelayStatusAt = performance.now();
      if (rtcConnectedReceivers.size) setConnectionState('online', 'Vídeo fluido conectado · WebRTC 30 FPS');
      else if (response?.ok) setConnectionState('online', 'Vídeo conectado ao TikTok · modo compatível');
      else setConnectionState('warning', response?.error || 'Aguardando a página da LIVE');
    }).catch(() => {
      if (performance.now() - lastRelayStatusAt < 700) return;
      lastRelayStatusAt = performance.now();
      setConnectionState('error', 'Extensão desconectada — recarregue-a');
      }).finally(() => { frameBusy = false; });
    };
    reader.onerror = () => { frameBusy = false; };
    reader.readAsDataURL(blob);
  }, 'image/webp', .68);
}

document.querySelector('.tabs').addEventListener('click', (event) => {
  const tab = event.target.closest('[data-tab]'); if (!tab) return;
  document.querySelectorAll('.tab').forEach((item) => item.classList.toggle('active', item === tab));
  document.querySelectorAll('.pane').forEach((pane) => pane.classList.toggle('active', pane.dataset.pane === tab.dataset.tab));
});
$('videoInput').addEventListener('change', async (event) => {
  const files = [...event.target.files];
  event.target.value = '';
  try {
    await importVideos(files);
  } catch (error) {
    $('emptyState').classList.remove('hidden');
    $('emptyState').querySelector('strong').textContent = 'Não foi possível abrir o vídeo';
    $('emptyState').querySelector('span').textContent = String(error?.message || error);
    setConnectionState('error', 'Falha ao carregar vídeo');
  }
});
for (const [inputId, type] of [['layerVideoInput', 'video'], ['layerImageInput', 'image']]) {
  $(inputId).addEventListener('change', async (event) => {
    const files = [...event.target.files];
    event.target.value = '';
    try {
      await importMediaLayers(files, type);
    } catch (error) {
      setConnectionState('error', `Falha ao adicionar camada: ${String(error?.message || error)}`);
    }
  });
}
$('mediaLayerList').addEventListener('input', (event) => {
  const card = event.target.closest('[data-layer-id]');
  const field = event.target.dataset.layerField;
  if (!card || !field || event.target.type !== 'range') return;
  updateMediaLayer(card.dataset.layerId, field, event.target.value);
  const output = event.target.closest('label')?.querySelector('output');
  if (output) output.value = `${Math.round(Number(event.target.value))}%`;
});
$('mediaLayerList').addEventListener('change', (event) => {
  const card = event.target.closest('[data-layer-id]');
  const field = event.target.dataset.layerField;
  if (!card || !field) return;
  const value = event.target.type === 'checkbox' ? event.target.checked : event.target.value;
  updateMediaLayer(card.dataset.layerId, field, value);
});
$('mediaLayerList').addEventListener('click', (event) => {
  const card = event.target.closest('[data-layer-id]');
  if (!card) return;
  selectedMediaLayerId = card.dataset.layerId;
  const action = event.target.closest('[data-layer-action]')?.dataset.layerAction;
  if (!action) {
    document.querySelectorAll('.media-layer-card').forEach((item) => item.classList.toggle('selected', item.dataset.layerId === selectedMediaLayerId));
    renderDragLayer();
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (action === 'remove') removeMediaLayer(card.dataset.layerId).catch(() => {});
  if (action === 'up') moveMediaLayer(card.dataset.layerId, 1);
  if (action === 'down') moveMediaLayer(card.dataset.layerId, -1);
  if (action === 'center') {
    const item = state.mediaLayers.find((entry) => entry.id === card.dataset.layerId);
    if (item) { item.x = .5; item.y = .5; save(); renderDragLayer(); }
  }
});
$('videoList').addEventListener('click', (event) => {
  const remove = event.target.closest('[data-remove]');
  if (remove) removeVideo(remove.dataset.remove); else { const item = event.target.closest('[data-id]'); if (item) selectVideo(item.dataset.id, playing); }
});
$('btnPlay').addEventListener('click', togglePlay); $('btnNext').addEventListener('click', () => next(1)); $('btnPrev').addEventListener('click', () => { state.shuffle = false; $('shuffle').checked = false; next(-1); save(); });
$('btnClear').addEventListener('click', async () => { if (!state.videos.length || !confirm('Remover todos os vídeos importados?')) return; for (const video of [...state.videos]) await removeVideo(video.id); });

for (const id of ['shuffle','scanEnabled','emojiEnabled']) $(id).addEventListener('change', (event) => { state[id] = event.target.checked; if (id === 'shuffle') bag = []; save(); });
for (const id of ['fit','transition','emojiSet','scanModel','scanColor','scanDirection','scanBlend']) $(id).addEventListener('change', (event) => {
  state[id] = event.target.value;
  if (id === 'transition') {
    state.transitionEngineVersion = TRANSITION_ENGINE_VERSION;
    if (state.transition !== 'fade') finishFade();
    else if (playing) void prepareNextTake();
  }
  save();
});
for (const id of ['fadeMs','scanOpacity','scanThickness','scanSpeed']) $(id).addEventListener('input', (event) => { state[id] = Number(event.target.value); $(`${id}Value`).value = id === 'fadeMs' ? `${state[id]} ms` : id === 'scanSpeed' ? `${state[id]} s` : id === 'scanThickness' ? `${state[id]} px` : `${state[id]}%`; save(); });

$('overlayList').addEventListener('input', (event) => { const card = event.target.closest('[data-id]'); const field = event.target.dataset.field; if (!card || !field) return; const value = event.target.type === 'checkbox' ? event.target.checked : event.target.value; updateOverlay(card.dataset.id, field, value); if (['size','speed'].includes(field)) card.querySelectorAll(`[data-field="${field}"]`).forEach((control) => { if (control !== event.target) control.value = value; }); });
$('overlayList').addEventListener('click', (event) => { const button = event.target.closest('[data-delete]'); if (!button) return; state.overlays = state.overlays.filter((item) => item.id !== button.dataset.delete); save(); renderOverlayEditor(); renderDragLayer(); });
$('btnAddBanner').addEventListener('click', () => { state.overlays.push({ id: mediaId('overlay'), type:'banner', name:'Banner personalizado', text:'Nova mensagem', x:.5, y:.5, size:20, color:'#ffffff', bg:'#111827', interval:3, enabled:true }); save(); renderOverlayEditor(); renderDragLayer(); });
$('btnAddPrice').addEventListener('click', () => { state.overlays.push({ id: mediaId('price'), type:'price-marquee', name:'Faixa de preço', promoPrice:'R$ 17,99', originalPrice:'R$ 64,99', x:.5, y:.56, size:28, color:'#ff0000', bg:'#fff200', speed:6, enabled:true }); save(); renderOverlayEditor(); renderDragLayer(); });
$('btnResetOverlays').addEventListener('click', () => { state.overlays = defaultOverlays(); timerStartedAt = performance.now(); save(); renderOverlayEditor(); renderDragLayer(); });

$('dragLayer').addEventListener('pointerdown', (event) => {
  const element = event.target.closest('.drag-item'); if (!element) return;
  const isMedia = element.dataset.kind === 'media';
  if (isMedia) {
    selectedMediaLayerId = element.dataset.id;
    element.dataset.selected = 'true';
    document.querySelectorAll('.media-layer-card').forEach((card) => card.classList.toggle('selected', card.dataset.layerId === selectedMediaLayerId));
  }
  element.setPointerCapture(event.pointerId); element.classList.add('dragging');
  const move = (moveEvent) => {
    const rect = $('stage').getBoundingClientRect();
    const item = (isMedia ? state.mediaLayers : state.overlays).find((entry) => entry.id === element.dataset.id); if (!item) return;
    item.x = Math.max(.02, Math.min(.98, (moveEvent.clientX - rect.left) / rect.width)); item.y = Math.max(.02, Math.min(.98, (moveEvent.clientY - rect.top) / rect.height));
    element.style.left = `${item.x*100}%`; element.style.top = `${item.y*100}%`;
  };
  const up = () => { element.classList.remove('dragging'); element.removeEventListener('pointermove', move); save(); if (isMedia) renderMediaLayerEditor(); };
  element.addEventListener('pointermove', move); element.addEventListener('pointerup', up, { once:true });
  element.addEventListener('pointercancel', up, { once:true });
});

players.forEach((video) => {
  video.addEventListener('timeupdate', monitorPlaybackBoundary);
  video.addEventListener('ended', () => { void advanceFinishedTake(video); });
  video.addEventListener('pause', () => { schedulePlaybackRecovery(video); });
  video.addEventListener('error', () => {
    if (video === players[activePlayer] && playing) void advanceFinishedTake(video);
  });
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'LIVEWEL_PLAYER_COMMAND') return;
  (async () => {
    const command = String(message.command || '').toUpperCase();
    if (command === 'PLAY') {
      if (!state.videos.length) return { ok: false, error: 'Nenhum vídeo importado.' };
      if (!playing) togglePlay();
      return { ok: true, playing };
    }
    if (command === 'PAUSE') {
      if (playing) togglePlay();
      return { ok: true, playing };
    }
    if (command === 'NEXT') {
      if (!state.videos.length) return { ok: false, error: 'Nenhum vídeo importado.' };
      await next(1);
      return { ok: true, currentId: state.currentId };
    }
    if (command === 'RESET_TIMER') {
      timerStartedAt = performance.now();
      return { ok: true };
    }
    return { ok: false, error: 'Comando do Player desconhecido.' };
  })().then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});
window.addEventListener('beforeunload', () => {
  clearTimeout(playbackRecoveryTimer);
  reportPlayerStatus(false);
  closeAllRtcPeers();
  try { rtcPort?.disconnect(); } catch {}
  for (const entry of mediaLayerSources.values()) {
    if (entry.type === 'video') entry.element.pause();
  }
  for (const url of urls.values()) URL.revokeObjectURL(url);
});

await restore();
setConnectionState('online', 'Saída pronta');
reportPlayerStatus();
setInterval(() => reportPlayerStatus(), 2000);
connectRtcTransport();
requestAnimationFrame(render);
