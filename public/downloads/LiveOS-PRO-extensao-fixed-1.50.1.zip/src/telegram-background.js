const TELEGRAM_SECRET_KEY = 'liveosTelegramSecretsV1';
const TELEGRAM_DEDUPE_KEY = 'liveosTelegramDedupeV1';
const TELEGRAM_UPDATE_KEY = 'liveosTelegramLastUpdateV1';
const TELEGRAM_MANUAL_SALES_KEY = 'liveosTelegramManualSalesV1';
const TELEGRAM_HISTORY_KEY = 'liveosTelegramHistoryV1';
const TELEGRAM_PENDING_ACTION_KEY = 'liveosTelegramPendingActionV1';
const TELEGRAM_POLL_ALARM = 'liveos-telegram-poll';
const TELEGRAM_RPC_PORT = 'livewel-telegram-rpc-v1';
const TELEGRAM_PENDING_TTL_MS = 2 * 60 * 1000;
const telegramDedupeClaims = new Map();
const TELEGRAM_COMMANDS = [
  { command: 'resumo', description: 'Resumo completo da operação' },
  { command: 'produto', description: 'Detalhes do produto atual' },
  { command: 'produtos', description: 'Lista a fila de produtos' },
  { command: 'buscarproduto', description: 'Busca um produto pelo nome' },
  { command: 'pin', description: 'Fixa produto por número ou nome' },
  { command: 'proximo', description: 'Avança produto e take' },
  { command: 'anterior', description: 'Volta ao produto anterior' },
  { command: 'meta', description: 'Define a meta de GMV' },
  { command: 'faltameta', description: 'Mostra quanto falta para a meta' },
  { command: 'status', description: 'Consulta GMV, pedidos e proteção' },
  { command: 'venda', description: 'Registra uma venda manual' },
  { command: 'vendas', description: 'Lista as vendas manuais' },
  { command: 'desfazervenda', description: 'Remove a última venda manual' },
  { command: 'removervenda', description: 'Remove uma venda pelo ID ou valor' },
  { command: 'historico', description: 'Mostra o histórico recente' },
  { command: 'comentario', description: 'Publica um comentário na live' },
  { command: 'auto', description: 'Liga ou desliga comentários periódicos' },
  { command: 'respostas', description: 'Liga ou desliga respostas automáticas' },
  { command: 'cenas', description: 'Lista as cenas do OBS' },
  { command: 'cena', description: 'Troca a cena do OBS' },
  { command: 'destaque', description: 'Salva o Replay Buffer do OBS' },
  { command: 'camera', description: 'Reinicia a câmera virtual' },
  { command: 'telemetria', description: 'Mostra FPS e reinícios' },
  { command: 'perfil', description: 'Seleciona 720p ou PC fraco' },
  { command: 'alertas', description: 'Consulta ou configura alertas' },
  { command: 'seguranca', description: 'Consulta a proteção da live' },
  { command: 'bloquear', description: 'Adiciona um perfil ao bloqueio' },
  { command: 'ciclo', description: 'Consulta o ciclo automático' },
  { command: 'diagnostico', description: 'Diagnóstico rápido da operação' },
  { command: 'audio', description: 'Consulta o áudio atual' },
  { command: 'play', description: 'Inicia vídeo e áudio' },
  { command: 'pausa', description: 'Pausa vídeo e áudio' },
  { command: 'timer', description: 'Reinicia o cronômetro da oferta' },
  { command: 'limparfila', description: 'Limpa a fila com confirmação' },
  { command: 'zerargmv', description: 'Zera GMV e pedidos com confirmação' },
  { command: 'confirmar', description: 'Executa uma ação pendente' },
  { command: 'cancelar', description: 'Cancela uma ação pendente' },
  { command: 'panic', description: 'Solicita encerramento imediato' },
  { command: 'ajuda', description: 'Lista todos os comandos' }
];
const TELEGRAM_DEFAULTS = {
  enabled: true,
  notifyManual: true,
  notifyDetected: true,
  notifySafety: true,
  chatId: '',
  botToken: '',
  lastCheckOk: false,
  lastCheckAt: 0,
  lastCheckError: '',
  botUsername: ''
};

async function readTelegramConfig() {
  const stored = await chrome.storage.local.get(TELEGRAM_SECRET_KEY);
  return { ...TELEGRAM_DEFAULTS, ...(stored[TELEGRAM_SECRET_KEY] || {}) };
}

function publicTelegramConfig(config) {
  return {
    enabled: config.enabled !== false,
    notifyManual: config.notifyManual !== false,
    notifyDetected: config.notifyDetected !== false,
    notifySafety: config.notifySafety !== false,
    chatId: String(config.chatId || ''),
    hasToken: Boolean(config.botToken),
    ready: Boolean(config.botToken && config.chatId),
    connected: Boolean(config.botToken && config.chatId && config.lastCheckOk),
    lastCheckAt: Number(config.lastCheckAt) || null,
    lastCheckError: String(config.lastCheckError || ''),
    botUsername: String(config.botUsername || ''),
    savedAt: Number(config.savedAt) || null,
    persistent: true
  };
}

async function saveTelegramConfig(input = {}) {
  const current = await readTelegramConfig();
  const next = {
    ...current,
    enabled: input.enabled !== false,
    notifyManual: input.notifyManual !== false,
    notifyDetected: input.notifyDetected !== false,
    notifySafety: input.notifySafety !== false,
    chatId: String(input.chatId ?? current.chatId ?? '').trim(),
    savedAt: Date.now()
  };
  const suppliedToken = String(input.botToken || '').trim();
  if (suppliedToken) next.botToken = suppliedToken;
  if (input.clearToken) next.botToken = '';
  if (input.clearChatId) next.chatId = '';
  if (suppliedToken || input.chatId != null || input.clearToken || input.clearChatId) {
    next.lastCheckOk = false;
    next.lastCheckError = '';
  }
  await chrome.storage.local.set({ [TELEGRAM_SECRET_KEY]: next });
  if ((suppliedToken && suppliedToken !== current.botToken) || input.clearToken) {
    lastUpdateId = 0;
    await chrome.storage.local.remove(TELEGRAM_UPDATE_KEY);
  }
  return publicTelegramConfig(next);
}

async function saveTelegramHealth(config, patch) {
  const next = { ...config, ...patch, lastCheckAt: Date.now() };
  await chrome.storage.local.set({ [TELEGRAM_SECRET_KEY]: next });
  return next;
}

async function telegramRequest(config, method, body) {
  if (!config.botToken) throw new Error('Informe o token do bot do Telegram.');
  if (!/^\d{5,}:[A-Za-z0-9_-]{20,}$/.test(config.botToken)) throw new Error('O token do bot não parece válido. Copie novamente do BotFather.');
  const response = await fetch(`https://api.telegram.org/bot${config.botToken}/${method}`, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    cache: 'no-store'
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.description || `Telegram respondeu HTTP ${response.status}.`);
  return data.result;
}

async function sendTelegramText(config, text) {
  if (!config.chatId) throw new Error('Informe o chat ID do Telegram.');
  return telegramRequest(config, 'sendMessage', {
    chat_id: config.chatId,
    text: String(text || '').slice(0, 4000),
    disable_web_page_preview: true
  });
}

async function checkTelegramConnection(config, { sendTest = false } = {}) {
  try {
    const bot = await telegramRequest(config, 'getMe');
    const chat = await telegramRequest(config, 'getChat', { chat_id: config.chatId });
    await telegramRequest(config, 'setMyCommands', { commands: TELEGRAM_COMMANDS }).catch(() => {});
    if (sendTest) {
      await sendTelegramText(config, '✅ LiveWelPro conectado. Alertas de GMV, pedidos, vendas, segurança e controle remoto estão ativos.\n\nEnvie /ajuda para listar os comandos.');
    }
    const next = await saveTelegramHealth(config, {
      lastCheckOk: true,
      lastCheckError: '',
      botUsername: String(bot?.username || ''),
      chatName: String(chat?.title || chat?.username || chat?.first_name || '')
    });
    return { ...publicTelegramConfig(next), chatName: next.chatName };
  } catch (error) {
    await saveTelegramHealth(config, { lastCheckOk: false, lastCheckError: String(error?.message || error) }).catch(() => {});
    throw error;
  }
}

async function claimTelegramEvent(eventId) {
  if (!eventId) return false;
  const now = Date.now();
  for (const [key, at] of telegramDedupeClaims) if (now - at > 12 * 60 * 60 * 1000) telegramDedupeClaims.delete(key);
  if (telegramDedupeClaims.has(eventId)) return true;
  telegramDedupeClaims.set(eventId, now);
  const stored = await chrome.storage.local.get(TELEGRAM_DEDUPE_KEY);
  const recent = stored[TELEGRAM_DEDUPE_KEY] || {};
  Object.keys(recent).forEach((key) => { if (now - Number(recent[key]) > 12 * 60 * 60 * 1000) delete recent[key]; });
  if (recent[eventId]) {
    telegramDedupeClaims.delete(eventId);
    return true;
  }
  return false;
}

async function markTelegramEventSent(eventId) {
  if (!eventId) return;
  const now = Date.now();
  const stored = await chrome.storage.local.get(TELEGRAM_DEDUPE_KEY);
  const recent = stored[TELEGRAM_DEDUPE_KEY] || {};
  Object.keys(recent).forEach((key) => { if (now - Number(recent[key]) > 12 * 60 * 60 * 1000) delete recent[key]; });
  recent[eventId] = now;
  await chrome.storage.local.set({ [TELEGRAM_DEDUPE_KEY]: recent });
  telegramDedupeClaims.delete(eventId);
}

function releaseTelegramEvent(eventId) {
  if (eventId) telegramDedupeClaims.delete(eventId);
}

async function findLatestChat(config) {
  const updates = await telegramRequest(config, 'getUpdates');
  const chats = [...updates].reverse().map((item) => item.message?.chat || item.edited_message?.chat || item.channel_post?.chat).filter(Boolean);
  if (!chats.length) throw new Error('Nenhuma conversa encontrada. Envie uma mensagem para o bot e tente novamente.');
  const chat = chats[0];
  const newestUpdateId = updates.reduce((max, item) => Math.max(max, Number(item.update_id) || 0), 0);
  if (newestUpdateId) {
    lastUpdateId = Math.max(lastUpdateId, newestUpdateId);
    await chrome.storage.local.set({ [TELEGRAM_UPDATE_KEY]: lastUpdateId });
  }
  const next = { ...config, chatId: String(chat.id) };
  await chrome.storage.local.set({ [TELEGRAM_SECRET_KEY]: next });
  return { ...publicTelegramConfig(next), chatName: chat.title || chat.username || chat.first_name || 'conversa encontrada' };
}

function safetyNotificationText(message) {
  const status = String(message.status || 'detected');
  const titles = {
    detected: '⚠️ AVISO DE VIOLAÇÃO DETECTADO',
    close_requested: '🛑 ENCERRAMENTO AUTOMÁTICO INICIADO',
    closed: '✅ LIVE FECHADA POR AVISO DE VIOLAÇÃO',
    platform_closed: '⛔ LIVE ENCERRADA PELO TIKTOK',
    close_failed: '🚨 FALHA AO FECHAR A LIVE'
  };
  const lines = [titles[status] || titles.detected];
  const snippet = String(message.snippet || '').replace(/\s+/g, ' ').trim().slice(0, 700);
  if (snippet) lines.push(`Aviso: ${snippet}`);
  if (status === 'detected') {
    lines.push(message.autoEnd ? 'Ação: o encerramento automático está ativado.' : 'Ação: somente aviso; encerramento automático desativado.');
  } else if (status === 'close_requested') {
    const seconds = Math.max(0, Math.min(300, Number(message.confirmSeconds) || 0));
    lines.push(seconds ? `Ação: fechamento programado em ${seconds}s.` : 'Ação: fechamento imediato solicitado.');
  } else if (status === 'closed') {
    lines.push('Resultado: a extensão confirmou que a live saiu do ar.');
  } else if (status === 'platform_closed') {
    lines.push('Resultado: a live já estava fora do ar quando o aviso foi processado.');
  } else if (status === 'close_failed') {
    lines.push('Resultado: a live ainda parece estar no ar. Feche manualmente agora.');
  }
  if (message.pageUrl) lines.push(`Página: ${String(message.pageUrl).slice(0, 500)}`);
  const detectedAt = Number(message.detectedAt) || Date.now();
  lines.push(`Horário: ${new Date(detectedAt).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`);
  return lines.join('\n');
}

function saleNotificationText(message) {
  const lines = [message.source === 'manual' ? '💰 VENDA MANUAL REGISTRADA' : '🛍️ NOVA VENDA DETECTADA'];
  const productName = String(message.product?.name || message.productName || '').trim();
  if (productName) lines.push(`Produto: ${productName}`);
  if (Number(message.orderDelta) > 1) lines.push(`Novos pedidos: ${Number(message.orderDelta)}`);
  if (Number.isFinite(Number(message.totalOrders))) lines.push(`Pedidos no painel: ${Number(message.totalOrders)}`);
  if (Number(message.value) > 0) lines.push(`Valor detectado: ${Number(message.value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`);
  if (Number.isFinite(Number(message.totalGmv))) lines.push(`GMV: ${Number(message.totalGmv).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`);
  if (Number.isFinite(Number(message.pendingOrders))) lines.push(`Pendentes: ${Number(message.pendingOrders)}`);
  if (Number.isFinite(Number(message.cancelledOrders))) lines.push(`Cancelados: ${Number(message.cancelledOrders)}`);
  lines.push(`Horário: ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`);
  return lines.join('\n');
}

let telegramPollingActive = false;
let lastUpdateId = 0;

const LIVE_URLS = ['*://*.tiktok.com/*', '*://*.tiktokshop.com/*', '*://seller.tiktok.com/*', '*://*.seller.tiktokshop.com/*'];

async function sendToLive(message) {
  const tabs = await chrome.tabs.query({ url: LIVE_URLS });
  const results = await Promise.allSettled(tabs.filter((tab) => tab.id).map((tab) => chrome.tabs.sendMessage(tab.id, message)));
  return results.filter((result) => result.status === 'fulfilled' && result.value?.ok !== false).map((result) => result.value);
}

async function sendToFirstLive(message) {
  const tabs = await chrome.tabs.query({ url: LIVE_URLS });
  for (const tab of tabs) {
    if (!tab.id) continue;
    try {
      const response = await chrome.tabs.sendMessage(tab.id, message);
      if (response?.ok !== false) return response || { ok: true };
    } catch {}
  }
  return null;
}

async function playerCommand(command) {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'LIVEWEL_PLAYER_COMMAND', command });
    return response?.ok === true;
  } catch {
    return false;
  }
}

async function audioRemoteCommand(command) {
  try {
    const service = globalThis.LiveWelAudioService;
    if (!service?.command) return false;
    const response = await service.command(command);
    return response?.ok === true;
  } catch {
    return false;
  }
}

async function localStudioCommand(type, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type, url: 'http://127.0.0.1:18765/', ...payload });
  if (!response?.ok) throw new Error(response?.error || response?.data?.error || 'O LiveStudioCAM não respondeu.');
  return response.data || {};
}

async function updateCommandCenterSettings(patch) {
  const stored = await chrome.storage.local.get('liveosCommandCenterV1');
  const current = stored.liveosCommandCenterV1 || { version: 1 };
  const next = { ...current, settings: { ...(current.settings || {}), ...patch } };
  await chrome.storage.local.set({ liveosCommandCenterV1: next });
  return next.settings;
}

async function replyCommandResult(config, success, successText, failureText) {
  await sendTelegramText(config, success ? successText : `⚠️ ${failureText}`);
  return success;
}

function parseMoneyArgument(value) {
  const cleaned = String(value || '').replace(/[^0-9.,-]/g, '');
  const comma = cleaned.lastIndexOf(',');
  const dot = cleaned.lastIndexOf('.');
  let normalized = cleaned;
  if (comma >= 0 && dot >= 0) {
    normalized = comma > dot
      ? cleaned.replace(/\./g, '').replace(',', '.')
      : cleaned.replace(/,/g, '');
  } else if (comma >= 0) {
    normalized = /,\d{1,2}$/.test(cleaned) ? cleaned.replace(/\./g, '').replace(',', '.') : cleaned.replace(/,/g, '');
  } else if (dot >= 0) {
    normalized = /\.\d{1,2}$/.test(cleaned) ? cleaned.replace(/,/g, '') : cleaned.replace(/\./g, '');
  }
  const parsed = Number.parseFloat(normalized);
  return Number.isFinite(parsed) ? Math.round(parsed * 100) / 100 : 0;
}

function isMoneySelector(value) {
  const cleaned = String(value || '').trim().toUpperCase().replace('R$', '').trim();
  return /^-?(?:(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d{1,2})?|\d+(?:\.\d{1,2})?)$/.test(cleaned);
}

function formatBrl(value) {
  return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function normalizeSearchTerm(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ').trim();
}

function productName(product, index = 0) {
  return String(product?.name || product?.title || product?.label || `Produto ${index + 1}`).replace(/\s+/g, ' ').trim();
}

function findProducts(products, query) {
  const needle = normalizeSearchTerm(query);
  if (!needle) return [];
  return products.map((product, index) => ({ product, index, name: productName(product, index) })).filter((item) => {
    const fields = [item.name, item.product?.id, item.product?.shopProductId, item.product?.sku].map(normalizeSearchTerm);
    return fields.some((field) => field.includes(needle));
  });
}

function formatProductPrice(value) {
  if (typeof value === 'number') return formatBrl(value);
  const text = String(value || '').trim();
  return text || 'não informado';
}

function formatDateTime(value) {
  const numeric = Number(value);
  const date = Number.isFinite(numeric) && numeric > 0 ? new Date(numeric) : new Date(value);
  return Number.isNaN(date.getTime()) ? 'sem horário' : date.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
}

function formatDurationMs(value) {
  const totalSeconds = Math.max(0, Math.floor(Number(value || 0) / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return hours ? `${hours}h ${minutes}m ${seconds}s` : `${minutes}m ${seconds}s`;
}

function normalizeTelegramHistory(value) {
  return Array.isArray(value) ? value.filter((entry) => entry && Number(entry.at) > 0).slice(-100) : [];
}

async function appendTelegramHistory(entry) {
  const stored = await chrome.storage.local.get(TELEGRAM_HISTORY_KEY);
  const history = normalizeTelegramHistory(stored[TELEGRAM_HISTORY_KEY]);
  history.push({ id: `h${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, at: Date.now(), ...entry });
  await chrome.storage.local.set({ [TELEGRAM_HISTORY_KEY]: history.slice(-100) });
}

function alertStatusText(config) {
  return [
    '🔔 ALERTAS DO TELEGRAM',
    `Vendas detectadas: ${config.notifyDetected !== false ? 'ligado ✅' : 'desligado ❌'}`,
    `Vendas manuais: ${config.notifyManual !== false ? 'ligado ✅' : 'desligado ❌'}`,
    `Segurança: ${config.notifySafety !== false ? 'ligado ✅' : 'desligado ❌'}`,
    '',
    'Altere com /alertas vendas on|off, /alertas manuais on|off ou /alertas seguranca on|off.'
  ].join('\n');
}

function parseOnOff(value) {
  const normalized = normalizeSearchTerm(value);
  if (['on', 'ligar', 'ligado', 'ativar', 'ativo', '1'].includes(normalized)) return true;
  if (['off', 'desligar', 'desligado', 'desativar', 'inativo', '0'].includes(normalized)) return false;
  return null;
}

async function requestConfirmation(config, action, label, senderName = '') {
  const pending = {
    action,
    label,
    chatId: String(config.chatId || ''),
    senderName: String(senderName || ''),
    createdAt: Date.now(),
    expiresAt: Date.now() + TELEGRAM_PENDING_TTL_MS
  };
  await chrome.storage.local.set({ [TELEGRAM_PENDING_ACTION_KEY]: pending });
  await sendTelegramText(config, [
    `⚠️ CONFIRMAÇÃO NECESSÁRIA`,
    label,
    '',
    'Envie /confirmar em até 2 minutos para executar.',
    'Envie /cancelar para desistir.'
  ].join('\n'));
}

async function readPendingAction(config) {
  const stored = await chrome.storage.local.get(TELEGRAM_PENDING_ACTION_KEY);
  const pending = stored[TELEGRAM_PENDING_ACTION_KEY];
  if (!pending || String(pending.chatId) !== String(config.chatId) || Number(pending.expiresAt) <= Date.now()) {
    if (pending) await chrome.storage.local.remove(TELEGRAM_PENDING_ACTION_KEY);
    return null;
  }
  return pending;
}

async function executePendingAction(config, pending) {
  await chrome.storage.local.remove(TELEGRAM_PENDING_ACTION_KEY);
  if (pending.action === 'clear_queue') {
    await chrome.storage.local.set({ playlist: [], currentIndex: 0, playlistRunning: false });
    await sendToLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'clear-queue', payload: {} });
    await appendTelegramHistory({ type: 'queue_cleared', message: 'Fila de produtos limpa pelo Telegram.' });
    return '🧹 Fila de produtos limpa. Todos os itens foram removidos.';
  }
  if (pending.action === 'zero_gmv') {
    const before = await chrome.storage.local.get(['gmvCurrent', 'gmvOrders']);
    const at = Date.now();
    await chrome.storage.local.set({
      gmvCurrent: 0,
      gmvOrders: 0,
      gmvHistory: [],
      lastSaleNotifyGmv: 0,
      lastSaleNotifyOrders: 0,
      [TELEGRAM_MANUAL_SALES_KEY]: [],
      lastManualSaleAt: 0,
      lastManualSaleValue: 0,
      lastManualSaleId: '',
      lastManualSaleRevertedAt: at
    });
    await appendTelegramHistory({
      type: 'gmv_reset',
      message: `GMV zerado; antes havia ${formatBrl(before.gmvCurrent)} e ${Number(before.gmvOrders || 0)} pedido(s).`
    });
    return '♻️ GMV e pedidos zerados. As vendas manuais ativas também foram limpas.';
  }
  if (pending.action === 'run_cycle') {
    const stored = await chrome.storage.local.get('livewelCycleConfig');
    if (stored.livewelCycleConfig?.enabled !== true) return '⚠️ O ciclo automático está desativado. Ative e configure pelo painel antes de executá-lo.';
    const result = await sendToFirstLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'run-cycle', payload: {} });
    if (!result) return '⚠️ Nenhuma página da LIVE recebeu o comando de ciclo.';
    await appendTelegramHistory({ type: 'cycle_requested', message: 'Ciclo imediato solicitado pelo Telegram.' });
    return '🔄 Ciclo imediato solicitado. Acompanhe o andamento com /ciclo.';
  }
  return '⚠️ A ação pendente não é mais reconhecida.';
}

function normalizeManualSales(value) {
  return Array.isArray(value)
    ? value.filter((sale) => sale?.id && Number(sale.value) > 0).slice(-100)
    : [];
}

async function registerManualSale(value) {
  const store = await chrome.storage.local.get(['gmvCurrent', 'gmvOrders', TELEGRAM_MANUAL_SALES_KEY]);
  const nextGmv = Math.max(0, Number(store.gmvCurrent) || 0) + value;
  const nextOrders = Math.max(0, Number(store.gmvOrders) || 0) + 1;
  const at = Date.now();
  const sale = {
    id: `v${at.toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    value,
    at,
    removedAt: 0,
    source: 'telegram'
  };
  const sales = [...normalizeManualSales(store[TELEGRAM_MANUAL_SALES_KEY]), sale].slice(-100);
  await chrome.storage.local.set({
    gmvCurrent: nextGmv,
    gmvOrders: nextOrders,
    [TELEGRAM_MANUAL_SALES_KEY]: sales,
    lastManualSaleAt: at,
    lastManualSaleValue: value,
    lastManualSaleId: sale.id,
    lastManualSaleRevertedAt: 0
  });
  await appendTelegramHistory({
    type: 'manual_sale',
    saleId: sale.id,
    value,
    message: `Venda manual ${sale.id} registrada: ${formatBrl(value)}.`
  });
  return { sale, nextGmv, nextOrders };
}

async function removeManualSale(selector = '') {
  const store = await chrome.storage.local.get([
    'gmvCurrent', 'gmvOrders', 'lastManualSaleAt', 'lastManualSaleValue',
    'lastManualSaleId', 'lastManualSaleRevertedAt', TELEGRAM_MANUAL_SALES_KEY
  ]);
  const sales = normalizeManualSales(store[TELEGRAM_MANUAL_SALES_KEY]);
  const active = sales.filter((sale) => !sale.removedAt);
  const requestedId = String(selector || '').trim().toLowerCase();
  const requestedValue = isMoneySelector(selector) ? parseMoneyArgument(selector) : 0;
  let sale = requestedId
    ? [...active].reverse().find((item) => String(item.id).toLowerCase() === requestedId)
      || (requestedValue > 0 ? [...active].reverse().find((item) => Math.abs(Number(item.value) - requestedValue) < .005) : null)
    : active.at(-1);
  let legacy = false;
  if (!sale && Number(store.lastManualSaleValue) > 0 && !Number(store.lastManualSaleRevertedAt)) {
    const legacyValue = Number(store.lastManualSaleValue);
    if (!requestedId || requestedValue <= 0 || Math.abs(legacyValue - requestedValue) < .005) {
      legacy = true;
      sale = {
        id: String(store.lastManualSaleId || 'venda-legada'),
        value: legacyValue,
        at: Number(store.lastManualSaleAt) || Date.now()
      };
    }
  }
  if (!sale && requestedValue > 0) {
    legacy = true;
    sale = { id: 'ajuste-manual', value: requestedValue, at: Date.now() };
  }
  if (!sale) return { ok: false, error: 'Nenhuma venda manual ativa foi encontrada para remover.' };

  const removedAt = Date.now();
  if (!legacy) {
    const storedSale = sales.find((item) => item.id === sale.id);
    if (storedSale) storedSale.removedAt = removedAt;
  }
  const nextGmv = Math.max(0, (Number(store.gmvCurrent) || 0) - Number(sale.value));
  const nextOrders = Math.max(0, (Number(store.gmvOrders) || 0) - 1);
  const remaining = sales.filter((item) => !item.removedAt).at(-1);
  await chrome.storage.local.set({
    gmvCurrent: Math.round(nextGmv * 100) / 100,
    gmvOrders: nextOrders,
    [TELEGRAM_MANUAL_SALES_KEY]: sales,
    lastManualSaleValue: Number(remaining?.value) || 0,
    lastManualSaleId: remaining?.id || '',
    lastManualSaleAt: Number(remaining?.at) || 0,
    lastManualSaleRevertedAt: removedAt
  });
  await appendTelegramHistory({
    type: 'manual_sale_removed',
    saleId: sale.id,
    value: Number(sale.value),
    message: `Venda manual ${sale.id} removida: ${formatBrl(sale.value)}.`
  });
  return { ok: true, sale, nextGmv, nextOrders };
}

async function manualSalesText() {
  const store = await chrome.storage.local.get([TELEGRAM_MANUAL_SALES_KEY, 'lastManualSaleAt', 'lastManualSaleValue', 'lastManualSaleRevertedAt']);
  const sales = normalizeManualSales(store[TELEGRAM_MANUAL_SALES_KEY]);
  if (!sales.length && Number(store.lastManualSaleValue) > 0) {
    sales.push({ id: 'venda-legada', value: Number(store.lastManualSaleValue), at: Number(store.lastManualSaleAt) || 0, removedAt: Number(store.lastManualSaleRevertedAt) || 0 });
  }
  if (!sales.length) return '🧾 Nenhuma venda manual registrada pelo Telegram.';
  const rows = sales.slice(-8).reverse().map((sale) => {
    const time = sale.at ? new Date(sale.at).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : 'sem horário';
    return `${sale.removedAt ? '↩️ removida' : '✅ ativa'} · ${sale.id} · ${formatBrl(sale.value)} · ${time}`;
  });
  return ['🧾 VENDAS MANUAIS', ...rows, '', 'Use /desfazervenda para remover a última ativa ou /removervenda <id ou valor>.'].join('\n');
}

function productDetailsText(product, index, total) {
  if (!product) return '📦 Nenhum produto está selecionado. Importe a fila no painel primeiro.';
  const rows = [
    '📌 PRODUTO ATUAL',
    `Posição: #${index + 1} de ${total}`,
    `Nome: ${productName(product, index)}`,
    `Preço: ${formatProductPrice(product.price)}`
  ];
  if (product.compareAt) rows.push(`De: ${formatProductPrice(product.compareAt)}`);
  if (product.stock != null && product.stock !== '') rows.push(`Estoque: ${product.stock}`);
  if (product.coupon) rows.push(`Cupom: ${String(product.coupon).slice(0, 120)}`);
  if (product.shipping) rows.push(`Frete: ${String(product.shipping).slice(0, 120)}`);
  const id = product.shopProductId || product.id || product.sku;
  if (id) rows.push(`ID: ${String(id).slice(0, 100)}`);
  return rows.join('\n');
}

function goalStatusText(store) {
  const gmv = Math.max(0, Number(store.gmvCurrent) || 0);
  const goal = Math.max(0, Number(store.gmvGoal) || 0);
  if (!(goal > 0)) return '🎯 Nenhuma meta definida. Use /meta 5000 para cadastrar.';
  const missing = Math.max(0, goal - gmv);
  const percent = Math.min(999, Math.max(0, gmv / goal * 100));
  return [
    '🎯 META DE GMV',
    `Meta: ${formatBrl(goal)}`,
    `Realizado: ${formatBrl(gmv)} (${percent.toFixed(1).replace('.', ',')}%)`,
    missing > 0 ? `Falta: ${formatBrl(missing)}` : `Meta atingida! Acima em ${formatBrl(gmv - goal)} ✅`
  ].join('\n');
}

function cycleStatusText(config = {}) {
  const enabled = config.enabled === true;
  const duration = Math.max(60_000, ((Number(config.hours) || 0) * 60 + (Number(config.minutes) || 0)) * 60_000);
  const remaining = enabled
    ? Math.max(0, Number(config.startedAt || Date.now()) + duration - Date.now())
    : Math.max(0, Number(config.pausedRemainingMs) || 0);
  const products = String(config.products || '').split(/\r?\n|,/).map((item) => item.trim()).filter(Boolean);
  const rows = [
    '🔄 CICLO AUTOMÁTICO',
    `Estado: ${enabled ? 'ativado ✅' : config.pausedRemainingMs ? 'pausado ⏸️' : 'desativado ❌'}`,
    `Intervalo: ${formatDurationMs(duration)}`,
    `Tempo restante: ${formatDurationMs(remaining)}`,
    `Produtos configurados: ${products.length}`,
    `Último estado: ${config.lastStatus || 'sem registro'}`
  ];
  if (config.lastError) rows.push(`Último erro: ${String(config.lastError).slice(0, 300)}`);
  rows.push('', 'Para executar antes da hora: /ciclo agora (exige confirmação).');
  return rows.join('\n');
}

async function securityStatusText(config) {
  const store = await chrome.storage.local.get([
    'violationAutoEnd', 'violationConfirmSeconds', 'lastViolationAt', 'lastViolationSnippet',
    'liveEmergencyKillTriggered', 'livewelModerationConfig', 'livewelModerationLog'
  ]);
  const moderation = store.livewelModerationConfig || {};
  const log = Array.isArray(store.livewelModerationLog) ? store.livewelModerationLog : [];
  const lastBlock = log.at(-1);
  const rows = [
    '🛡️ SEGURANÇA DA LIVE',
    `Encerramento por violação: ${store.violationAutoEnd !== false ? 'ativado ✅' : 'desativado ❌'}`,
    `Confirmação: ${Math.max(0, Number(store.violationConfirmSeconds) || 0)}s`,
    `Alertas no Telegram: ${config.notifySafety !== false ? 'ligados ✅' : 'desligados ❌'}`,
    `Bloqueio de perfis: ${moderation.enabled === true ? 'ativado ✅' : 'desativado ❌'}`,
    `Perfis cadastrados: ${Array.isArray(moderation.profiles) ? moderation.profiles.length : 0}`
  ];
  if (store.lastViolationAt) rows.push(`Último aviso: ${formatDateTime(store.lastViolationAt)}`);
  if (store.lastViolationSnippet) rows.push(`Detalhe: ${String(store.lastViolationSnippet).replace(/\s+/g, ' ').slice(0, 300)}`);
  if (lastBlock) rows.push(`Último bloqueio: ${lastBlock.ok ? 'confirmado' : 'não localizado'} · ${lastBlock.author || 'perfil'} · ${formatDateTime(lastBlock.at)}`);
  if (store.liveEmergencyKillTriggered) rows.push(`Último pânico: ${formatDateTime(store.liveEmergencyKillTriggered)}`);
  return rows.join('\n');
}

async function operationSummaryText(config) {
  const store = await chrome.storage.local.get(null);
  const products = Array.isArray(store.playlist) ? store.playlist : [];
  const index = products.length ? Math.min(products.length - 1, Math.max(0, Number(store.currentIndex) || 0)) : 0;
  const product = products[index];
  const goal = Math.max(0, Number(store.gmvGoal) || 0);
  const gmv = Math.max(0, Number(store.gmvCurrent) || 0);
  const missing = Math.max(0, goal - gmv);
  const audio = store.livewelAudioStatus || {};
  const cycle = store.livewelCycleConfig || {};
  return [
    '📋 RESUMO DA OPERAÇÃO',
    `LIVE: ${store.liveOnAir === true ? 'no ar 🟢' : store.liveOnAir === false ? 'fora do ar 🔴' : 'não confirmada ⚪'}`,
    `GMV: ${formatBrl(gmv)} · Pedidos: ${Math.max(0, Number(store.gmvOrders) || 0)}`,
    goal > 0 ? `Meta: ${formatBrl(goal)} · ${missing > 0 ? `faltam ${formatBrl(missing)}` : 'atingida ✅'}` : 'Meta: não definida',
    `Produto: ${product ? `#${index + 1}/${products.length} ${productName(product, index).slice(0, 100)}` : 'fila vazia'}`,
    `Player: ${store.livewelPlayerOnline && Date.now() - Number(store.livewelPlayerUpdatedAt || 0) < 10_000 ? 'online ✅' : 'offline ❌'}`,
    `Áudio: ${audio.playing ? `tocando ${String(audio.currentTrackName || '').slice(0, 80) || 'faixa atual'} ▶️` : 'pausado ⏸️'}`,
    `Proteção: ${store.violationAutoEnd !== false ? 'ativada ✅' : 'desativada ❌'}`,
    `Ciclo: ${cycle.enabled === true ? 'ativado ✅' : 'desativado ❌'}`,
    `Alertas: vendas ${config.notifyDetected !== false ? 'ON' : 'OFF'} · segurança ${config.notifySafety !== false ? 'ON' : 'OFF'}`
  ].join('\n');
}

async function diagnosticText(config) {
  const [tabs, store] = await Promise.all([
    chrome.tabs.query({ url: LIVE_URLS }).catch(() => []),
    chrome.storage.local.get(null)
  ]);
  const now = Date.now();
  const playerFresh = store.livewelPlayerOnline && now - Number(store.livewelPlayerUpdatedAt || 0) < 10_000;
  const frameFresh = Number(store.livewelCameraFrameAt) > 0 && now - Number(store.livewelCameraFrameAt) < 3_500;
  const audio = store.livewelAudioStatus || {};
  const products = Array.isArray(store.playlist) ? store.playlist : [];
  const cycle = store.livewelCycleConfig || {};
  const rows = [
    '🩺 DIAGNÓSTICO RÁPIDO',
    `Bot: ${config.botToken && config.chatId ? 'configurado ✅' : 'incompleto ❌'}`,
    `Páginas TikTok abertas: ${tabs.length}${tabs.length ? ' ✅' : ' ❌'}`,
    `Player: ${playerFresh ? 'online ✅' : 'offline ou sem atualização ❌'}`,
    `Câmera virtual: ${frameFresh ? 'quadros recentes ✅' : 'sem confirmação recente ⚠️'}`,
    `Áudio: ${audio.playing ? 'reproduzindo ✅' : 'pausado ou sem resposta ⚠️'}`,
    `Fila de produtos: ${products.length} item(ns)${products.length ? ' ✅' : ' ⚠️'}`,
    `Proteção: ${store.violationAutoEnd !== false ? 'ativada ✅' : 'desativada ⚠️'}`,
    `Ciclo: ${cycle.enabled === true ? 'ativado' : 'desativado'}`
  ];
  if (store.livewelPlayerTake) rows.push(`Take atual: ${String(store.livewelPlayerTake).slice(0, 120)}`);
  if (cycle.lastError) rows.push(`Erro do ciclo: ${String(cycle.lastError).slice(0, 300)}`);
  rows.push('', 'Este diagnóstico apenas consulta os sinais; não reinicia nenhum motor.');
  return rows.join('\n');
}

async function historyText() {
  const store = await chrome.storage.local.get([TELEGRAM_HISTORY_KEY, TELEGRAM_MANUAL_SALES_KEY, 'gmvHistory']);
  const own = normalizeTelegramHistory(store[TELEGRAM_HISTORY_KEY]).map((entry) => ({
    at: Number(entry.at),
    message: String(entry.message || entry.type || 'Ação registrada')
  }));
  const recordedSaleIds = new Set(normalizeTelegramHistory(store[TELEGRAM_HISTORY_KEY]).map((entry) => entry.saleId).filter(Boolean));
  const sales = normalizeManualSales(store[TELEGRAM_MANUAL_SALES_KEY])
    .filter((sale) => !recordedSaleIds.has(sale.id))
    .map((sale) => ({
      at: Number(sale.removedAt || sale.at),
      message: `${sale.removedAt ? 'Venda removida' : 'Venda manual'} ${sale.id}: ${formatBrl(sale.value)}.`
    }));
  const metrics = (Array.isArray(store.gmvHistory) ? store.gmvHistory : []).map((sample) => {
    if (typeof sample === 'number') return { at: 0, message: `Amostra de GMV: ${formatBrl(sample)}.` };
    const value = Number(sample?.gmv ?? sample?.value ?? sample?.totalGmv);
    const orders = Number(sample?.orders ?? sample?.totalOrders);
    if (!Number.isFinite(value) && !Number.isFinite(orders)) return null;
    return {
      at: Number(sample?.at ?? sample?.timestamp ?? sample?.time) || 0,
      message: `Métrica: ${Number.isFinite(value) ? formatBrl(value) : 'GMV indisponível'}${Number.isFinite(orders) ? ` · ${orders} pedido(s)` : ''}.`
    };
  }).filter(Boolean);
  const entries = [...own, ...sales, ...metrics].sort((a, b) => Number(b.at) - Number(a.at)).slice(0, 12);
  if (!entries.length) return '🕘 Nenhum histórico de vendas, GMV ou ações do Telegram foi registrado ainda.';
  return ['🕘 HISTÓRICO RECENTE', ...entries.map((entry) => `${entry.at ? formatDateTime(entry.at) : 'sem horário'} · ${entry.message}`)].join('\n');
}

async function executeRemoteCommand(config, text, senderName) {
  const trimmed = String(text || '').trim();
  if (!trimmed.startsWith('/')) return;
  const parts = trimmed.split(/\s+/);
  const cmd = parts[0].toLowerCase().replace(/@\w+$/, '');
  const arg = parts.slice(1).join(' ').trim();

  try {
    if (cmd === '/start' || cmd === '/ajuda' || cmd === '/help') {
      const msg = [
        '📱 LIVEWELPRO — CONTROLE REMOTO',
        '',
        'CONSULTAS',
        '/resumo — visão completa da operação',
        '/status — GMV, pedidos e proteção',
        '/produto — detalhes do produto atual',
        '/produtos — lista a fila',
        '/buscarproduto nome — procura na fila',
        '/faltameta — progresso da meta',
        '/audio — faixa e estado do áudio',
        '/seguranca — proteção e último aviso',
        '/ciclo — programação do ciclo',
        '/diagnostico — saúde da operação',
        '/historico — eventos recentes',
        '',
        'PRODUTOS E REPRODUÇÃO',
        '/pin 2 ou /pin nome — fixa um produto',
        '/proximo — avança produto e take',
        '/anterior — volta ao produto anterior',
        '/play — inicia vídeo e áudio',
        '/pausa — pausa vídeo e áudio',
        '/timer — reinicia o cronômetro da oferta',
        '/cenas — lista as cenas do OBS',
        '/cena nome ou número — troca a cena',
        '/destaque — salva o Replay Buffer do OBS',
        '/camera — reinicia a câmera virtual',
        '/telemetria — mostra FPS, drops e reinícios',
        '/perfil 720 ou /perfil fraco — qualidade a 30 FPS',
        '',
        'VENDAS E META',
        '/meta 5000 — define a meta de GMV',
        '/venda 79,90 — registra venda manual',
        '/vendas — lista vendas e IDs',
        '/desfazervenda — remove a última venda',
        '/removervenda id — remove uma específica',
        '',
        'INTERAÇÃO E ALERTAS',
        '/comentario texto — publica na live',
        '/auto on|off — comentários periódicos',
        '/respostas on|off — respostas a espectadores',
        '/bloquear @perfil — cadastra e tenta bloquear',
        '/alertas — consulta as notificações',
        '/alertas vendas on|off — altera vendas',
        '',
        'AÇÕES COM CONFIRMAÇÃO',
        '/limparfila — remove todos os produtos',
        '/zerargmv — zera GMV e pedidos',
        '/ciclo agora — executa o ciclo agora',
        '/confirmar — executa a ação pendente',
        '/cancelar — descarta a ação pendente',
        '',
        '/panic — 🛑 solicita encerramento imediato',
        '',
        'As confirmações expiram em 2 minutos.'
      ].join('\n');
      await sendTelegramText(config, msg);
      return;
    }

    if (cmd === '/cancelar' || cmd === '/cancel') {
      const pending = await readPendingAction(config);
      if (!pending) {
        await sendTelegramText(config, 'ℹ️ Não há nenhuma ação pendente para cancelar.');
        return;
      }
      await chrome.storage.local.remove(TELEGRAM_PENDING_ACTION_KEY);
      await sendTelegramText(config, `✅ Ação cancelada: ${pending.label}`);
      return;
    }

    if (cmd === '/confirmar' || cmd === '/confirm') {
      const pending = await readPendingAction(config);
      if (!pending) {
        await sendTelegramText(config, '⚠️ Não há ação pendente ou a confirmação expirou. Envie o comando novamente.');
        return;
      }
      await sendTelegramText(config, await executePendingAction(config, pending));
      return;
    }

    if (cmd === '/limparfila' || cmd === '/clearqueue') {
      await requestConfirmation(config, 'clear_queue', 'Remover TODOS os produtos da fila?', senderName);
      return;
    }

    if (cmd === '/zerargmv' || cmd === '/resetgmv') {
      await requestConfirmation(config, 'zero_gmv', 'Zerar GMV, pedidos e vendas manuais ativas?', senderName);
      return;
    }

    if (cmd === '/resumo' || cmd === '/summary') {
      await sendTelegramText(config, await operationSummaryText(config));
      return;
    }

    if (cmd === '/meta' || cmd === '/goal') {
      const goal = parseMoneyArgument(arg);
      if (!(goal > 0)) {
        await sendTelegramText(config, '⚠️ Informe uma meta maior que zero. Exemplo: /meta 5000');
        return;
      }
      await chrome.storage.local.set({ gmvGoal: goal });
      await appendTelegramHistory({ type: 'goal_set', value: goal, message: `Meta de GMV definida em ${formatBrl(goal)}.` });
      const store = await chrome.storage.local.get(['gmvCurrent', 'gmvGoal']);
      await sendTelegramText(config, `✅ Meta atualizada.\n\n${goalStatusText(store)}`);
      return;
    }

    if (cmd === '/faltameta' || cmd === '/remaininggoal') {
      const store = await chrome.storage.local.get(['gmvCurrent', 'gmvGoal']);
      await sendTelegramText(config, goalStatusText(store));
      return;
    }

    if (cmd === '/produto' || cmd === '/product') {
      const store = await chrome.storage.local.get(['playlist', 'currentIndex']);
      const products = Array.isArray(store.playlist) ? store.playlist : [];
      const index = products.length ? Math.min(products.length - 1, Math.max(0, Number(store.currentIndex) || 0)) : 0;
      await sendTelegramText(config, productDetailsText(products[index], index, products.length));
      return;
    }

    if (cmd === '/buscarproduto' || cmd === '/buscar' || cmd === '/findproduct') {
      if (!arg) {
        await sendTelegramText(config, '⚠️ Informe parte do nome ou o ID. Exemplo: /buscarproduto escova');
        return;
      }
      const store = await chrome.storage.local.get('playlist');
      const products = Array.isArray(store.playlist) ? store.playlist : [];
      const matches = findProducts(products, arg).slice(0, 10);
      if (!matches.length) {
        await sendTelegramText(config, `🔎 Nenhum produto encontrado para “${arg.slice(0, 100)}”.`);
        return;
      }
      await sendTelegramText(config, [
        `🔎 RESULTADOS PARA “${arg.slice(0, 100)}”`,
        ...matches.map((item) => `#${item.index + 1} · ${item.name.slice(0, 100)} · ${formatProductPrice(item.product?.price)}`),
        '',
        'Use /pin <número ou nome> para fixar.'
      ].join('\n'));
      return;
    }

    if (cmd === '/kill' || cmd === '/panic' || cmd === '/panico' || cmd === '/stop') {
      await chrome.storage.local.set({
        liveEmergencyKillTriggered: Date.now(),
        lastViolationAt: new Date().toISOString(),
        lastViolationSnippet: '🛑 Encerramento de emergência solicitado pelo Telegram mobile.'
      });
      const delivered = await sendToLive({ type: 'LIVEOS_EMERGENCY_KILL', requestedBy: senderName || 'Telegram' });
      await replyCommandResult(config, delivered.length > 0,
        '🛑 Encerramento de emergência solicitado. Aguarde a mensagem de confirmação de que a LIVE saiu do ar.',
        'Nenhuma página da LIVE recebeu o comando de emergência. Abra o gerenciador da LIVE e tente novamente.');
      return;
    }

    if (cmd === '/proximo' || cmd === '/next' || cmd === '/nextproduct') {
      const store = await chrome.storage.local.get(['playlist', 'currentIndex']);
      const total = Array.isArray(store.playlist) ? store.playlist.length : 0;
      const nextIndex = total ? (Math.max(0, Number(store.currentIndex) || 0) + 1) % total : 0;
      const [liveResults, playerOk] = await Promise.all([
        sendToLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'pin-position', payload: { position: nextIndex + 1 } }),
        playerCommand('NEXT')
      ]);
      if (total && liveResults.length) await chrome.storage.local.set({ currentIndex: nextIndex });
      await replyCommandResult(config, liveResults.length > 0 || playerOk,
        `⏩ Próximo take acionado${liveResults.length ? ` e produto #${nextIndex + 1} fixado` : ''}.`,
        'Player e página da LIVE não responderam ao comando Próximo.');
      return;
    }

    if (cmd === '/anterior' || cmd === '/prev' || cmd === '/previous') {
      const store = await chrome.storage.local.get(['playlist', 'currentIndex']);
      const total = Array.isArray(store.playlist) ? store.playlist.length : 0;
      if (!total) {
        await sendTelegramText(config, '⚠️ A fila de produtos está vazia. Importe os produtos no painel primeiro.');
        return;
      }
      const previousIndex = (Math.max(0, Number(store.currentIndex) || 0) - 1 + total) % total;
      const results = await sendToLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'pin-position', payload: { position: previousIndex + 1 } });
      if (results.length) await chrome.storage.local.set({ currentIndex: previousIndex });
      await replyCommandResult(config, results.length > 0, `⏮️ Produto #${previousIndex + 1} fixado.`, 'A página da LIVE não respondeu ao comando Anterior.');
      return;
    }

    if (cmd === '/produtos' || cmd === '/fila' || cmd === '/queue') {
      const store = await chrome.storage.local.get(['playlist', 'currentIndex']);
      const products = Array.isArray(store.playlist) ? store.playlist : [];
      if (!products.length) {
        await sendTelegramText(config, '📦 A fila de produtos está vazia.');
        return;
      }
      const currentIndex = Math.max(0, Number(store.currentIndex) || 0);
      const rows = products.slice(0, 20).map((product, index) => `${index === currentIndex ? '📌' : '▫️'} #${index + 1} ${String(product?.name || product?.title || `Produto ${index + 1}`).slice(0, 90)}`);
      if (products.length > rows.length) rows.push(`… e mais ${products.length - rows.length} produto(s).`);
      await sendTelegramText(config, ['📦 FILA DE PRODUTOS', ...rows].join('\n'));
      return;
    }

    if (cmd === '/pin') {
      const store = await chrome.storage.local.get(['playlist', 'currentIndex']);
      const products = Array.isArray(store.playlist) ? store.playlist : [];
      let idx = /^\d+$/.test(arg) ? Number(arg) : 0;
      let selectedName = '';
      if (!idx && arg) {
        const matches = findProducts(products, arg);
        if (!matches.length) {
          await sendTelegramText(config, `⚠️ Nenhum produto encontrado para “${arg.slice(0, 100)}”. Use /buscarproduto para consultar a fila.`);
          return;
        }
        idx = matches[0].index + 1;
        selectedName = matches[0].name;
      }
      if (!idx || idx < 1) {
        await sendTelegramText(config, '⚠️ Use /pin 1 ou /pin nome do produto.');
        return;
      }
      if (products.length && idx > products.length) {
        await sendTelegramText(config, `⚠️ A fila tem ${products.length} produto(s); a posição #${idx} não existe.`);
        return;
      }
      const results = await sendToLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'pin-position', payload: { position: idx } });
      if (results.length) await chrome.storage.local.set({ currentIndex: idx - 1 });
      await replyCommandResult(config, results.length > 0,
        `📌 Produto #${idx}${selectedName ? ` · ${selectedName.slice(0, 100)}` : ''} fixado na LIVE.`,
        `A página da LIVE não confirmou o produto #${idx}.`);
      return;
    }

    if (cmd === '/comentario' || cmd === '/comment') {
      const comment = arg.replace(/\s+/g, ' ').trim();
      if (!comment) {
        await sendTelegramText(config, '⚠️ Digite a mensagem. Exemplo: /comentario Confira o produto fixado no carrinho!');
        return;
      }
      if (comment.length > 200) {
        await sendTelegramText(config, `⚠️ O comentário tem ${comment.length} caracteres. Envie no máximo 200.`);
        return;
      }
      const result = await sendToFirstLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'send-comment', payload: { text: comment } });
      if (!result) {
        await sendTelegramText(config, '⚠️ Não encontrei uma caixa de comentários ativa na página da LIVE.');
        return;
      }
      await appendTelegramHistory({ type: 'comment_sent', message: `Comentário publicado: “${comment.slice(0, 120)}”.` });
      await sendTelegramText(config, `💬 Comentário publicado na LIVE:\n${comment}`);
      return;
    }

    if (cmd === '/alertas' || cmd === '/alerts') {
      if (!arg) {
        await sendTelegramText(config, alertStatusText(config));
        return;
      }
      const [categoryRaw, switchRaw] = arg.split(/\s+/);
      const category = normalizeSearchTerm(categoryRaw);
      const enabled = parseOnOff(switchRaw);
      if (enabled == null) {
        await sendTelegramText(config, '⚠️ Use: /alertas vendas on|off, /alertas manuais on|off, /alertas seguranca on|off ou /alertas todos on|off.');
        return;
      }
      const patch = {};
      if (['vendas', 'venda', 'sales'].includes(category)) {
        patch.notifyDetected = enabled;
        patch.notifyManual = enabled;
      } else if (['manuais', 'manual'].includes(category)) patch.notifyManual = enabled;
      else if (['detectadas', 'detectados', 'detected'].includes(category)) patch.notifyDetected = enabled;
      else if (['seguranca', 'safety'].includes(category)) patch.notifySafety = enabled;
      else if (['todos', 'tudo', 'all'].includes(category)) {
        patch.notifyDetected = enabled;
        patch.notifyManual = enabled;
        patch.notifySafety = enabled;
      } else {
        await sendTelegramText(config, '⚠️ Categoria inválida. Use vendas, manuais, detectadas, seguranca ou todos.');
        return;
      }
      const next = { ...config, ...patch, savedAt: Date.now() };
      await chrome.storage.local.set({ [TELEGRAM_SECRET_KEY]: next });
      Object.assign(config, patch);
      await appendTelegramHistory({ type: 'alerts_changed', message: `Alertas “${category}” ${enabled ? 'ativados' : 'desativados'} pelo Telegram.` });
      await sendTelegramText(config, `✅ Alertas atualizados.\n\n${alertStatusText(next)}`);
      return;
    }

    if (cmd === '/seguranca' || cmd === '/safety') {
      await sendTelegramText(config, await securityStatusText(config));
      return;
    }

    if (cmd === '/bloquear' || cmd === '/block') {
      const profile = arg.trim().replace(/^@/, '').toLocaleLowerCase('pt-BR');
      if (!/^[\p{L}\p{N}._-]{2,40}$/u.test(profile)) {
        await sendTelegramText(config, '⚠️ Informe um perfil válido. Exemplo: /bloquear @perfil_concorrente');
        return;
      }
      const stored = await chrome.storage.local.get('livewelModerationConfig');
      const current = stored.livewelModerationConfig || {};
      const profiles = [...new Set([...(Array.isArray(current.profiles) ? current.profiles : []).map((item) => String(item).replace(/^@/, '').toLocaleLowerCase('pt-BR')), profile])].slice(-200);
      const moderation = {
        ...current,
        enabled: true,
        keywords: Array.isArray(current.keywords) ? current.keywords : ['achadinhos', 'shop', 'mais barato', 'ofertas'],
        profiles,
        updatedAt: Date.now()
      };
      await chrome.storage.local.set({ livewelModerationConfig: moderation, competitorKeywords: profiles });
      const result = await sendToFirstLive({ type: 'LIVEWEL_DASH_COMMAND', action: 'block-profile', payload: { profile } });
      await appendTelegramHistory({ type: 'profile_blocked', message: `Perfil @${profile} adicionado ao bloqueio.` });
      await sendTelegramText(config, result?.blocked
        ? `🚫 @${profile} foi cadastrado e o bloqueio imediato foi confirmado.`
        : `🚫 @${profile} foi cadastrado. Se não estiver visível agora, será bloqueado automaticamente quando aparecer na LIVE.`);
      return;
    }

    if (cmd === '/ciclo' || cmd === '/cycle') {
      if (['agora', 'now'].includes(normalizeSearchTerm(arg))) {
        await requestConfirmation(config, 'run_cycle', 'Executar o ciclo AGORA? Isso encerra e reinicia a LIVE conforme a configuração salva.', senderName);
        return;
      }
      if (arg) {
        await sendTelegramText(config, '⚠️ Use /ciclo para consultar ou /ciclo agora para executar com confirmação.');
        return;
      }
      const stored = await chrome.storage.local.get('livewelCycleConfig');
      await sendTelegramText(config, cycleStatusText(stored.livewelCycleConfig || {}));
      return;
    }

    if (cmd === '/diagnostico' || cmd === '/diagnostic' || cmd === '/diag') {
      await sendTelegramText(config, await diagnosticText(config));
      return;
    }

    if (cmd === '/historico' || cmd === '/history') {
      await sendTelegramText(config, await historyText());
      return;
    }

    if (cmd === '/play') {
      const [playerOk, audioOk] = await Promise.all([playerCommand('PLAY'), audioRemoteCommand('PLAY')]);
      await replyCommandResult(config, playerOk || audioOk,
        `▶️ Reprodução iniciada${playerOk && audioOk ? ' no vídeo e no áudio' : playerOk ? ' no vídeo' : ' no áudio'}.`,
        'O Player e o motor de áudio não responderam. Abra o Estúdio primeiro.');
      return;
    }

    if (cmd === '/pausa' || cmd === '/pause') {
      const [playerOk, audioOk] = await Promise.all([playerCommand('PAUSE'), audioRemoteCommand('PAUSE')]);
      await replyCommandResult(config, playerOk || audioOk, '⏸️ Reprodução pausada.', 'Nenhum motor de reprodução respondeu ao comando Pausa.');
      return;
    }

    if (cmd === '/timer' || cmd === '/reset_timer' || cmd === '/oferta') {
      const ok = await playerCommand('RESET_TIMER');
      await replyCommandResult(config, ok, '⏱️ Cronômetro de oferta reiniciado.', 'O Player não estava aberto para reiniciar o cronômetro.');
      return;
    }

    if (cmd === '/venda' || cmd === '/sale') {
      const val = parseMoneyArgument(arg);
      if (!(val > 0)) {
        await sendTelegramText(config, '⚠️ Informe um valor maior que zero. Exemplo: /venda 79,90');
        return;
      }
      const { sale, nextGmv, nextOrders } = await registerManualSale(val);
      await sendTelegramText(config, [
        '💰 VENDA MANUAL REGISTRADA',
        `ID: ${sale.id}`,
        `Valor: ${formatBrl(val)}`,
        `Pedidos: ${nextOrders}`,
        `GMV: ${formatBrl(nextGmv)}`,
        'Para desfazer agora: /desfazervenda'
      ].join('\n'));
      return;
    }

    if (cmd === '/vendas' || cmd === '/sales') {
      await sendTelegramText(config, await manualSalesText());
      return;
    }

    if (cmd === '/desfazervenda' || cmd === '/undovenda' || cmd === '/removervenda' || cmd === '/delvenda') {
      const result = await removeManualSale(arg);
      if (!result.ok) {
        await sendTelegramText(config, `⚠️ ${result.error}`);
        return;
      }
      await sendTelegramText(config, [
        '↩️ VENDA MANUAL REMOVIDA',
        `ID: ${result.sale.id}`,
        `Valor removido: ${formatBrl(result.sale.value)}`,
        `Pedidos: ${result.nextOrders}`,
        `GMV: ${formatBrl(result.nextGmv)}`
      ].join('\n'));
      return;
    }

    if (cmd === '/audio' || cmd === '/som') {
      const store = await chrome.storage.local.get(['livewelAudioStatus', 'audioLibrary', 'audioPlayMode']);
      const status = store.livewelAudioStatus || {};
      const tracks = Array.isArray(store.audioLibrary) ? store.audioLibrary : [];
      await sendTelegramText(config, [
        '🎧 STATUS DO ÁUDIO',
        `Reprodução: ${status.playing ? 'ativa ▶️' : 'pausada ⏸️'}`,
        `Faixa: ${status.currentTrackName || 'nenhuma'}`,
        `Biblioteca: ${tracks.length} faixa(s)`,
        `Modo: ${tracks.length === 1 && (tracks[0]?.streaming || Number(tracks[0]?.duration) >= 600) ? 'faixa longa em loop direto' : store.audioPlayMode === 'segments' ? 'trechos em loop' : 'faixas completas em loop'}`,
        `Monitor local: ${status.monitoring ? 'ligado' : 'desligado'}`
      ].join('\n'));
      return;
    }

    if (cmd === '/cenas' || cmd === '/scenes') {
      const data = await localStudioCommand('LIVEOS_CC_OBS_SCENES');
      const scenes = Array.isArray(data.scenes) ? data.scenes : [];
      await sendTelegramText(config, scenes.length
        ? ['🎬 CENAS DO OBS', ...scenes.map((scene, index) => `${index + 1}. ${scene}${scene === data.current ? ' · ATUAL' : ''}`), '', 'Use /cena número ou /cena nome.'].join('\n')
        : '⚠️ O OBS não retornou cenas. Confirme a conexão WebSocket no LiveStudioCAM.');
      return;
    }

    if (cmd === '/cena' || cmd === '/scene') {
      if (!arg) { await sendTelegramText(config, '⚠️ Use /cena 2 ou /cena Nome da cena.'); return; }
      const data = await localStudioCommand('LIVEOS_CC_OBS_SCENES');
      const scenes = Array.isArray(data.scenes) ? data.scenes : [];
      let scene = /^\d+$/.test(arg) ? scenes[Number(arg) - 1] : scenes.find((item) => item.toLocaleLowerCase('pt-BR') === arg.toLocaleLowerCase('pt-BR'));
      if (!scene) scene = scenes.find((item) => item.toLocaleLowerCase('pt-BR').includes(arg.toLocaleLowerCase('pt-BR')));
      if (!scene) { await sendTelegramText(config, '⚠️ Cena não encontrada. Use /cenas para listar.'); return; }
      await localStudioCommand('LIVEOS_CC_OBS_SCENE', { scene });
      await sendTelegramText(config, `🎬 Cena alterada no OBS: ${scene}`);
      return;
    }

    if (cmd === '/destaque' || cmd === '/highlight') {
      await localStudioCommand('LIVEOS_CC_HIGHLIGHT');
      await sendTelegramText(config, '⭐ Destaque salvo pelo Replay Buffer do OBS.');
      return;
    }

    if (cmd === '/camera' || cmd === '/reiniciarcamera') {
      await localStudioCommand('LIVEOS_CC_CAMERA_RESTART');
      await sendTelegramText(config, '📷 Câmera virtual reiniciada.');
      return;
    }

    if (cmd === '/telemetria' || cmd === '/fps') {
      const data = await localStudioCommand('LIVEOS_CC_TELEMETRY');
      await sendTelegramText(config, [
        '📈 TELEMETRIA DA CÂMERA',
        `FPS: ${Number(data.actualFps ?? data.fps ?? 0).toFixed(1)} / ${Number(data.targetFps || 30)}`,
        `Saída: ${Number(data.width || 720)}×${Number(data.height || 1280)}`,
        `Drops: ${Number(data.droppedFrames ?? data.drops ?? 0)}`,
        `Reinícios: ${Number(data.restartCount ?? data.restarts ?? 0)}`,
        `Último quadro: ${data.lastFrameAgeMs == null ? 'sem leitura' : `${data.lastFrameAgeMs} ms`}`,
        `Câmera: ${data.cameraConnected === false ? 'desconectada ❌' : 'ativa ✅'}`
      ].join('\n'));
      return;
    }

    if (cmd === '/perfil' || cmd === '/profile') {
      const normalized = normalizeSearchTerm(arg);
      const profile = ['fraco', 'low', '540', '540p'].includes(normalized) ? 'low' : ['720', '720p', 'desempenho', 'performance'].includes(normalized) ? 'performance' : '';
      if (!profile) { await sendTelegramText(config, '⚠️ Use /perfil 720 ou /perfil fraco. Ambos trabalham a 30 FPS.'); return; }
      const settings = await updateCommandCenterSettings({ captureProfile: profile, outputFps: 30, videoPipelineVersion: 4 });
      await localStudioCommand('LIVEOS_CC_OUTPUT_CONFIG', { config: { frameMode: settings.videoFrameMode || 'fit', captureProfile: profile, safeScale: settings.safeScale || 1, outputFps: 30 } });
      await sendTelegramText(config, profile === 'low' ? '🪶 Perfil PC fraco aplicado: 540×960 a 30 FPS.' : '⚡ Perfil desempenho aplicado: 720×1280 a 30 FPS.');
      return;
    }

    if (cmd === '/auto') {
      const enabled = parseOnOff(arg);
      if (enabled == null) { await sendTelegramText(config, '⚠️ Use /auto on ou /auto off.'); return; }
      await updateCommandCenterSettings({ engagementReminderEnabled: enabled, engagementAutoPublish: enabled });
      await sendTelegramText(config, `💬 Comentários periódicos ${enabled ? 'ativados' : 'desativados'}.`);
      return;
    }

    if (cmd === '/respostas' || cmd === '/replies') {
      const enabled = parseOnOff(arg);
      if (enabled == null) { await sendTelegramText(config, '⚠️ Use /respostas on ou /respostas off.'); return; }
      await updateCommandCenterSettings({ autoReplyEnabled: enabled });
      await sendTelegramText(config, `🤖 Respostas automáticas ${enabled ? 'ativadas' : 'desativadas'}.`);
      return;
    }

    if (cmd === '/status' || cmd === '/info') {
      const store = await chrome.storage.local.get(null);
      const onAir = store.liveOnAir !== false ? '🟢 No Ar' : '🔴 Fora do Ar';
      const gmv = formatBrl(store.gmvCurrent || 0);
      const orders = Number(store.gmvOrders || 0);
      const msg = [
        `📊 *Status da Live:* ${onAir}`,
        `💵 GMV Acumulado: ${gmv}`,
        `📦 Pedidos Confirmados: ${orders}`,
        `🛡️ Auto-Kill Switch: ${store.violationAutoEnd !== false ? 'Ativado ✅' : 'Desativado ❌'}`
      ].join('\n');
      await sendTelegramText(config, msg);
      return;
    }
    await sendTelegramText(config, '⚠️ Comando não reconhecido. Envie /ajuda para ver as opções.');
  } catch (err) {
    console.warn('[Telegram Remote Command Error]', err);
    await sendTelegramText(config, `⚠️ O comando falhou: ${String(err?.message || err)}`).catch(() => {});
  }
}

async function pollTelegramUpdates() {
  if (telegramPollingActive) return;
  telegramPollingActive = true;

  try {
    const config = await readTelegramConfig();
    if (!config.botToken || !config.enabled) {
      telegramPollingActive = false;
      return;
    }

    if (!lastUpdateId) {
      const stored = await chrome.storage.local.get(TELEGRAM_UPDATE_KEY);
      lastUpdateId = Math.max(0, Number(stored[TELEGRAM_UPDATE_KEY]) || 0);
    }

    const updates = await telegramRequest(config, `getUpdates?offset=${lastUpdateId + 1}&timeout=5`);
    if (Array.isArray(updates)) {
      for (const update of updates) {
        lastUpdateId = Math.max(lastUpdateId, update.update_id || 0);
        const msg = update.message || update.edited_message;
        if (msg && msg.text && String(msg.chat?.id) === String(config.chatId)) {
          await executeRemoteCommand(config, msg.text, msg.from?.first_name || msg.from?.username);
        }
      }
      if (updates.length) await chrome.storage.local.set({ [TELEGRAM_UPDATE_KEY]: lastUpdateId });
    }
  } catch (e) {
    // Falha silenciosa no polling
  } finally {
    telegramPollingActive = false;
  }
}

setInterval(pollTelegramUpdates, 4000);
setTimeout(pollTelegramUpdates, 750);
chrome.alarms?.create(TELEGRAM_POLL_ALARM, { delayInMinutes: .1, periodInMinutes: .5 });
chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name === TELEGRAM_POLL_ALARM) void pollTelegramUpdates();
});

async function handleTelegramMessage(message) {
    if (message.type === 'LIVEOS_TG_GET_CONFIG') return { ok: true, config: publicTelegramConfig(await readTelegramConfig()) };
    if (message.type === 'LIVEOS_TG_SAVE_CONFIG') return { ok: true, config: await saveTelegramConfig(message.config) };
    if (message.type === 'LIVEOS_TG_FIND_CHAT') {
      const found = await findLatestChat(await readTelegramConfig());
      const checked = await checkTelegramConnection(await readTelegramConfig());
      return { ok: true, config: { ...found, ...checked } };
    }
    if (message.type === 'LIVEOS_TG_CHECK') return { ok: true, config: await checkTelegramConnection(await readTelegramConfig()) };
    if (message.type === 'LIVEOS_TG_TEST') {
      const config = await readTelegramConfig();
      return { ok: true, config: await checkTelegramConnection(config, { sendTest: true }) };
    }
    if (message.type === 'LIVEOS_TG_SALE') {
      const config = await readTelegramConfig();
      const source = message.source === 'detected' ? 'detected' : 'manual';
      if (!config.enabled || (source === 'manual' && !config.notifyManual) || (source === 'detected' && !config.notifyDetected)) return { ok: true, skipped: true };
      if (!config.botToken || !config.chatId) return { ok: false, error: 'Configure o Telegram na aba Config.' };
      const eventId = String(message.eventId || '');
      if (await claimTelegramEvent(eventId)) return { ok: true, duplicate: true };
      try {
        await sendTelegramText(config, message.text || saleNotificationText(message));
        await markTelegramEventSent(eventId);
        return { ok: true };
      } catch (error) {
        releaseTelegramEvent(eventId);
        throw error;
      }
    }
    if (message.type === 'LIVEOS_TG_SAFETY') {
      const config = await readTelegramConfig();
      if (!config.enabled || !config.notifySafety) return { ok: true, skipped: true };
      if (!config.botToken || !config.chatId) return { ok: false, error: 'Configure o Telegram na aba Config.' };
      const eventId = String(message.eventId || '');
      if (await claimTelegramEvent(eventId)) return { ok: true, duplicate: true };
      try {
        await sendTelegramText(config, safetyNotificationText(message));
        await markTelegramEventSent(eventId);
        return { ok: true };
      } catch (error) {
        releaseTelegramEvent(eventId);
        throw error;
      }
    }
    return { ok: false, error: 'Ação do Telegram desconhecida.' };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!String(message?.type || '').startsWith('LIVEOS_TG_')) return false;
  handleTelegramMessage(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'liveos-pro-rpc' && port.name !== TELEGRAM_RPC_PORT) return;
  port.onMessage.addListener((message) => {
    if (!String(message?.type || '').startsWith('LIVEOS_TG_')) return;
    handleTelegramMessage(message)
      .then((response) => port.postMessage({ requestId: message.requestId, ...response }))
      .catch((error) => port.postMessage({ requestId: message.requestId, ok: false, error: String(error?.message || error) }));
  });
});
