// Relays the final composited player frame to every TikTok frame. Blob URLs
// cannot cross the chrome-extension:// -> https:// boundary, so the player
// sends encoded frame bytes and each content bridge paints them locally.
let lastFrameAt = 0;
let lastHealthAt = 0;
let deliveredFrames = 0;
let latestFrame = '';
let latestSequence = 0;
let lastDeliveredTabs = 0;
let lastDeliveredAt = 0;
let lastErrorAt = 0;
let lastErrorMessage = '';
let playerRtcPort = null;
const cameraRtcPorts = new Map();
const cameraRtcConnected = new Set();
const cameraTargets = new Map();
const audioTargets = new Map();
let latestAudioSource = null;
let latestAudioConfig = null;
let latestAudioControl = null;
const audioSourceRegistry = new Map();

function rememberAudioSource(message) {
  if (!message?.id || typeof message.dataUrl !== 'string') return;
  audioSourceRegistry.delete(message.id);
  audioSourceRegistry.set(message.id, message);
  while (audioSourceRegistry.size > 12) audioSourceRegistry.delete(audioSourceRegistry.keys().next().value);
}

const LIVE_URLS = [
  '*://*.tiktok.com/*',
  '*://*.tiktokshop.com/*',
  '*://seller.tiktok.com/*',
  '*://*.seller.tiktokshop.com/*'
];

function rememberCameraTarget(sender) {
  const tabId = Number(sender?.tab?.id);
  const frameId = Number(sender?.frameId ?? 0);
  if (!Number.isInteger(tabId) || !Number.isInteger(frameId)) return null;
  const key = `${tabId}:${frameId}`;
  const target = { key, tabId, frameId };
  cameraTargets.set(key, target);
  return target;
}

async function activeCameraTargets() {
  const registered = [...cameraTargets.values()];
  if (registered.length) return registered;
  const tabs = await chrome.tabs.query({ url: LIVE_URLS });
  return tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) => ({
    key: '',
    tabId: tab.id,
    frameId: 0
  }));
}

async function deliverCameraFrame(frame, sequence) {
  const targets = await activeCameraTargets();
  const results = await Promise.allSettled(targets.map((target) => (
    chrome.tabs.sendMessage(target.tabId, {
      type: 'LIVEWEL_CAMERA_FRAME',
      frame,
      sequence
    }, { frameId: target.frameId })
  )));
  results.forEach((result, index) => {
    if (result.status === 'rejected' && targets[index].key) cameraTargets.delete(targets[index].key);
  });
  return {
    delivered: results.filter((result) => result.status === 'fulfilled' && result.value?.ok !== false).length,
    rejected: results.find((result) => result.status === 'rejected')
  };
}

async function relayPlayerFrame(frame) {
  const now = Date.now();
  if (now - lastFrameAt < 55) {
    const connected = lastDeliveredTabs > 0 && now - lastDeliveredAt < 2500;
    return {
      ok: connected,
      dropped: true,
      delivered: connected ? lastDeliveredTabs : 0,
      sequence: latestSequence,
      error: connected ? '' : 'Aguardando a página da LIVE receber o primeiro quadro.'
    };
  }

  lastFrameAt = now;
  latestFrame = frame;
  latestSequence += 1;
  const { delivered, rejected } = await deliverCameraFrame(frame, latestSequence);
  if (delivered) {
    lastDeliveredTabs = delivered;
    lastDeliveredAt = now;
    deliveredFrames += 1;
    if (now - lastHealthAt > 750) {
      lastHealthAt = now;
      chrome.storage.local.set({
        livewelCameraFrameAt: now,
        livewelCameraFrameTabs: delivered,
        livewelCameraFrames: deliveredFrames,
        livewelCameraError: '',
        livewelCameraRelayAt: now
      });
      lastErrorMessage = '';
    }
  } else {
    lastDeliveredTabs = 0;
    relayError(rejected?.reason?.message || 'Recarregue a página da LIVE para conectar a câmera virtual.');
  }
  return {
    ok: delivered > 0,
    delivered,
    sequence: latestSequence,
    error: delivered ? '' : 'Nenhuma página da LIVE recebeu o quadro. Recarregue o TikTok Shop.'
  };
}

function persistPlayerStatus(message) {
  chrome.storage.local.set({
    livewelPlayerOnline: Boolean(message.online),
    livewelPlayerPlaying: Boolean(message.playing),
    livewelPlayerUpdatedAt: Date.now(),
    livewelPlayerTake: String(message.take || '')
  });
}

function relayError(message) {
  const text = String(message || 'A página do TikTok ainda não recebeu o vídeo.');
  const now = Date.now();
  if (text === lastErrorMessage && now - lastErrorAt < 1000) return;
  lastErrorMessage = text;
  lastErrorAt = now;
  chrome.storage.local.set({
    livewelCameraError: text,
    livewelCameraRelayAt: now
  });
}

function safePortMessage(port, message) {
  try {
    port?.postMessage(message);
    return true;
  } catch {
    return false;
  }
}

function announceRtcStatus(status, receiverId = '') {
  if (status === 'connected' && receiverId) cameraRtcConnected.add(receiverId);
  else if (receiverId) cameraRtcConnected.delete(receiverId);
  if (status === 'producer-offline') cameraRtcConnected.clear();
  const rtcActive = cameraRtcConnected.size > 0;
  const now = Date.now();
  chrome.storage.local.set({
    livewelCameraTransport: rtcActive ? 'webrtc' : 'frames',
    livewelCameraRtcStatus: status,
    livewelCameraRtcReceiver: receiverId,
    livewelCameraRtcAt: now,
    ...(rtcActive ? { livewelCameraFrameAt: now, livewelCameraError: '' } : {})
  });
}

async function relayAudioMessage(message) {
  const targets = [...audioTargets.entries()];
  const results = await Promise.allSettled(targets.map(([, target]) => (
    chrome.tabs.sendMessage(target.tabId, message, { frameId: target.frameId })
  )));
  results.forEach((result, index) => {
    if (result.status === 'rejected') audioTargets.delete(targets[index][0]);
  });
  return results.some((result) => result.status === 'fulfilled' && result.value?.ok !== false);
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'LIVEWEL_PLAYER_RTC') {
    if (playerRtcPort && playerRtcPort !== port) {
      try { playerRtcPort.disconnect(); } catch {}
    }
    playerRtcPort = port;
    for (const receiverId of cameraRtcPorts.keys()) {
      safePortMessage(port, { type: 'receiver-ready', receiverId });
    }
    port.onMessage.addListener((message) => {
      if (message?.type === 'fallback-frame' && typeof message.frame === 'string') {
        relayPlayerFrame(message.frame)
          .then((result) => safePortMessage(port, {
            type: 'fallback-frame-result',
            requestId: String(message.requestId || ''),
            ...result
          }))
          .catch((error) => safePortMessage(port, {
            type: 'fallback-frame-result',
            requestId: String(message.requestId || ''),
            ok: false,
            error: String(error?.message || error)
          }));
        return;
      }
      if (message?.type === 'player-status') {
        persistPlayerStatus(message);
        return;
      }
      const receiverId = String(message?.receiverId || '');
      if (!receiverId) return;
      if (message.type === 'signal') {
        safePortMessage(cameraRtcPorts.get(receiverId), { type: 'signal', receiverId, signal: message.signal });
      }
    });
    port.onDisconnect.addListener(() => {
      if (playerRtcPort === port) playerRtcPort = null;
      for (const receiverPort of cameraRtcPorts.values()) {
        safePortMessage(receiverPort, { type: 'producer-offline' });
      }
      announceRtcStatus('producer-offline');
    });
    return;
  }

  if (port.name !== 'LIVEWEL_CAMERA_RTC') return;
  let registeredId = '';
  port.onMessage.addListener((message) => {
    const receiverId = String(message?.receiverId || registeredId || '');
    if (!receiverId) return;
    if (message.type === 'receiver-ready') {
      registeredId = receiverId;
      cameraRtcPorts.set(receiverId, port);
      safePortMessage(playerRtcPort, { type: 'receiver-ready', receiverId });
      return;
    }
    if (message.type === 'signal') {
      safePortMessage(playerRtcPort, { type: 'signal', receiverId, signal: message.signal });
      return;
    }
    if (message.type === 'receiver-status') {
      announceRtcStatus(String(message.status || 'unknown'), receiverId);
      safePortMessage(playerRtcPort, {
        type: 'receiver-status',
        receiverId,
        status: String(message.status || 'unknown')
      });
    }
  });
  port.onDisconnect.addListener(() => {
    if (!registeredId || cameraRtcPorts.get(registeredId) !== port) return;
    cameraRtcPorts.delete(registeredId);
    announceRtcStatus('receiver-closed', registeredId);
    safePortMessage(playerRtcPort, { type: 'receiver-closed', receiverId: registeredId });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'LIVEWEL_CAMERA_BRIDGE_READY') {
    // Every TikTok iframe loads the bridge, but only the frame that actually
    // requested the virtual camera should receive the continuous fallback.
    if (message.videoRequested === true) rememberCameraTarget(sender);
    sendResponse({
      ok: true,
      frame: latestFrame || undefined,
      sequence: latestSequence,
      updatedAt: lastFrameAt
    });
    return;
  }

  if (message?.type === 'LIVEWEL_AUDIO_BRIDGE_READY') {
    const tabId = Number(sender?.tab?.id);
    const frameId = Number(sender?.frameId || 0);
    const targetKey = `${tabId}:${frameId}`;
    const newTarget = Number.isInteger(tabId) && !audioTargets.has(targetKey);
    const restoreMessages = message.restore === false
      ? []
      : [latestAudioConfig, ...audioSourceRegistry.values(), latestAudioSource, latestAudioControl].filter(Boolean);
    if (Number.isInteger(tabId)) {
      audioTargets.set(targetKey, { tabId, frameId });
      // A restauração é enviada também diretamente ao frame. Assim, um
      // listener legado que responda "unknown_message" primeiro não consegue
      // impedir que o cache de áudio volte depois de um reload da página.
      if (restoreMessages.length) void (async () => {
        for (const restoreMessage of restoreMessages) {
          await chrome.tabs.sendMessage(tabId, restoreMessage, { frameId }).catch(() => null);
        }
      })();
      if (newTarget) chrome.runtime.sendMessage({ type: 'LIVEWEL_AUDIO_TARGET_READY' }).catch(() => {});
    }
    sendResponse({
      ok: Number.isInteger(tabId),
      messages: []
    });
    return;
  }

  if (message?.type === 'LIVEWEL_AUDIO_REGISTER_SOURCE'
    || message?.type === 'LIVEWEL_AUDIO_SOURCE'
    || message?.type === 'LIVEWEL_AUDIO_SOURCE_BEGIN'
    || message?.type === 'LIVEWEL_AUDIO_SOURCE_CHUNK'
    || message?.type === 'LIVEWEL_AUDIO_SOURCE_END'
    || message?.type === 'LIVEWEL_AUDIO_CONTROL'
    || message?.type === 'LIVEWEL_AUDIO_CONFIG') {
    if (message.type === 'LIVEWEL_AUDIO_REGISTER_SOURCE') rememberAudioSource(message);
    if (message.type === 'LIVEWEL_AUDIO_SOURCE') {
      if (typeof message.dataUrl === 'string') {
        rememberAudioSource({ type: 'LIVEWEL_AUDIO_REGISTER_SOURCE', id: message.id, name: message.name || '', dataUrl: message.dataUrl });
      }
      latestAudioSource = { ...message };
      delete latestAudioSource.dataUrl;
      latestAudioControl = { type: 'LIVEWEL_AUDIO_CONTROL', action: 'play' };
    }
    if (message.type === 'LIVEWEL_AUDIO_CONTROL') latestAudioControl = message;
    if (message.type === 'LIVEWEL_AUDIO_CONFIG') latestAudioConfig = message;
    relayAudioMessage(message)
      .then((ok) => sendResponse({ ok, waitingForMicrophone: !ok }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === 'LIVEWEL_PLAYER_FRAME' && typeof message.frame === 'string') {
    relayPlayerFrame(message.frame)
      .then(sendResponse)
      .catch((error) => {
        relayError(error?.message || error);
        sendResponse({ ok: false, error: String(error?.message || error) });
      });
    return true;
  }

  if (message?.type === 'LIVEWEL_PLAYER_STATUS') {
    persistPlayerStatus(message);
    sendResponse({ ok: true });
  }
});
