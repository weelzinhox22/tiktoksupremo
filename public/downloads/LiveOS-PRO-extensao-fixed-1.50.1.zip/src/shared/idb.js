const VIDEO_DB = 'plw_liveops_videos';
const VIDEO_VERSION = 1;
const VIDEO_STORE = 'blobs';
const AUDIO_DB = 'plw_liveops_audio';
const AUDIO_VERSION = 1;
const AUDIO_STORE = 'tracks';

function openDb(name, version, storeName) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(name, version);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

const openVideoDb = () => openDb(VIDEO_DB, VIDEO_VERSION, VIDEO_STORE);
const openAudioDb = () => openDb(AUDIO_DB, AUDIO_VERSION, AUDIO_STORE);

async function readRecord(openDatabase, storeName, id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const request = transaction.objectStore(storeName).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
    transaction.onerror = () => db.close();
    transaction.onabort = () => db.close();
  });
}

async function writeRecord(openDatabase, storeName, record) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    transaction.objectStore(storeName).put(record);
    transaction.oncomplete = () => {
      db.close();
      resolve(true);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error);
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error || new Error('Transação IndexedDB cancelada.'));
    };
  });
}

async function deleteRecord(openDatabase, storeName, id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    transaction.objectStore(storeName).delete(id);
    transaction.oncomplete = () => {
      db.close();
      resolve(true);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error);
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error || new Error('Transação IndexedDB cancelada.'));
    };
  });
}

function arrayBufferFrom(value) {
  if (!value) return null;
  if (value instanceof ArrayBuffer) return value.slice(0);
  if (ArrayBuffer.isView(value)) {
    return value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength);
  }
  return null;
}

function audioBlob(record) {
  if (!record) return null;
  if (record.blob instanceof Blob) return record.blob;
  if (record.data instanceof Blob) return record.data;
  const data = arrayBufferFrom(record.data);
  if (!data) return null;
  return new Blob([data], { type: record.mime || 'audio/mpeg' });
}

export async function idbPutBlob(id, blob, metadata = {}) {
  if (!(blob instanceof Blob) || blob.size < 1) throw new Error('Arquivo vazio ao salvar.');
  return writeRecord(openVideoDb, VIDEO_STORE, {
    id,
    blob,
    ...metadata,
    updatedAt: Date.now()
  });
}

export function idbGetBlob(id) {
  return readRecord(openVideoDb, VIDEO_STORE, id);
}

export function idbDeleteBlob(id) {
  return deleteRecord(openVideoDb, VIDEO_STORE, id);
}

export async function idbClearAll() {
  const db = await openVideoDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(VIDEO_STORE, 'readwrite');
    transaction.objectStore(VIDEO_STORE).clear();
    transaction.oncomplete = () => {
      db.close();
      resolve(true);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error);
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error || new Error('Transação IndexedDB cancelada.'));
    };
  });
}

export async function idbPutAudio(id, source, metadata = {}) {
  let blob;
  if (source instanceof Blob) {
    blob = source;
  } else {
    const data = arrayBufferFrom(source);
    if (data) blob = new Blob([data], { type: metadata.mime || 'audio/mpeg' });
  }
  if (!blob?.size) throw new Error('Áudio vazio ao salvar.');
  const mime = blob.type || metadata.mime || 'audio/mpeg';
  return writeRecord(openAudioDb, AUDIO_STORE, {
    id,
    blob,
    mime,
    name: metadata.name || 'Áudio',
    duration: Number(metadata.duration) || 0,
    size: Number(metadata.size) || blob.size,
    updatedAt: Date.now()
  });
}

// Caminho de baixo consumo: entrega o Blob sem materializar uma segunda cópia
// do arquivo inteiro em ArrayBuffer. Registros antigos com `data` continuam
// compatíveis e são convertidos apenas para uma visão Blob.
export async function idbGetAudioBlob(id) {
  const record = await readRecord(openAudioDb, AUDIO_STORE, id);
  const blob = audioBlob(record);
  if (!record || !blob?.size) return null;
  return {
    id: record.id,
    blob,
    mime: record.mime || blob.type || 'audio/mpeg',
    name: record.name || 'Áudio',
    duration: Number(record.duration) || 0,
    size: Number(record.size) || blob.size
  };
}

// Mantém a API histórica para módulos legados que ainda decodificam o arquivo
// completo. Os caminhos novos de áudio longo usam idbGetAudioBlob.
export async function idbGetAudio(id) {
  const stored = await idbGetAudioBlob(id);
  if (!stored) return null;
  const data = await stored.blob.arrayBuffer();
  return { ...stored, data };
}

export async function idbGetAudioMetadata(id) {
  const record = await readRecord(openAudioDb, AUDIO_STORE, id);
  if (!record) return null;
  const blobSize = record.blob instanceof Blob ? record.blob.size : 0;
  const dataSize = record.data instanceof ArrayBuffer
    ? record.data.byteLength
    : ArrayBuffer.isView(record.data) ? record.data.byteLength : 0;
  return {
    id: record.id,
    mime: record.mime || record.blob?.type || 'audio/mpeg',
    name: record.name || 'Áudio',
    duration: Number(record.duration) || 0,
    size: Number(record.size) || blobSize || dataSize
  };
}

export function idbDeleteAudio(id) {
  return deleteRecord(openAudioDb, AUDIO_STORE, id);
}

export async function idbListAudioIds() {
  const db = await openAudioDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(AUDIO_STORE, 'readonly');
    const request = transaction.objectStore(AUDIO_STORE).getAllKeys();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
    transaction.onerror = () => db.close();
    transaction.onabort = () => db.close();
  });
}
