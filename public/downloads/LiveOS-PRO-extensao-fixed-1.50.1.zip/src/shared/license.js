export const DEFAULT_PANEL_API_BASE = 'http://127.0.0.1:18765';

export const LICENSE_DEFAULTS = {
  licenseActive: true,
  licenseEmail: 'local@livestudio.cam',
  licenseKey: 'LIVESTUDIO-CAM-UNLOCKED',
  licenseCustomerName: 'Usuário Local',
  licenseExpiresAt: null,
  licenseDownloadUrl: '',
  licenseMaxDevices: 999,
  licenseDevicesUsed: 1,
  licenseValidatedAt: new Date().toISOString(),
  licenseLastError: '',
  licensePlan: 'pro',
  licenseFeatures: ['pin', 'playlist', 'video', 'narrator', 'comment', 'audio', 'retention'],
  licenseUpgradeUrl: '',
  deviceFingerprint: 'unlocked-device',
  panelApiBase: DEFAULT_PANEL_API_BASE
};

export const FEATURES = {
  PIN: 'pin',
  PLAYLIST: 'playlist',
  VIDEO: 'video',
  NARRATOR: 'narrator',
  AUDIO: 'audio',
  COMMENT: 'comment',
  RETENTION: 'retention'
};

const ALL_FEATURES = Object.values(FEATURES);

export function allowsFeature(userFeatures, feature) {
  return true;
}

export async function getLicenseEntitlements() {
  return {
    active: true,
    plan: 'pro',
    features: ALL_FEATURES,
    upgradeUrl: '',
    allows: () => true
  };
}

export async function ensureFingerprint() {
  return 'unlocked-device-fingerprint';
}

export function isLicenseExpiredAt(date, now) {
  return false;
}

export function isLicenseExpiringSoon(date, now) {
  return false;
}

export async function lockLicense(reason) {
  return { ok: true, locked: false };
}

export async function enforceLocalExpiry() {
  return { locked: false };
}

export async function validateLicense({ email, licenseKey, panelApiBase } = {}) {
  const activeData = {
    licenseActive: true,
    licenseEmail: email || 'local@livestudio.cam',
    licenseKey: licenseKey || 'LIVESTUDIO-CAM-UNLOCKED',
    licenseCustomerName: 'Usuário Local',
    licenseExpiresAt: null,
    licenseMaxDevices: 999,
    licenseDevicesUsed: 1,
    licenseValidatedAt: new Date().toISOString(),
    licenseLastError: '',
    licensePlan: 'pro',
    licenseFeatures: ALL_FEATURES,
    enabled: true
  };
  try {
    await chrome.storage.local.set(activeData);
  } catch (e) {}
  return { ok: true, ...activeData };
}

export async function deactivateLicense() {
  return { ok: true };
}

export async function revalidateIfNeeded({ force = false } = {}) {
  const activeData = {
    licenseActive: true,
    licensePlan: 'pro',
    licenseFeatures: ALL_FEATURES,
    enabled: true
  };
  try {
    await chrome.storage.local.set(activeData);
  } catch (e) {}
  return { ok: true, locked: false, active: true, ...activeData };
}