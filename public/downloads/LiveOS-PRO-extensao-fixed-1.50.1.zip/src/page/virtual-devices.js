(() => {
  if (globalThis.__LIVEWEL_VIRTUAL_DEVICES__) return;
  globalThis.__LIVEWEL_VIRTUAL_DEVICES__ = true;

  const devices = navigator.mediaDevices;
  if (!devices) return;

  const mediaDevicesPrototype = Object.getPrototypeOf(devices);
  const nativeEnumerateMethod = mediaDevicesPrototype?.enumerateDevices || devices.enumerateDevices;
  const nativeGetUserMediaMethod = mediaDevicesPrototype?.getUserMedia || devices.getUserMedia;
  const nativeEnumerate = () => Reflect.apply(nativeEnumerateMethod, devices, []);
  const nativeGetUserMedia = (constraints) => Reflect.apply(nativeGetUserMediaMethod, devices, [constraints]);
  const VIDEO_ID = 'livewelpro-camera';
  const AUDIO_ID = 'livewelpro-microphone';
  const GROUP_ID = 'livewelpro';

  let videoStream;
  let videoSurface;
  let audioContext;
  let audioDestination;
  let voiceGain;
  let voiceLowShelf;
  let voiceHighShelf;
  let ambientGain;
  let ambientSource;
  let audioPlaybackActive = false;
  let audioConfig = {
    volume: .9,
    voiceSpeed: 1,
    voiceTone: 0,
    ambientEnabled: true,
    ambientLevel: 10
  };
  const audioElements = [];
  let audioDeck = 0;
  const audioStartTimers = [0, 0];
  const audioStopTimers = [0, 0];
  const audioSourceUrls = new Map();
  const pendingAudioTransfers = new Map();
  const MAX_AUDIO_TRANSFER_BYTES = 256 * 1024 * 1024;

  function releaseAudioSource(entry) {
    if (entry?.revoke && typeof entry.url === 'string') URL.revokeObjectURL(entry.url);
  }

  function rememberAudioSource(id, url, revoke = false) {
    if (!id || typeof url !== 'string') return;
    const previous = audioSourceUrls.get(id);
    if (previous?.url !== url) releaseAudioSource(previous);
    audioSourceUrls.delete(id);
    audioSourceUrls.set(id, { url, revoke });
    while (audioSourceUrls.size > 12) {
      const oldestId = audioSourceUrls.keys().next().value;
      releaseAudioSource(audioSourceUrls.get(oldestId));
      audioSourceUrls.delete(oldestId);
    }
  }

  function audioSourceUrl(id) {
    const entry = audioSourceUrls.get(id);
    if (!entry) return '';
    rememberAudioSource(id, entry.url, entry.revoke);
    return entry.url;
  }

  function bytesFromBase64(data) {
    const binary = atob(data);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  function beginAudioTransfer(data) {
    const size = Number(data.size) || 0;
    const totalChunks = Number(data.totalChunks) || 0;
    if (!data.id || !data.token || size < 1 || size > MAX_AUDIO_TRANSFER_BYTES || totalChunks < 1 || totalChunks > 2048) return;
    pendingAudioTransfers.set(data.id, {
      token: String(data.token),
      mime: String(data.mime || 'audio/mpeg'),
      size,
      totalChunks,
      chunks: new Array(totalChunks),
      received: 0,
      receivedBytes: 0
    });
    while (pendingAudioTransfers.size > 2) pendingAudioTransfers.delete(pendingAudioTransfers.keys().next().value);
  }

  function appendAudioTransfer(data) {
    const transfer = pendingAudioTransfers.get(data.id);
    const index = Number(data.index);
    if (!transfer || transfer.token !== String(data.token) || !Number.isInteger(index) || index < 0 || index >= transfer.totalChunks || typeof data.data !== 'string') return;
    if (transfer.chunks[index]) return;
    let bytes;
    try {
      bytes = bytesFromBase64(data.data);
    } catch {
      pendingAudioTransfers.delete(data.id);
      return;
    }
    transfer.chunks[index] = bytes;
    transfer.received += 1;
    transfer.receivedBytes += bytes.byteLength;
    if (transfer.receivedBytes > MAX_AUDIO_TRANSFER_BYTES) pendingAudioTransfers.delete(data.id);
  }

  function finishAudioTransfer(data) {
    const transfer = pendingAudioTransfers.get(data.id);
    if (!transfer || transfer.token !== String(data.token)) return;
    pendingAudioTransfers.delete(data.id);
    if (transfer.received !== transfer.totalChunks || transfer.receivedBytes !== transfer.size || transfer.chunks.some((chunk) => !chunk)) return;
    const blob = new Blob(transfer.chunks, { type: transfer.mime });
    rememberAudioSource(data.id, URL.createObjectURL(blob), true);
  }

  window.addEventListener('pagehide', () => {
    for (const entry of audioSourceUrls.values()) releaseAudioSource(entry);
    audioSourceUrls.clear();
    pendingAudioTransfers.clear();
  });

  function isVirtualAudioStream(stream) {
    try {
      return stream?.getAudioTracks?.().some((track) => (
        track.label === 'LiveWelPro - Microfone Virtual'
        || track.getSettings?.().deviceId === AUDIO_ID
      ));
    } catch {
      return false;
    }
  }

  function muteVirtualMonitor(element, stream = element?.srcObject) {
    if (!element || !isVirtualAudioStream(stream)) return;
    try { element.muted = true; } catch {}
    try { element.defaultMuted = true; } catch {}
    try { element.volume = 0; } catch {}
    element.setAttribute?.('data-livewel-local-monitor', 'muted');
  }

  function installVirtualMonitorMute() {
    const prototype = globalThis.HTMLMediaElement?.prototype;
    const descriptor = prototype && Object.getOwnPropertyDescriptor(prototype, 'srcObject');
    if (descriptor?.configurable && descriptor.set && !prototype.__livewelSrcObjectMuteInstalled) {
      try {
        Object.defineProperty(prototype, 'srcObject', {
          configurable: true,
          enumerable: descriptor.enumerable,
          get: descriptor.get,
          set(stream) {
            descriptor.set.call(this, stream);
            muteVirtualMonitor(this, stream);
          }
        });
        Object.defineProperty(prototype, '__livewelSrcObjectMuteInstalled', { value: true });
      } catch {}
    }
    const Context = globalThis.AudioContext || globalThis.webkitAudioContext;
    const contextPrototype = Context?.prototype;
    if (contextPrototype?.createMediaStreamSource && !contextPrototype.__livewelStreamSourceMuteInstalled) {
      const nativeCreateMediaStreamSource = contextPrototype.createMediaStreamSource;
      try {
        Object.defineProperty(contextPrototype, 'createMediaStreamSource', {
          configurable: true,
          writable: true,
          value(stream) {
            const node = nativeCreateMediaStreamSource.call(this, stream);
            if (isVirtualAudioStream(stream) && typeof node.connect === 'function') {
              const nativeConnect = node.connect.bind(node);
              node.connect = (destination, ...args) => {
                if (destination === node.context?.destination) return destination;
                return nativeConnect(destination, ...args);
              };
            }
            return node;
          }
        });
        Object.defineProperty(contextPrototype, '__livewelStreamSourceMuteInstalled', { value: true });
      } catch {}
    }
    for (const element of document.querySelectorAll?.('audio,video') || []) muteVirtualMonitor(element);
  }

  installVirtualMonitorMute();
  if (typeof setInterval === 'function') setInterval(installVirtualMonitorMute, 1000);

  const valueContainsId = (value, deviceId) => {
    if (typeof value === 'string') return value === deviceId;
    if (Array.isArray(value)) return value.some((item) => valueContainsId(item, deviceId));
    if (!value || typeof value !== 'object') return false;
    return valueContainsId(value.exact, deviceId) || valueContainsId(value.ideal, deviceId);
  };

  const requestsDevice = (constraint, deviceId) => {
    if (!constraint || constraint === true || typeof constraint !== 'object') return false;
    if (valueContainsId(constraint.deviceId, deviceId)) return true;
    return Array.isArray(constraint.advanced)
      && constraint.advanced.some((entry) => valueContainsId(entry?.deviceId, deviceId));
  };

  const virtualDevice = (kind, deviceId, label) => ({
    kind,
    deviceId,
    label,
    groupId: GROUP_ID,
    toJSON() { return { kind, deviceId, label, groupId: GROUP_ID }; }
  });

  async function enumerateDevicesWithVirtualSources() {
    let found = [];
    try {
      found = await nativeEnumerate();
    } catch {}
    return [
      ...found.filter((item) => item.deviceId !== VIDEO_ID && item.deviceId !== AUDIO_ID),
      virtualDevice('videoinput', VIDEO_ID, 'LiveWelPro - Câmera Virtual'),
      virtualDevice('audioinput', AUDIO_ID, 'LiveWelPro - Microfone Virtual')
    ];
  }

  function getSurface() {
    return document.getElementById('livewel-virtual-camera-surface');
  }

  async function waitForSurface(timeoutMs = 3000) {
    const startedAt = performance.now();
    let surface = getSurface();
    while (!surface?.captureStream && performance.now() - startedAt < timeoutMs) {
      await new Promise((resolve) => setTimeout(resolve, 25));
      surface = getSurface();
    }
    return surface;
  }

  function decorateTrack(track, kind) {
    if (!track) return track;
    const deviceId = kind === 'video' ? VIDEO_ID : AUDIO_ID;
    const label = kind === 'video'
      ? 'LiveWelPro - Câmera Virtual'
      : 'LiveWelPro - Microfone Virtual';
    try { Object.defineProperty(track, 'label', { configurable: true, value: label }); } catch {}
    const nativeGetSettings = track.getSettings?.bind(track);
    if (nativeGetSettings) {
      try {
        Object.defineProperty(track, 'getSettings', {
          configurable: true,
          value: () => ({ ...nativeGetSettings(), deviceId, groupId: GROUP_ID })
        });
      } catch {}
    }
    return track;
  }

  async function getVirtualVideo() {
    globalThis.__LIVEWEL_VIRTUAL_VIDEO_REQUESTED_AT__ = Date.now();
    window.dispatchEvent(new CustomEvent('livewel-virtual-video-requested'));
    const surface = await waitForSurface();
    if (!surface?.captureStream) {
      throw new DOMException('Player LiveWelPro ainda não conectado.', 'NotReadableError');
    }
    if (videoSurface !== surface || !videoStream || videoStream.getVideoTracks().every((track) => track.readyState === 'ended')) {
      videoStream?.getTracks().forEach((track) => track.stop());
      videoStream = surface.captureStream(30);
      videoSurface = surface;
    }
    return decorateTrack(videoStream.getVideoTracks()[0]?.clone(), 'video');
  }

  function clamp(value, min, max, fallback = min) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
  }

  function setAudioParam(param, value) {
    if (!param) return;
    try {
      if (audioContext && typeof param.setTargetAtTime === 'function') {
        param.setTargetAtTime(value, audioContext.currentTime, .012);
      } else {
        param.value = value;
      }
    } catch {
      try { param.value = value; } catch {}
    }
  }

  function applyAudioConfig(next = audioConfig) {
    audioConfig = { ...audioConfig, ...(next || {}) };
    const volume = clamp(audioConfig.volume, 0, 1, .9);
    const speed = clamp(audioConfig.voiceSpeed, .75, 1.25, 1);
    const tone = clamp(audioConfig.voiceTone, -100, 100, 0);
    const grave = Math.max(0, -tone / 100);
    const agudo = Math.max(0, tone / 100);
    setAudioParam(voiceGain?.gain, volume);
    setAudioParam(voiceLowShelf?.gain, grave * 10 - agudo * 4);
    setAudioParam(voiceHighShelf?.gain, agudo * 8 - grave * 5);
    const ambientLevel = clamp(audioConfig.ambientLevel, 0, 100, 10);
    const normalizedAmbient = ambientLevel / 100;
    const ambientVolume = audioPlaybackActive && audioConfig.ambientEnabled !== false && normalizedAmbient > 0
      ? .003 + normalizedAmbient * .035
      : 0;
    setAudioParam(ambientGain?.gain, ambientVolume);
    for (const element of audioElements) {
      element.playbackRate = speed;
      try { element.preservesPitch = true; } catch {}
      try { element.webkitPreservesPitch = true; } catch {}
    }
  }

  function createAmbientMicrophoneNoise() {
    if (!audioContext || !audioDestination || ambientSource) return;
    const sampleRate = audioContext.sampleRate || 48000;
    const buffer = audioContext.createBuffer(1, sampleRate * 2, sampleRate);
    const samples = buffer.getChannelData(0);
    let softNoise = 0;
    for (let index = 0; index < samples.length; index += 1) {
      const white = Math.random() * 2 - 1;
      softNoise = softNoise * .965 + white * .035;
      samples[index] = white * .68 + softNoise * .32;
    }
    const fadeSamples = Math.min(1024, samples.length - 1);
    const loopValue = samples[0];
    for (let index = 0; index < fadeSamples; index += 1) {
      const mix = (index + 1) / fadeSamples;
      const target = samples.length - fadeSamples + index;
      samples[target] = samples[target] * (1 - mix) + loopValue * mix;
    }
    ambientSource = audioContext.createBufferSource();
    ambientSource.buffer = buffer;
    ambientSource.loop = true;
    const highPass = audioContext.createBiquadFilter();
    highPass.type = 'highpass';
    highPass.frequency.value = 380;
    const lowPass = audioContext.createBiquadFilter();
    lowPass.type = 'lowpass';
    lowPass.frequency.value = 6800;
    ambientGain = audioContext.createGain();
    ambientGain.gain.value = 0;
    ambientSource.connect(highPass).connect(lowPass).connect(ambientGain).connect(audioDestination);
    ambientSource.start();
  }

  function ensureVirtualAudio() {
    if (!audioContext || audioContext.state === 'closed') {
      const Context = globalThis.AudioContext || globalThis.webkitAudioContext;
      audioContext = new Context({ latencyHint: 'playback' });
      audioDestination = audioContext.createMediaStreamDestination();
      voiceGain = audioContext.createGain();
      voiceLowShelf = audioContext.createBiquadFilter();
      voiceLowShelf.type = 'lowshelf';
      voiceLowShelf.frequency.value = 220;
      voiceHighShelf = audioContext.createBiquadFilter();
      voiceHighShelf.type = 'highshelf';
      voiceHighShelf.frequency.value = 3200;
      voiceLowShelf.connect(voiceHighShelf).connect(voiceGain).connect(audioDestination);
      for (let index = 0; index < 2; index += 1) {
        const element = document.createElement('audio');
        element.id = `livewel-virtual-audio-surface-${index}`;
        element.preload = 'auto';
        element.playsInline = true;
        element.style.display = 'none';
        (document.body || document.documentElement).appendChild(element);
        const source = audioContext.createMediaElementSource(element);
        source.connect(voiceLowShelf);
        audioElements.push(element);
      }
      createAmbientMicrophoneNoise();
      const oscillator = audioContext.createOscillator();
      const keepAlive = audioContext.createGain();
      keepAlive.gain.value = 0.00001;
      oscillator.connect(keepAlive).connect(audioDestination);
      oscillator.start();
      applyAudioConfig();
    }
    audioContext.resume().catch(() => {});
    return audioDestination;
  }

  function getVirtualAudio() {
    globalThis.__LIVEWEL_VIRTUAL_AUDIO_REQUESTED_AT__ = Date.now();
    window.dispatchEvent(new CustomEvent('livewel-virtual-audio-requested'));
    ensureVirtualAudio();
    return decorateTrack(audioDestination.stream.getAudioTracks()[0]?.clone(), 'audio');
  }

  async function getUserMediaWithVirtualSources(constraints = {}) {
    const wantsVideo = requestsDevice(constraints.video, VIDEO_ID);
    const wantsAudio = requestsDevice(constraints.audio, AUDIO_ID);
    if (!wantsVideo && !wantsAudio) return nativeGetUserMedia(constraints);

    const stream = new MediaStream();
    if (wantsVideo) stream.addTrack(await getVirtualVideo());
    else if (constraints.video) {
      const native = await nativeGetUserMedia({ video: constraints.video, audio: false });
      native.getVideoTracks().forEach((track) => stream.addTrack(track));
    }

    if (wantsAudio) stream.addTrack(getVirtualAudio());
    else if (constraints.audio) {
      const native = await nativeGetUserMedia({ video: false, audio: constraints.audio });
      native.getAudioTracks().forEach((track) => stream.addTrack(track));
    }
    return stream;
  }

  function installMethod(target, name, value) {
    if (!target) return;
    try {
      Object.defineProperty(target, name, { configurable: true, writable: true, value });
    } catch {
      try { target[name] = value; } catch {}
    }
  }

  installMethod(mediaDevicesPrototype, 'enumerateDevices', enumerateDevicesWithVirtualSources);
  installMethod(mediaDevicesPrototype, 'getUserMedia', getUserMediaWithVirtualSources);
  installMethod(devices, 'enumerateDevices', enumerateDevicesWithVirtualSources);
  installMethod(devices, 'getUserMedia', getUserMediaWithVirtualSources);

  const legacyGetUserMedia = (constraints, onSuccess, onError) => {
    getUserMediaWithVirtualSources(constraints).then(onSuccess, onError);
  };
  if ('getUserMedia' in navigator) installMethod(navigator, 'getUserMedia', legacyGetUserMedia);
  if ('webkitGetUserMedia' in navigator) installMethod(navigator, 'webkitGetUserMedia', legacyGetUserMedia);

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (event.source !== window || data?.source !== 'livewel-extension') return;
    if (data.type === 'LIVEWEL_AUDIO_REGISTER_SOURCE' && typeof data.dataUrl === 'string') {
      rememberAudioSource(data.id, data.dataUrl);
      return;
    }
    if (data.type === 'LIVEWEL_AUDIO_SOURCE_BEGIN') {
      beginAudioTransfer(data);
      return;
    }
    if (data.type === 'LIVEWEL_AUDIO_SOURCE_CHUNK') {
      appendAudioTransfer(data);
      return;
    }
    if (data.type === 'LIVEWEL_AUDIO_SOURCE_END') {
      finishAudioTransfer(data);
      return;
    }
    if (data.type === 'LIVEWEL_AUDIO_SOURCE' && data.id) {
      if (typeof data.dataUrl === 'string') rememberAudioSource(data.id, data.dataUrl);
      const sourceUrl = audioSourceUrl(data.id);
      if (!sourceUrl) return;
      ensureVirtualAudio();
      audioPlaybackActive = true;
      applyAudioConfig();
      const deckIndex = (audioDeck + 1) % audioElements.length;
      audioDeck = deckIndex;
      const element = audioElements[deckIndex];
      const other = audioElements[(deckIndex + 1) % audioElements.length];
      const startPlayback = () => {
        if (Number.isFinite(Number(data.currentTime))) {
          try { element.currentTime = Math.max(0, Number(data.currentTime)); } catch {}
        }
        const delay = Math.max(0, Number(data.startAt || Date.now()) - Date.now());
        clearTimeout(audioStartTimers[deckIndex]);
        clearTimeout(audioStopTimers[deckIndex]);
        audioStartTimers[deckIndex] = setTimeout(() => {
          other.pause();
          audioContext.resume().catch(() => {});
          applyAudioConfig();
          element.play().then(() => {
            const playDurationMs = Math.max(0, Number(data.playDurationSec) || 0) * 1000;
            if (playDurationMs) {
              audioStopTimers[deckIndex] = setTimeout(() => element.pause(), playDurationMs + 25);
            }
          }).catch(() => {});
        }, delay);
      };
      element.pause();
      element.loop = data.loop === true;
      element.src = sourceUrl;
      element.onloadedmetadata = startPlayback;
      element.load();
    }
    if (data.type === 'LIVEWEL_AUDIO_CONTROL') {
      ensureVirtualAudio();
      if (data.action === 'pause' || data.action === 'stop') {
        audioPlaybackActive = false;
        audioStartTimers.forEach(clearTimeout);
        audioStopTimers.forEach(clearTimeout);
        audioElements.forEach((element) => element.pause());
      }
      if (data.action === 'play') {
        audioPlaybackActive = true;
        audioElements[audioDeck]?.play().catch(() => {});
      }
      applyAudioConfig();
    }
    if (data.type === 'LIVEWEL_AUDIO_CONFIG') {
      applyAudioConfig(data.config || data);
    }
  });

  try { devices.dispatchEvent(new Event('devicechange')); } catch {}
})();
