const ALLOWED_LOCAL = /^http:\/\/(127\.0\.0\.1|localhost):18765\//i;

function localBase(input) {
  const url = new URL(String(input || 'http://127.0.0.1:18765/'));
  const base = `${url.protocol}//${url.host}/`;
  if (!ALLOWED_LOCAL.test(base)) throw new Error('Endereço local não permitido.');
  return base;
}

async function fetchLocalJson(url, options = {}, timeoutMs = 2200) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { cache: 'no-store', ...options, signal: controller.signal });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP ${response.status}`);
    return { status: response.status, data };
  } finally {
    clearTimeout(timeout);
  }
}

async function handleHealthMessage(message) {
  try {
    const base = localBase(message.url);
    const candidates = [new URL('api/status', base).href, base];
    let lastError = null;
    for (const endpoint of candidates) {
      try {
        const result = await fetchLocalJson(endpoint, { method: 'GET' });
        if (!result.data || result.data.ok === false) throw new Error(result.data?.error || 'Resposta de status inválida.');
        return { ok: true, status: result.status, data: result.data, endpoint, base };
      } catch (error) { lastError = error; }
    }
    throw lastError || new Error('O app não respondeu.');
  } catch (error) {
    return { ok: false, error: error?.name === 'AbortError' ? 'tempo esgotado' : String(error?.message || error) };
  }
}

async function handleAppCommand(message) {
  try {
    const base = localBase(message.url);
    const command = ['play', 'pause', 'next'].includes(message.command) ? message.command : '';
    if (!command) return { ok: false, error: 'Comando do app não permitido.' };
    const body = command === 'play' && Number.isInteger(Number(message.index)) ? { index: Number(message.index) } : {};
    const result = await fetchLocalJson(new URL(`api/${command}`, base).href, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }, 3500);
    return { ok: result.data?.ok !== false, data: result.data, command };
  } catch (error) {
    return { ok: false, error: error?.name === 'AbortError' ? 'tempo esgotado' : String(error?.message || error) };
  }
}

async function handleOutputConfig(message) {
  try {
    const base = localBase(message.url);
    const frameMode = message.config?.frameMode === 'crop' ? 'crop' : 'fit';
    const captureProfile = message.config?.captureProfile === 'low' ? 'low' : 'performance';
    const safeScale = Math.max(0.5, Math.min(1.5, Number(message.config?.safeScale) || 1));
    const outputFps = 30;
    const result = await fetchLocalJson(new URL('api/output/config', base).href, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frameMode, captureProfile, safeScale, outputFps })
    }, 5000);
    return { ok: result.data?.ok !== false, data: result.data };
  } catch (error) {
    return { ok: false, error: error?.name === 'AbortError' ? 'tempo esgotado' : String(error?.message || error) };
  }
}

async function handleControlMessage(message) {
  try {
    const base = localBase(message.url);
    const routes = {
      LIVEOS_CC_TELEMETRY: ['api/telemetry', 'GET'],
      LIVEOS_CC_OBS_SCENES: ['api/obs/scenes', 'GET'],
      LIVEOS_CC_OBS_SCENE: ['api/obs/scene', 'POST'],
      LIVEOS_CC_HIGHLIGHT: ['api/highlight', 'POST'],
      LIVEOS_CC_CAMERA_RESTART: ['api/camera/restart', 'POST']
    };
    const route = routes[message.type];
    if (!route) return { ok: false, error: 'Controle local desconhecido.' };
    const options = { method: route[1] };
    if (route[1] === 'POST') {
      options.headers = { 'Content-Type': 'application/json' };
      options.body = JSON.stringify(message.type === 'LIVEOS_CC_OBS_SCENE' ? { scene: message.scene } : {});
    }
    const result = await fetchLocalJson(new URL(route[0], base).href, options, 5000);
    return { ok: result.data?.ok !== false, data: result.data };
  } catch (error) {
    return { ok: false, error: error?.name === 'AbortError' ? 'tempo esgotado' : String(error?.message || error) };
  }
}

function handleMessage(message) {
  if (message?.type === 'LIVEOS_CC_HEALTH') return handleHealthMessage(message);
  if (message?.type === 'LIVEOS_CC_APP_COMMAND') return handleAppCommand(message);
  if (message?.type === 'LIVEOS_CC_OUTPUT_CONFIG') return handleOutputConfig(message);
  if (['LIVEOS_CC_TELEMETRY', 'LIVEOS_CC_OBS_SCENES', 'LIVEOS_CC_OBS_SCENE', 'LIVEOS_CC_HIGHLIGHT', 'LIVEOS_CC_CAMERA_RESTART'].includes(message?.type)) return handleControlMessage(message);
  if (message?.type === 'LIVEOS_OPEN_PLAYER_WINDOW') {
    chrome.windows.create({
      url: chrome.runtime.getURL('player/player.html'),
      type: 'popup',
      width: 1080,
      height: 720
    });
    return Promise.resolve({ ok: true });
  }
  if (message?.type === 'LIVEOS_OPEN_MOBILE_WINDOW') {
    chrome.tabs.create({ url: chrome.runtime.getURL('mobile/index.html') });
    return Promise.resolve({ ok: true });
  }
  return null;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const task = handleMessage(message);
  if (!task) return false;
  task.then(sendResponse);
  return true;
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'liveos-pro-rpc') return;
  port.onMessage.addListener((message) => {
    const task = handleMessage(message);
    if (!task) return;
    task
      .then((response) => port.postMessage({ requestId: message.requestId, ...response }))
      .catch((error) => port.postMessage({ requestId: message.requestId, ok: false, error: String(error?.message || error) }));
  });
});
