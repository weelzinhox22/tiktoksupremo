(() => {
  'use strict';
  if (globalThis.LiveOSMetricsV2) return;

  const LABELS = [
    { key: 'paidOrders', kind: 'count', priority: 120, re: /^(pedidos? pagos?|vendas? pagas?|itens? pagos?|pedidos? atribu[ií]dos? pagos?|paid orders?)(?:\s*\([^)]+\))?:?$/i },
    { key: 'pendingOrders', kind: 'count', priority: 115, re: /^(pedidos? pendentes?|pedidos? n[aã]o pagos?|n[aã]o pagos?|aguardando pagamento|pending orders?)(?:\s*\([^)]+\))?:?$/i },
    { key: 'cancelledOrders', kind: 'count', priority: 115, re: /^(pedidos? cancelados?|cancelamentos?|cancelled orders?)(?:\s*\([^)]+\))?:?$/i },
    { key: 'orders', kind: 'count', priority: 90, re: /^(pedidos?|pedidos? criados?|itens? atribu[ií]dos? vendidos?|itens? vendidos? atribu[ií]dos?|itens? vendidos?|unidades? vendidas?|total de pedidos?|pedidos? da live|total orders?|orders?)(?:\s*\([^)]+\))?:?$/i },
    { key: 'paidGmv', kind: 'money', priority: 120, re: /^(gmv pago|gmv de pedidos? pagos?|gmv confirmado|receita paga|paid gmv|paid revenue)(?:\s*\([^)]+\))?:?$/i },
    { key: 'gmv', kind: 'money', priority: 90, re: /^(gmv(?: da live| atual| total| pago| de vendas| atribu[ií]do)?|receita(?: (?:total|da live|estimada|paga|de vendas|atribu[ií]da))?|vendas \(gmv\)|valor total d[ae]s? vendas|live gmv|total revenue|revenue)(?:\s*\([^)]+\))?:?$/i },
    { key: 'commission', kind: 'money', priority: 110, re: /^(comiss[aã]o estimada(?: da live)?|comiss[aã]o|ganhos? estimados?|estimated commission)(?:\s*\([^)]+\))?:?$/i },
    { key: 'viewers', kind: 'count', priority: 100, re: /^(espectadores?|assistindo agora|viewers?|audi[eê]ncia ao vivo|live viewers?)(?:\s*\([^)]+\))?:?$/i }
  ];
  const METRIC_WORDS = /receita|gmv|comiss[aã]o|pedidos?|vendas?|itens? atribu[ií]dos?|itens? vendidos?|unidades? vendidas?|espectadores?|assistindo agora|viewers?|audi[eê]ncia|revenue/i;
  const EXCLUDED_CONTEXT = /coment[aá]rios?|chat|lista de produtos|demonstra[cç][aã]o|estoque|pre[cç]o do produto|dura[cç][aã]o m[eé]dia/i;

  function clean(value) {
    return String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function visible(node) {
    if (!node?.isConnected || node.closest?.('#plw-liveops-root, #liveos-command-center')) return false;
    try {
      const style = getComputedStyle(node);
      return style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0 && node.getClientRects().length > 0;
    } catch { return false; }
  }

  function parsePtNumber(raw, kind, contextText = '') {
    const original = clean(raw);
    if (!original || /\d{1,2}:\d{2}|\d{2}\/\d{2}|%/.test(original)) return null;
    const hasCurrency = /(?:R\$|BRL|\$)\s*[-+]?\s*\d|\d[\d.,]*\s*(?:reais?)$/i.test(original);
    const contextHasCurrency = /(?:R\$|BRL|\$|reais|gmv|receita|revenue)/i.test(contextText);
    if (kind === 'money' && !hasCurrency && !contextHasCurrency) return null;
    if (kind === 'count' && /R\$|BRL|reais?/i.test(original)) return null;
    const match = original.match(/[-+]?\s*(\d[\d.,]*)(?:\s*(mil|k))?/i);
    if (!match) return null;
    let token = match[1];
    const suffix = String(match[2] || '').toLowerCase();
    if (token.includes(',') && token.includes('.')) token = token.replace(/\./g, '').replace(',', '.');
    else if (token.includes(',')) token = token.replace(',', '.');
    else if (kind === 'money' && /^\d{1,3}(?:\.\d{3})+$/.test(token)) token = token.replace(/\./g, '');
    const number = Number(token);
    if (!Number.isFinite(number) || number < 0) return null;
    const scaled = number * (suffix ? 1000 : 1);
    if (kind === 'count' && (!Number.isInteger(scaled) || scaled > 10000000)) return null;
    if (kind === 'money' && scaled > 100000000) return null;
    return scaled;
  }

  function leafTextNodes(root) {
    const nodes = [...root.querySelectorAll('span,div,p,strong,b,label,dt,dd')];
    return nodes.filter((node) => visible(node) && clean(node.textContent).length <= 80 && ![...node.children].some((child) => clean(child.textContent) === clean(node.textContent)));
  }

  function metricLabelCount(node) {
    const text = clean(node.innerText || node.textContent);
    return (text.match(new RegExp(METRIC_WORDS.source, 'gi')) || []).length;
  }

  function candidateContainers(labelNode) {
    const containers = [];
    let node = labelNode.parentElement;
    for (let depth = 1; node && node !== document.body && depth <= 5; depth += 1, node = node.parentElement) {
      const text = clean(node.innerText || node.textContent);
      if (!text || text.length > 360 || EXCLUDED_CONTEXT.test(text)) continue;
      const labels = metricLabelCount(node);
      if (labels <= 2) containers.push({ node, depth, text, labels });
    }
    return containers;
  }

  function valueFromContainer(container, labelNode, definition) {
    const candidates = [];
    const nodes = [container.node, ...container.node.querySelectorAll('span,div,p,strong,b,dd')];
    for (const node of nodes) {
      if (node === labelNode || node.contains(labelNode) || !visible(node)) continue;
      const text = clean(node.textContent);
      if (!text || text.length > 70 || METRIC_WORDS.test(text)) continue;
      const value = parsePtNumber(text, definition.kind, container.text);
      if (value == null) continue;
      const currencyBonus = definition.kind === 'money' && /(?:R\$|BRL|\$)/i.test(text) ? 25 : 0;
      const leafBonus = node.children.length === 0 ? 12 : 0;
      const score = definition.priority + currencyBonus + leafBonus - container.depth * 3 - container.labels * 8 - text.length / 20;
      candidates.push({ value, text, score });
    }
    candidates.sort((a, b) => b.score - a.score);
    return candidates[0] || null;
  }

  function collectDocument(rootDocument = document) {
    const results = {};
    const evidence = {};
    for (const node of leafTextNodes(rootDocument)) {
      const labelText = clean(node.textContent);
      const definition = LABELS.find((item) => item.re.test(labelText));
      if (!definition) continue;
      for (const container of candidateContainers(node)) {
        const found = valueFromContainer(container, node, definition);
        if (!found) continue;
        const previous = evidence[definition.key];
        if (!previous || found.score > previous.score) {
          results[definition.key] = found.value;
          evidence[definition.key] = { label: labelText, valueText: found.text, score: Math.round(found.score), context: container.text.slice(0, 180) };
        }
        break;
      }
    }
    return { results, evidence };
  }

  function scan(rootDocument = document) {
    const documents = [rootDocument];
    try {
      for (const frame of rootDocument.querySelectorAll('iframe')) {
        const frameDocument = frame.contentDocument;
        if (frameDocument?.body) documents.push(frameDocument);
      }
    } catch {}
    const values = {};
    const evidence = {};
    for (const doc of documents) {
      const collected = collectDocument(doc);
      for (const [key, value] of Object.entries(collected.results)) {
        const incoming = collected.evidence[key];
        if (!evidence[key] || incoming.score > evidence[key].score) {
          values[key] = value;
          evidence[key] = incoming;
        }
      }
    }
    const orderKey = Number.isFinite(values.paidOrders) ? 'paidOrders' : Number.isFinite(values.orders) ? 'orders' : null;
    const gmvKey = Number.isFinite(values.paidGmv) ? 'paidGmv' : Number.isFinite(values.gmv) ? 'gmv' : null;
    return {
      ...values,
      orderKey,
      gmvKey,
      trustedOrders: Boolean(orderKey && evidence[orderKey]?.score >= 75),
      trustedGmv: Boolean(gmvKey && evidence[gmvKey]?.score >= 75),
      evidence,
      scannedAt: Date.now(),
      version: 2
    };
  }

  globalThis.LiveOSMetricsV2 = { scan, parsePtNumber, version: 2 };
  if (typeof module !== 'undefined' && module.exports) module.exports = globalThis.LiveOSMetricsV2;
})();
