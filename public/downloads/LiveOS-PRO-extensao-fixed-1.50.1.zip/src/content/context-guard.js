(() => {
  'use strict';
  if (globalThis.__LIVEOS_CONTEXT_GUARD__) return;
  globalThis.__LIVEOS_CONTEXT_GUARD__ = true;

  const isInvalidated = (error) => /extension context invalidated/i.test(
    String(error?.message || error || '')
  );

  // Content scripts from an older extension version can finish promises after
  // a developer-mode reload. Convert only that expected rejection into a safe
  // undefined response; all other errors keep their normal behavior.
  try {
    const originalSendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
    chrome.runtime.sendMessage = (...args) => {
      try {
        const result = originalSendMessage(...args);
        return result?.catch
          ? result.catch((error) => isInvalidated(error) ? undefined : Promise.reject(error))
          : result;
      } catch (error) {
        if (isInvalidated(error)) return Promise.resolve(undefined);
        throw error;
      }
    };
  } catch {}

  globalThis.addEventListener('unhandledrejection', (event) => {
    if (isInvalidated(event.reason)) event.preventDefault();
  });
})();
