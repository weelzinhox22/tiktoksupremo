(() => {
  'use strict';
  if (globalThis.__LIVEOS_VIOLATION_TELEGRAM_BRIDGE__) return;
  globalThis.__LIVEOS_VIOLATION_TELEGRAM_BRIDGE__ = true;

  const handled = new Set();
  const MAX_EVENT_AGE_MS = 90 * 1000;
  const CLOSE_TIMEOUT_MS = 55 * 1000;
  const VIOLATION_PATTERN = /(?:viola[cç][aã]o|policy violation|community guidelines|diretrizes da comunidade|conte[uú]do proibido|aviso de conformidade|transmiss[aã]o (?:foi )?(?:suspensa|interrompida|bloqueada)|live (?:foi )?(?:suspensa|interrompida|bloqueada))/i;
  let domScanTimer = 0;
  let lastDomSignature = '';
  let lastDomDetectedAt = 0;

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function findViolationState(value, depth = 0, seen = new WeakSet()) {
    if (!value || typeof value !== 'object' || depth > 5 || seen.has(value)) return null;
    seen.add(value);
    if (Object.prototype.hasOwnProperty.call(value, 'lastViolationAt')) return value;
    for (const nested of Object.values(value)) {
      const result = findViolationState(nested, depth + 1, seen);
      if (result) return result;
    }
    return null;
  }

  function eventTime(value) {
    const parsed = Date.parse(String(value || ''));
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function safePageUrl() {
    try { return `${location.origin}${location.pathname}`.slice(0, 500); } catch { return ''; }
  }

  async function sendSafety(baseId, status, state, detectedAt) {
    try {
      return await chrome.runtime.sendMessage({
        type: 'LIVEOS_TG_SAFETY',
        eventId: `${baseId}:${status}`,
        status,
        snippet: String(state.lastViolationSnippet || '').slice(0, 700),
        autoEnd: state.violationAutoEnd !== false,
        confirmSeconds: Math.max(0, Math.min(300, Number(state.violationConfirmSeconds) || 0)),
        detectedAt,
        pageUrl: safePageUrl()
      });
    } catch {
      return null;
    }
  }

  function readLiveOnAir() {
    try {
      if (typeof globalThis.PLWDom?.invalidateLiveOnAirCache === 'function') {
        globalThis.PLWDom.invalidateLiveOnAirCache();
      }
      return typeof globalThis.PLWDom?.isLiveOnAir === 'function'
        ? globalThis.PLWDom.isLiveOnAir()
        : null;
    } catch {
      return null;
    }
  }

  async function followClosure(baseId, state, detectedAt) {
    const initialOnAir = readLiveOnAir();
    if (initialOnAir === false) {
      await sendSafety(baseId, 'platform_closed', state, detectedAt);
      return;
    }

    await sendSafety(baseId, 'close_requested', state, detectedAt);
    const configuredDelay = Math.max(0, Math.min(300, Number(state.violationConfirmSeconds) || 0)) * 1000;
    if (configuredDelay) await delay(configuredDelay);

    const deadline = Date.now() + CLOSE_TIMEOUT_MS;
    while (Date.now() < deadline) {
      await delay(1000);
      if (readLiveOnAir() === false) {
        await sendSafety(baseId, 'closed', state, detectedAt);
        return;
      }
    }
    await sendSafety(baseId, 'close_failed', state, detectedAt);
  }

  async function triggerDomEndLive() {
    try {
      const endLive = globalThis.PLWDom?.tryEndLive || globalThis.PLWDom?.endLive;
      if (typeof endLive === 'function') {
        const res = await endLive.call(globalThis.PLWDom);
        if (res === true || res?.ok !== false) return true;
      }
    } catch {}

    // Fallback: busca botões no DOM que contenham texto de encerramento
    try {
      const buttons = [...document.querySelectorAll('button, [role="button"]')];
      const endBtn = buttons.find((b) => {
        const txt = (b.textContent || '').trim().toLowerCase();
        return !b.disabled && /^(encerrar(?:\s+(?:a\s+)?live)?|end(?:\s+live)?|terminar(?:\s+a)?\s+live|parar(?:\s+a)?\s+live|finalizar(?:\s+a)?\s+live|结束直播)$/i.test(txt);
      });
      if (endBtn) {
        endBtn.click();
        await delay(600);
        const modalButtons = [...document.querySelectorAll('[role="dialog"] button, .modal button, [class*="modal"] button, [class*="dialog"] button, button')];
        const confirmBtn = modalButtons.find((b) => {
          const txt = (b.textContent || '').trim().toLowerCase();
          return !b.disabled && /^(encerrar(?:\s+agora|\s+(?:a\s+)?live)?|finalizar(?:\s+agora)?|confirmar|confirm|end now|sim|ok|yes)$/i.test(txt);
        });
        if (confirmBtn) {
          confirmBtn.click();
          return true;
        }
      }
    } catch {}
    return false;
  }

  async function handleState(state) {
    if (!state || state.violationWatchEnabled === false) return;
    const detectedAt = eventTime(state.lastViolationAt);
    if (!detectedAt || Date.now() - detectedAt > MAX_EVENT_AGE_MS) return;
    const baseId = `violation:${detectedAt}`;
    if (handled.has(baseId)) return;
    handled.add(baseId);
    await sendSafety(baseId, 'detected', state, detectedAt);
    if (state.violationAutoEnd !== false) {
      await triggerDomEndLive();
      await followClosure(baseId, state, detectedAt);
    }
  }

  function visible(element) {
    if (!element?.isConnected) return false;
    try {
      const style = getComputedStyle(element);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    } catch {
      return true;
    }
  }

  function findVisibleViolation() {
    const selectors = [
      '[role="alert"]',
      '[role="dialog"]',
      '[aria-live="assertive"]',
      '.arco-modal',
      '.arco-notification',
      '[class*="violation" i]',
      '[class*="warning" i]'
    ].join(',');
    for (const element of document.querySelectorAll(selectors)) {
      if (element.closest?.('#plw-liveops-root, #livewel-virtual-camera-surface, #livewel-webrtc-video')) continue;
      if (!visible(element)) continue;
      const text = String(element.innerText || element.textContent || '').replace(/\s+/g, ' ').trim();
      if (text && VIOLATION_PATTERN.test(text)) return text.slice(0, 700);
    }
    return '';
  }

  function recordVisibleViolation(snippet) {
    const signature = snippet.toLowerCase().replace(/\d+/g, '#').slice(0, 240);
    if (signature === lastDomSignature && Date.now() - lastDomDetectedAt < 30_000) return;
    lastDomSignature = signature;
    lastDomDetectedAt = Date.now();
    chrome.storage.local.set({
      lastViolationAt: new Date(lastDomDetectedAt).toISOString(),
      lastViolationSnippet: snippet,
      lastViolationSource: 'tiktok-visible-warning'
    }).catch(() => {});
  }

  function scanVisibleViolation() {
    clearTimeout(domScanTimer);
    const snippet = findVisibleViolation();
    if (snippet) recordVisibleViolation(snippet);
  }

  function queueVisibleViolationScan() {
    clearTimeout(domScanTimer);
    domScanTimer = setTimeout(scanVisibleViolation, 80);
  }

  // Listener para Botão de Pânico / Kill Switch Remoto
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'LIVEOS_EMERGENCY_KILL') {
      void triggerDomEndLive();
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (!['local', 'sync', 'session'].includes(areaName)) return;
    if (changes.lastViolationAt || changes.lastViolationSnippet) {
      const area = chrome.storage[areaName];
      if (area?.get) area.get(null).then((store) => handleState(findViolationState(store))).catch(() => {});
      return;
    }
    for (const change of Object.values(changes)) {
      const state = findViolationState(change?.newValue);
      if (state) void handleState(state);
    }
  });

  Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.sync.get(null).catch(() => ({}))
  ]).then((stores) => {
    for (const store of stores) {
      const state = findViolationState(store);
      if (state) void handleState(state);
    }
  }).catch(() => {});

  const observeTarget = document.body || document.documentElement;
  if (observeTarget) {
    new MutationObserver(queueVisibleViolationScan).observe(observeTarget, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  scanVisibleViolation();
  setInterval(scanVisibleViolation, 650);
})();
