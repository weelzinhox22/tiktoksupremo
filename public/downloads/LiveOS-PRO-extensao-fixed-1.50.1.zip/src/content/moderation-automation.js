(() => {
  'use strict';
  if (globalThis.__LIVEWEL_MODERATION_AUTOMATION__) return;
  globalThis.__LIVEWEL_MODERATION_AUTOMATION__ = true;

  const CONFIG_KEY = 'livewelModerationConfig';
  const LOG_KEY = 'livewelModerationLog';
  const defaults = {
    enabled: false,
    keywords: ['achadinhos', 'shop', 'mais barato', 'ofertas'],
    profiles: []
  };
  let config = { ...defaults };
  let scanBusy = false;
  const attempts = new Map();

  const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
  const normalize = (value) => clean(value).replace(/^@/, '').toLocaleLowerCase('pt-BR');

  function visible(element) {
    if (!element?.isConnected || element.closest?.('#liveos-command-center, #plw-liveops-root')) return false;
    try {
      const style = getComputedStyle(element);
      return style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0;
    } catch {
      return true;
    }
  }

  function authorFromNode(node) {
    const direct = [
      node.getAttribute?.('data-username'),
      node.getAttribute?.('data-user-name'),
      node.querySelector?.('[data-username]')?.getAttribute('data-username'),
      node.querySelector?.('[data-user-name]')?.getAttribute('data-user-name')
    ].map(clean).find(Boolean);
    if (direct) return direct;

    const profileLink = [...(node.querySelectorAll?.('a[href*="/@"], a[href*="/user/"]') || [])][0];
    if (profileLink) {
      const linked = clean(profileLink.textContent) || clean(profileLink.getAttribute('href')?.match(/\/@([^/?#]+)/)?.[1]);
      if (linked) return linked;
    }

    const text = clean(node.innerText || node.textContent);
    const handle = text.match(/@([\p{L}\p{N}._-]{2,40})/u)?.[1];
    if (handle) return handle;
    const prefix = text.match(/^([^:：]{2,45})[:：]/)?.[1];
    if (prefix) return clean(prefix);
    const joined = text.match(/^(.{2,45}?)\s+(?:entrou|entrou na live|joined|começou a seguir)\b/i)?.[1];
    return clean(joined);
  }

  function matchReason(author) {
    const normalized = normalize(author);
    if (!normalized) return '';
    const profiles = (config.profiles || []).map(normalize).filter(Boolean);
    if (profiles.includes(normalized)) return 'perfil específico';
    const keyword = (config.keywords || []).map(normalize).filter(Boolean).find((term) => normalized.includes(term));
    return keyword ? `palavra “${keyword}”` : '';
  }

  async function appendLog(entry) {
    const stored = await chrome.storage.local.get(LOG_KEY);
    const log = Array.isArray(stored[LOG_KEY]) ? stored[LOG_KEY] : [];
    log.push(entry);
    await chrome.storage.local.set({ [LOG_KEY]: log.slice(-100) });
  }

  async function scan() {
    if (scanBusy || !config.enabled || typeof globalThis.PLWDom?.tryBlockNearbyComment !== 'function') return;
    scanBusy = true;
    try {
      const selectors = [
        '[data-e2e*="comment"]', '[class*="CommentItem"]', '[class*="comment-item"]',
        '[class*="ChatMessage"]', '[class*="chat-message"]', '[class*="comment"]',
        '[class*="chat"] [role="listitem"]', '[class*="message"]'
      ];
      const nodes = [...new Set(selectors.flatMap((selector) => [...document.querySelectorAll(selector)]))].slice(-200);
      for (const node of nodes) {
        if (!visible(node)) continue;
        const author = authorFromNode(node);
        const reason = matchReason(author);
        if (!reason) continue;
        const key = normalize(author);
        const previous = attempts.get(key);
        if (previous?.ok || Date.now() - Number(previous?.at || 0) < 30_000) continue;
        attempts.set(key, { at: Date.now(), ok: false });
        const result = await globalThis.PLWDom.tryBlockNearbyComment(clean(author));
        const entry = { author: clean(author), reason, ok: result?.ok === true, at: Date.now(), error: String(result?.reason || '') };
        attempts.set(key, entry);
        await appendLog(entry);
        break;
      }
    } catch (error) {
      console.warn('[LiveWelPro] moderação automática:', error);
    } finally {
      scanBusy = false;
    }
  }

  chrome.storage.local.get(CONFIG_KEY).then((stored) => {
    config = { ...defaults, ...(stored[CONFIG_KEY] || {}) };
    scan();
  }).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[CONFIG_KEY]) {
      config = { ...defaults, ...(changes[CONFIG_KEY].newValue || {}) };
      attempts.clear();
      scan();
    }
  });
  new MutationObserver(() => queueMicrotask(scan)).observe(document.body || document.documentElement, { childList: true, subtree: true });
  setInterval(scan, 1500);
})();
