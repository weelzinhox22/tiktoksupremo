(() => {
  'use strict';
  if (globalThis.__LIVEWEL_AUTOMATION_RUNTIME__) return;
  globalThis.__LIVEWEL_AUTOMATION_RUNTIME__ = true;

  const STORAGE_KEY = 'liveosCommandCenterV1';
  const DEFAULT_URL = 'http://127.0.0.1:18765/';
  const seenComments = new Set();
  const seenSales = new Set();
  const replyQueue = [];
  let initialized = false;
  let settings = {};
  let currentState = {};
  let replyBusy = false;
  let nextReplyAt = 0;
  let retryAt = 0;
  let watchdogFailures = 0;
  let lastWatchdogRestartAt = 0;

  const localControl = (type, payload = {}) => chrome.runtime.sendMessage({ type, url: settings.companionUrl || DEFAULT_URL, ...payload });
  const normalizedCategories = () => new Set(String(settings.autoReplyCategories || 'compra,duvida').split(',').map((item) => item.trim()).filter(Boolean));

  function replyText(comment) {
    const product = (currentState.products || []).find((item) => item.id === currentState.currentProductId);
    const name = String(comment.author || '').replace(/^@/, '').trim().slice(0, 30);
    const prefix = name ? `@${name}, ` : '';
    if (comment.category === 'compra') return `${prefix}${product ? `confira ${product.name} no produto fixado` : 'confira o produto fixado'} para ver preço e condições atualizados.`.slice(0, 200);
    if (comment.category === 'duvida') return `${prefix}vou explicar isso agora; confira também os detalhes do produto fixado.`.slice(0, 200);
    return `${prefix}obrigada por participar! Pode mandar sua dúvida sobre o produto.`.slice(0, 200);
  }

  function eligible(comment) {
    return settings.autoReplyEnabled === true && comment?.status === 'new' && comment.category !== 'risco' && normalizedCategories().has(comment.category || 'geral');
  }

  async function saveStatus(key, value) {
    await chrome.storage.local.set({ [key]: { ...value, at: Date.now() } }).catch(() => {});
  }

  async function pumpReplies() {
    if (replyBusy || !replyQueue.length || Date.now() < retryAt || Date.now() < nextReplyAt) return;
    const item = replyQueue.shift();
    if (!eligible(item.comment)) return;
    replyBusy = true;
    const text = replyText(item.comment);
    try {
      const result = await globalThis.LiveWelComments?.publish(text);
      if (!result?.ok) throw new Error(result?.reason || 'O TikTok não confirmou a resposta.');
      nextReplyAt = Date.now() + Math.max(15, Number(settings.autoReplyMinSec) || 20) * 1000;
      retryAt = 0;
      await saveStatus('livewelAutoReplyStatus', { ok: true, commentId: item.comment.id, text });
    } catch (error) {
      if (item.attempts < 2) replyQueue.unshift({ ...item, attempts: item.attempts + 1 });
      retryAt = Date.now() + 30000;
      await saveStatus('livewelAutoReplyStatus', { ok: false, commentId: item.comment.id, error: String(error?.message || error) });
    } finally { replyBusy = false; }
  }

  async function saveHighlight(sale) {
    const response = await localControl('LIVEOS_CC_HIGHLIGHT', { source: sale?.source || 'sale' }).catch((error) => ({ ok: false, error: String(error) }));
    await saveStatus('livewelHighlightStatus', response?.ok ? { ok: true, saleId: sale?.id } : { ok: false, saleId: sale?.id, error: response?.error || response?.data?.error || 'Destaque não foi salvo.' });
  }

  function acceptState(root = {}) {
    currentState = root;
    settings = root.settings || {};
    const comments = Array.isArray(root.comments) ? root.comments : [];
    const sales = Array.isArray(root.sales) ? root.sales : [];
    if (!initialized) {
      comments.forEach((item) => seenComments.add(item.id));
      sales.forEach((item) => seenSales.add(item.id));
      initialized = true;
      return;
    }
    for (const comment of comments) {
      if (!comment?.id || seenComments.has(comment.id)) continue;
      seenComments.add(comment.id);
      if (eligible(comment) && replyQueue.length < 50) replyQueue.push({ comment, attempts: 0 });
    }
    for (const sale of sales) {
      if (!sale?.id || seenSales.has(sale.id)) continue;
      seenSales.add(sale.id);
      if (settings.autoHighlightEnabled === true) void saveHighlight(sale);
    }
  }

  async function checkCameraWatchdog() {
    if (settings.cameraWatchdogEnabled === false) { watchdogFailures = 0; return; }
    const stored = await chrome.storage.local.get(['livewelCameraFrameAt', 'livewelPlayerOnline', 'livewelPlayerPlaying', 'livewelPlayerUpdatedAt']).catch(() => ({}));
    const frameAt = Number(stored.livewelCameraFrameAt || 0);
    const playerFresh = stored.livewelPlayerOnline && Date.now() - Number(stored.livewelPlayerUpdatedAt || 0) < 12000;
    if (!frameAt || !playerFresh || !stored.livewelPlayerPlaying || Date.now() - frameAt < 6500) { watchdogFailures = 0; return; }
    watchdogFailures += 1;
    if (watchdogFailures < 3 || Date.now() - lastWatchdogRestartAt < 20000) return;
    watchdogFailures = 0;
    lastWatchdogRestartAt = Date.now();
    const response = await localControl('LIVEOS_CC_CAMERA_RESTART', { source: 'browser_watchdog' }).catch((error) => ({ ok: false, error: String(error) }));
    await saveStatus('livewelCameraWatchdogStatus', response?.ok ? { ok: true, reason: 'quadros congelados' } : { ok: false, error: response?.error || 'Falha ao reiniciar a câmera.' });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[STORAGE_KEY]?.newValue) acceptState(changes[STORAGE_KEY].newValue);
  });
  chrome.storage.local.get(STORAGE_KEY).then((stored) => acceptState(stored[STORAGE_KEY] || {})).catch(() => { initialized = true; });
  setInterval(() => void pumpReplies(), 1000);
  setInterval(() => void checkCameraWatchdog(), 2500);
})();
