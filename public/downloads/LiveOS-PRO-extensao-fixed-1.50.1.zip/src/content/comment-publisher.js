(() => {
  'use strict';
  if (globalThis.LiveWelComments) return;

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
  const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 200);

  function visible(element) {
    if (!element?.isConnected || element.disabled || element.readOnly) return false;
    if (element.closest?.('#liveos-command-center, #plw-liveops-root')) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 2 && rect.height > 2;
  }

  function documentRoots() {
    const roots = [document];
    for (const frame of document.querySelectorAll('iframe')) {
      try { if (frame.contentDocument?.documentElement) roots.push(frame.contentDocument); } catch {}
    }
    return roots;
  }

  function candidateScore(element) {
    const hint = `${element.getAttribute?.('placeholder') || ''} ${element.getAttribute?.('aria-label') || ''} ${element.getAttribute?.('data-tid') || ''} ${element.className || ''}`.toLocaleLowerCase('pt-BR');
    const context = String(element.closest?.('form, [class*="chat" i], [class*="comment" i], [class*="message" i]')?.textContent || '').toLocaleLowerCase('pt-BR').slice(0, 500);
    let score = 0;
    if (/m4b_input_textarea|comment|coment|mensagem|message|chat|digite|escreva/.test(hint)) score += 10;
    if (/coment|comment|mensagem|message|chat/.test(context)) score += 4;
    if (element.matches?.('textarea, input, [contenteditable="true"]')) score += 2;
    return score;
  }

  function findInput() {
    const selector = [
      'textarea[data-tid="m4b_input_textarea"]', 'input[data-tid="m4b_input_textarea"]',
      'textarea[placeholder*="coment" i]', 'textarea[placeholder*="comment" i]',
      'textarea[placeholder*="mensagem" i]', 'textarea[placeholder*="digite" i]',
      'input[placeholder*="coment" i]', 'input[placeholder*="comment" i]',
      'input[placeholder*="mensagem" i]', 'input[placeholder*="digite" i]',
      '[contenteditable="true"][aria-label*="coment" i]', '[contenteditable="true"][aria-label*="comment" i]',
      '[contenteditable="true"][data-placeholder*="coment" i]', '[contenteditable="true"][data-placeholder*="comment" i]',
      'textarea', 'input[type="text"]', '[contenteditable="true"]'
    ].join(',');
    const candidates = documentRoots().flatMap((root) => [...root.querySelectorAll(selector)]).filter(visible);
    return candidates.map((element) => ({ element, score: candidateScore(element) }))
      .filter((item) => item.score >= 6).sort((a, b) => b.score - a.score)[0]?.element || null;
  }

  function readValue(element) {
    return element.matches?.('input, textarea') ? String(element.value || '') : String(element.textContent || '');
  }

  function setValue(element, text) {
    element.click();
    element.focus();
    if (element.matches?.('input, textarea')) {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value')?.set;
      if (setter) setter.call(element, text);
      else element.value = text;
    } else {
      element.textContent = text;
    }
    try { element.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: text })); } catch {}
    try { element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); }
    catch { element.dispatchEvent(new Event('input', { bubbles: true })); }
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function findSendButton(input) {
    const containers = [input.closest?.('form'), input.parentElement, input.parentElement?.parentElement, input.closest?.('[class*="chat" i], [class*="comment" i], [class*="message" i]')].filter(Boolean);
    const selector = 'button[type="submit"], button[data-tid*="send" i], button[aria-label*="enviar" i], button[aria-label*="send" i], button[title*="enviar" i], button[title*="send" i], [role="button"]';
    for (const container of containers) {
      const buttons = [...container.querySelectorAll(selector)].filter(visible);
      const matched = buttons.find((button) => /enviar|send|publicar|comentar|comment/.test(`${button.textContent || ''} ${button.getAttribute?.('aria-label') || ''} ${button.getAttribute?.('title') || ''}`.toLocaleLowerCase('pt-BR')));
      if (matched) return matched;
      if (buttons.length === 1) return buttons[0];
    }
    return null;
  }

  async function submit(input, text) {
    setValue(input, text);
    await wait(120);
    const button = findSendButton(input);
    if (button) button.click();
    else {
      for (const type of ['keydown', 'keypress', 'keyup']) {
        input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      }
    }
    const deadline = Date.now() + 2200;
    while (Date.now() < deadline) {
      await wait(120);
      if (!input.isConnected || clean(readValue(input)) !== text) return { ok: true, method: button ? 'button' : 'enter' };
    }
    return { ok: false, reason: 'O TikTok não confirmou o envio. Verifique se a caixa de comentários está aberta e liberada.' };
  }

  async function publish(value) {
    const text = clean(value);
    if (!text) return { ok: false, reason: 'Comentário vazio.' };
    const input = findInput();
    if (!input) return { ok: false, reason: 'Caixa de comentários ativa não encontrada.' };
    try { return await submit(input, text); }
    catch (error) { return { ok: false, reason: String(error?.message || error) }; }
  }

  globalThis.LiveWelComments = Object.freeze({ publish, findInput });
})();
