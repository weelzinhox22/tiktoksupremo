(() => {
  if (globalThis.__LIVEWEL_DASHBOARD_BRIDGE__) return;
  globalThis.__LIVEWEL_DASHBOARD_BRIDGE__ = true;

  function hideLegacyPanels() {
    for (const id of ['plw-liveops-root', 'liveos-command-center']) {
      const panel = document.getElementById(id);
      if (panel) panel.style.setProperty('display', 'none', 'important');
    }
  }

  async function snapshot({ allProducts = false } = {}) {
    const metrics = typeof PLWDom?.scrapeLiveMetrics === 'function' ? await PLWDom.scrapeLiveMetrics() : {};
    const stored = await chrome.storage.local.get('playlist');
    const products = allProducts && typeof PLWDom?.scrapeLiveProductsAll === 'function'
      ? await PLWDom.scrapeLiveProductsAll()
      : Array.isArray(stored.playlist) ? stored.playlist : [];
    const onAir = typeof PLWDom?.isLiveOnAir === 'function' ? PLWDom.isLiveOnAir() : null;
    return { ok: true, metrics: metrics || {}, products: Array.isArray(products) ? products : [], onAir };
  }

  async function execute(action, payload = {}) {
    if (action === 'snapshot' || action === 'import-products') {
      const data = await snapshot({ allProducts: action === 'import-products' });
      if (action === 'import-products' && data.products.length) {
        await chrome.storage.local.set({ playlist: data.products, currentIndex: 0, playlistRunning: false });
      }
      return data;
    }
    if (action === 'pin-position') {
      const position = Math.max(1, Number(payload.position) || 1);
      const result = await PLWDom?.tryPinByBagOrder?.(position);
      return { ok: result !== false, result, position };
    }
    if (action === 'pin-first') {
      const enabled = Boolean(payload.enabled);
      await chrome.storage.local.set({
        livewelKeepFirstPinned: false,
        livewelPinFirstWithoutScroll: enabled,
        pinSkipFirst: false,
        autoRepinEnabled: false,
        currentIndex: 0,
        playlistRunning: false
      });
      if (enabled) await PLWDom?.tryPinByBagOrder?.(1);
      return { ok: true, enabled };
    }
    if (action === 'send-comment') {
      const text = String(payload.text || '').replace(/\s+/g, ' ').trim().slice(0, 200);
      if (!text) return { ok: false, error: 'Comentário vazio.' };
      const result = typeof globalThis.LiveWelComments?.publish === 'function'
        ? await globalThis.LiveWelComments.publish(text)
        : typeof PLWDom?.trySendComment === 'function' ? await PLWDom.trySendComment(text) : null;
      const ok = result === true || result?.ok === true;
      const error = ok ? '' : String(result?.reason || 'Não foi possível publicar o comentário.');
      await chrome.storage.local.set({ livewelCommentPublishStatus: { ok, error, text: text.slice(0, 80), at: Date.now() } }).catch(() => {});
      return { ok, result, error };
    }
    if (action === 'block-profile') {
      const profile = String(payload.profile || '').trim().replace(/^@/, '').slice(0, 40);
      if (!profile) return { ok: false, error: 'Perfil vazio.' };
      if (typeof PLWDom?.tryBlockNearbyComment !== 'function') return { ok: false, error: 'Moderação indisponível.' };
      const result = await PLWDom.tryBlockNearbyComment(profile);
      const blocked = result === true || result?.ok === true;
      return { ok: blocked, blocked, result, error: blocked ? '' : String(result?.reason || 'Perfil não localizado agora.') };
    }
    if (action === 'clear-queue') {
      await chrome.storage.local.set({ playlist: [], currentIndex: 0, playlistRunning: false });
      return { ok: true };
    }
    if (action === 'run-cycle') {
      window.dispatchEvent(new CustomEvent('livewel-run-cycle'));
      return { ok: true };
    }
    return { ok: false, error: 'Comando desconhecido.' };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'LIVEWEL_DASH_COMMAND') return;
    execute(message.action, message.payload).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  });

  new MutationObserver(hideLegacyPanels).observe(document.documentElement, { childList: true, subtree: true });
  hideLegacyPanels();
})();
