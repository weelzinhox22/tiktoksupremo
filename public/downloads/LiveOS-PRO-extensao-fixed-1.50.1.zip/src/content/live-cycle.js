(() => {
  if (globalThis.__LIVEWEL_LIVE_CYCLE__) return;
  globalThis.__LIVEWEL_LIVE_CYCLE__ = true;

  const KEY = 'livewelCycleConfig';
  const defaults = { enabled:false, hours:2, minutes:0, products:'', startedAt:0, lastStatus:'Desativado', lastError:'' };
  let config = { ...defaults };
  let busy = false;
  let card = null;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const visible = (element) => Boolean(element && element.isConnected && element.getClientRects().length && getComputedStyle(element).visibility !== 'hidden');
  const text = (element) => (element?.textContent || '').replace(/\s+/g,' ').trim();
  const findText = (selector, pattern, root=document) => [...root.querySelectorAll(selector)].find((element) => visible(element) && pattern.test(text(element)));
  const click = (element) => { if (!element) return false; element.scrollIntoView({ block:'center', inline:'center' }); element.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true})); element.dispatchEvent(new PointerEvent('pointerup',{bubbles:true})); element.click(); return true; };
  const waitFor = async (finder, timeout=15000, step=250) => { const end=Date.now()+timeout; while(Date.now()<end){ const result=finder(); if(result) return result; await sleep(step); } return null; };
  const durationMs = () => Math.max(60_000, ((Number(config.hours)||0)*60 + (Number(config.minutes)||0))*60_000);

  async function patch(values) {
    config = { ...config, ...values };
    await chrome.storage.local.set({ [KEY]: config });
    renderStatus();
  }

  function setInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
    setter?.call(input, value);
    input.dispatchEvent(new Event('input',{bubbles:true}));
    input.dispatchEvent(new Event('change',{bubbles:true}));
  }

  function isOnAir() {
    try { if (typeof PLWDom?.isLiveOnAir === 'function' && PLWDom.isLiveOnAir() === true) return true; } catch {}
    const body = document.body?.innerText || '';
    return /encerrar\s+live|finalizar\s+live|tempo\s+da\s+live/i.test(body) && !/iniciar\s+live/i.test(body.slice(0,3000));
  }

  async function endLive() {
    await patch({ lastStatus:'Encerrando a LIVE…', lastError:'' });
    let invoked = false;
    try { if (typeof PLWDom?.tryEndLive === 'function') { await PLWDom.tryEndLive(); invoked = true; } } catch {}
    if (!invoked) click(findText('button',[/encerrar\s+live/i,/finalizar\s+live/i][0]));
    await sleep(1200);
    const confirm = findText('button',/^(encerrar|finalizar|confirmar|sim,?\s*encerrar)/i);
    if (confirm) click(confirm);
    await sleep(5000);
  }

  async function openProductDrawer() {
    const add = await waitFor(() => [...document.querySelectorAll('button[data-tid="m4b_button"],button')].find((button) => visible(button) && /^adicionar$/i.test(text(button))), 15000);
    if (!add) throw new Error('Botão Adicionar não encontrado.');
    click(add);
    const option = await waitFor(() => findText('div',/^adicionar produtos$/i), 10000);
    if (!option) throw new Error('Opção Adicionar produtos não encontrada.');
    click(option);
    return waitFor(() => document.querySelector('input[data-tid="m4b_input_search"],input[placeholder*="Pesquisar por nome"]'), 10000);
  }

  async function addConfiguredProducts() {
    const products = String(config.products||'').split(/\n|,/).map((item)=>item.trim()).filter(Boolean);
    if (!products.length) throw new Error('Nenhum ID ou nome de produto configurado.');
    let search = await openProductDrawer();
    if (!search) throw new Error('Campo de pesquisa de produtos não encontrado.');
    for (const query of products) {
      setInputValue(search, query);
      search.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));
      search.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true}));
      await sleep(1800);
      const drawer = search.closest('.arco-drawer,.arco-modal') || document;
      const candidates = [...drawer.querySelectorAll('.arco-checkbox-mask')].filter(visible);
      if (!candidates.length) throw new Error(`Produto não encontrado: ${query}`);
      const matching = candidates.find((mask) => text(mask.closest('[class*="product"],tr,[class*="item"],label') || mask.parentElement).toLowerCase().includes(query.toLowerCase()));
      click(matching || candidates[0]);
      await sleep(600);
    }
    await patch({ lastStatus:`${products.length} produto(s) selecionado(s).` });
    await sleep(5000);
    const close = [...document.querySelectorAll('.arco-drawer-close-icon,[aria-label="Close"],[aria-label="Fechar"]')].find(visible);
    if (close) click(close);
    await sleep(5000);
  }

  async function chooseSource(index, label) {
    const inputs = await waitFor(() => { const found=[...document.querySelectorAll('input[placeholder="Selecionar fonte"]')].filter(visible); return found.length>index ? found : null; }, 15000);
    if (!inputs) throw new Error('Seletores de câmera/microfone não apareceram.');
    click(inputs[index].closest('.arco-select-view') || inputs[index].parentElement);
    const option = await waitFor(() => [...document.querySelectorAll('li[role="option"],.arco-select-option')].find((item)=>visible(item)&&text(item).includes(label)), 8000);
    if (!option) throw new Error(`Fonte não encontrada: ${label}`);
    click(option);
    await sleep(700);
  }

  async function startLive() {
    const start = await waitFor(() => findText('button',/^iniciar live$/i), 15000);
    if (!start) throw new Error('Botão Iniciar LIVE não encontrado.');
    click(start);
    await sleep(1800);
    await chooseSource(0,'LiveWelPro - Câmera Virtual');
    await chooseSource(1,'LiveWelPro - Microfone Virtual');
    const confirm = await waitFor(() => findText('button',/^iniciar live$/i), 8000);
    if (confirm) click(confirm);
    await sleep(8000);
    try { if (typeof PLWDom?.tryPinByBagOrder === 'function') await PLWDom.tryPinByBagOrder(1); } catch {}
  }

  async function runCycle() {
    if (busy || !config.enabled) return;
    busy = true;
    try {
      await endLive();
      await patch({ lastStatus:'Repondo produtos…' });
      await addConfiguredProducts();
      await patch({ lastStatus:'Configurando fontes e reiniciando…' });
      await startLive();
      await patch({ startedAt:Date.now(), lastStatus:'Novo ciclo iniciado.', lastError:'' });
    } catch (error) {
      await patch({ lastStatus:'Ciclo aguardando nova tentativa.', lastError:String(error?.message||error) });
    } finally { busy = false; }
  }

  function renderStatus() {
    if (!card) return;
    const status=card.querySelector('[data-cycle-status]');
    const remaining=config.startedAt ? Math.max(0,config.startedAt+durationMs()-Date.now()) : durationMs();
    const h=Math.floor(remaining/3600000),m=Math.floor((remaining%3600000)/60000),s=Math.floor((remaining%60000)/1000);
    status.textContent = `${config.lastStatus}${config.enabled ? ` · próximo ciclo em ${h}h ${m}m ${s}s` : ''}${config.lastError ? ` · ${config.lastError}` : ''}`;
  }

  function mountCard() {
    if (card?.isConnected) return;
    const pane=document.querySelector('#plw-liveops-root .plw-pane[data-pane="extra"],#plw-liveops-root [data-pane="extra"]');
    if (!pane) return;
    card=document.createElement('section');
    card.className='plw-card'; card.id='livewel-cycle-card';
    card.style.cssText='display:grid;gap:10px;padding:12px;border:1px solid rgba(34,211,238,.28);border-radius:12px;background:rgba(7,17,31,.92)';
    card.innerHTML=`<strong style="font-size:13px">Ciclo programado da LIVE</strong><span style="font-size:10px;color:#8fa7c3">Encerra, repõe os produtos configurados, seleciona as fontes LiveWelPro e inicia novamente.</span><label style="display:flex;gap:8px;font-size:11px"><input data-cycle-enabled type="checkbox"> Ativar reinício automático</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><label style="font-size:10px">Horas<input data-cycle-hours type="number" min="0" max="24" style="width:100%" /></label><label style="font-size:10px">Minutos<input data-cycle-minutes type="number" min="0" max="59" style="width:100%" /></label></div><label style="font-size:10px">IDs ou nomes dos produtos (um por linha)<textarea data-cycle-products rows="4" style="width:100%;resize:vertical" placeholder="1736986474452255915"></textarea></label><div style="display:flex;gap:8px"><button data-cycle-save type="button" class="primary">Salvar ciclo</button><button data-cycle-now type="button">Executar agora</button></div><small data-cycle-status style="color:#8fa7c3;line-height:1.4"></small>`;
    pane.appendChild(card);
    card.querySelector('[data-cycle-enabled]').checked=config.enabled;
    card.querySelector('[data-cycle-hours]').value=config.hours;
    card.querySelector('[data-cycle-minutes]').value=config.minutes;
    card.querySelector('[data-cycle-products]').value=config.products;
    card.querySelector('[data-cycle-save]').addEventListener('click',async()=>{ const enabled=card.querySelector('[data-cycle-enabled]').checked; await patch({enabled,hours:Number(card.querySelector('[data-cycle-hours]').value)||0,minutes:Number(card.querySelector('[data-cycle-minutes]').value)||0,products:card.querySelector('[data-cycle-products]').value.trim(),startedAt:enabled ? Date.now() : 0,lastStatus:enabled?'Ciclo programado.':'Desativado',lastError:''}); });
    card.querySelector('[data-cycle-now]').addEventListener('click',runCycle);
    renderStatus();
  }

  chrome.storage.local.get(KEY).then((stored)=>{config={...defaults,...(stored[KEY]||{})}; mountCard();});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[KEY]?.newValue) config = { ...defaults, ...changes[KEY].newValue };
  });
  window.addEventListener('livewel-run-cycle', () => runCycle());
  new MutationObserver(mountCard).observe(document.documentElement,{childList:true,subtree:true});
  setInterval(()=>{ mountCard(); renderStatus(); if(!config.enabled||busy)return; if(!config.startedAt&&isOnAir())patch({startedAt:Date.now(),lastStatus:'Ciclo iniciado.'}); else if(config.startedAt&&Date.now()>=config.startedAt+durationMs())runCycle(); },1000);
})();
