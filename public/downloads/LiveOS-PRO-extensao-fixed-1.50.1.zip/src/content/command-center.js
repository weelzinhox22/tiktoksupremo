(() => {
  'use strict';
  const PANEL_VERSION = '1.25.2';
  if (globalThis.__LIVEOS_COMMAND_CENTER__) return;
  globalThis.__LIVEOS_COMMAND_CENTER__ = true;

  const STORAGE_KEY = 'liveosCommandCenterV1';
  const MAX_COMMENTS = 250;
  const MAX_EVENTS = 1200;
  const MAX_SALES = 1500;
  const MAX_SESSION_REPORTS = 120;
  const DEFAULTS = {
    version: 1,
    session: { active: false, startedAt: null, id: null },
    currentProductId: null,
    pinStartedAt: null,
    products: [],
    comments: [],
    rundown: [
      { id: 'rd_open', title: 'Abertura e boas-vindas', minutes: 5, done: false },
      { id: 'rd_demo', title: 'Demonstração dos produtos', minutes: 40, done: false },
      { id: 'rd_offer', title: 'Oferta e dúvidas', minutes: 15, done: false },
      { id: 'rd_close', title: 'Resumo e encerramento', minutes: 5, done: false }
    ],
    events: [],
    sales: [],
    analytics: {
      peakViewers: 0,
      viewerSamples: [],
      anomalies: [],
      processedMetricEvents: [],
      sessionReports: [],
      lastSummaryAt: null
    },
    aiHistory: [],
    checklist: {
      disclosure: false, lighting: false, audio: false, productMatch: false,
      stock: false, moderator: false, links: false, camera: false
    },
    settings: {
      pinReminderSec: 30,
      commentScan: true,
      hotkeys: true,
      moderatorMode: false,
      hostPanelPosition: null,
      companionUrl: 'http://127.0.0.1:18765/',
      videoFrameMode: 'fit',
      captureProfile: 'performance',
      safeScale: 1,
      outputFps: 30,
      videoPipelineVersion: 4,
      saleSummaryMinutes: 60,
      maxOrderJump: 10,
      metricConfirmReads: 2,
      defaultCommissionRate: 0,
      telegramSummaryEnabled: true,
      engagementReminderEnabled: false,
      engagementAutoPublish: false,
      engagementMinSec: 45,
      engagementMaxSec: 90,
      engagementTemplates: 'Qual produto vocês querem ver em detalhes?\nAproveitem para conferir o produto fixado e as variações disponíveis.\nFicou alguma dúvida sobre tamanho, cor ou uso? Podem perguntar!\nQuem chegou agora: estamos mostrando as ofertas e respondendo dúvidas ao vivo.',
      autoReplyEnabled: false,
      autoReplyMinSec: 20,
      autoReplyCategories: 'compra,duvida',
      autoHighlightEnabled: false,
      cameraWatchdogEnabled: true,
      riskTerms: 'whatsapp,pix,link na bio,chama no direct,compre fora,garantido,cura,resultado garantido,100% garantido',
      blockedTerms: 'telefone,site externo,qr code,mercado livre,shopee'
    }
  };

  let state = structuredClone(DEFAULTS);
  let panel;
  let launcher;
  let hostProTab;
  let hostProPane;
  let hostProSelected = false;
  let hostScrollTop = 0;
  let preferredHostTabKey = '';
  let lastHostTabRestoreAt = 0;
  let draggingHostPanel = false;
  let fixedHostPosition = null;
  let activeTab = 'now';
  let saveTimer;
  const localStateWrites = new Set();
  let tickTimer;
  let healthTimer;
  let scanTimer;
  let hostState = {};
  let companionOnline = false;
  let healthDetails = {};
  let aiConfig = { provider: 'groq', geminiModel: 'gemini-3.6-flash', groqModel: 'openai/gpt-oss-20b', hasGemini: false, hasGroq: false };
  let telegramConfig = { enabled: true, notifyManual: true, notifyDetected: true, notifySafety: true, chatId: '', hasToken: false, ready: false };
  let aiResult = '';
  let aiBusy = false;
  let lastHostOrders = null;
  let lastHostGmv = null;
  let lastHostCommission = null;
  let metricCandidateKey = '';
  let metricCandidateHits = 0;
  let engagementSuggestion = '';
  let engagementNextAt = null;
  let lastDomActivity = Date.now();
  const seenComments = new Set();
  const processedCommentNodes = new WeakMap();

  const ENGAGEMENT_PRESETS = [
    { id: 'max_safety', label: '🛡️ 60s a 120s (Segurança Máxima · Baixo Risco)', min: 60, max: 120, badge: 'Baixo Risco' },
    { id: 'moderate', label: '⚡ 45s a 90s (Fila Moderada · Baixo Risco)', min: 45, max: 90, badge: 'Baixo Risco' },
    { id: 'long_live', label: '🌙 120s a 300s (Super Seguro · Live Longa)', min: 120, max: 300, badge: 'Baixo Risco' },
    { id: 'busy', label: '🔥 30s a 60s (Live Movimentada · Risco Médio)', min: 30, max: 60, badge: 'Risco Médio' }
  ];

  function findTikTokCommentInput() {
    const selectors = [
      'textarea[data-tid="m4b_input_textarea"]',
      'textarea.m4b-input-textarea',
      'textarea.arco-textarea',
      'textarea[placeholder*="digite" i]',
      'textarea[placeholder*="algo" i]',
      'textarea[placeholder*="coment" i]',
      'textarea[placeholder*="comment" i]',
      'textarea[placeholder*="mensagem" i]',
      'textarea[placeholder*="chat" i]',
      'input[data-tid="m4b_input_textarea"]',
      'input.m4b-input-textarea',
      'input.arco-input',
      'input[placeholder*="digite" i]',
      'input[placeholder*="algo" i]',
      'input[placeholder*="coment" i]',
      'input[placeholder*="comment" i]',
      'input[placeholder*="mensagem" i]',
      'input[placeholder*="chat" i]',
      'div[contenteditable="true"][placeholder*="digite" i]',
      'div[contenteditable="true"][placeholder*="coment" i]',
      'div[contenteditable="true"][placeholder*="comment" i]',
      'div[contenteditable="true"]'
    ];
    const docs = [document];
    try {
      for (const frame of document.querySelectorAll('iframe')) {
        if (frame.contentDocument?.body) docs.push(frame.contentDocument);
      }
    } catch {}
    for (const doc of docs) {
      for (const sel of selectors) {
        const el = doc.querySelector(sel);
        if (el && el.isConnected && (el.offsetWidth > 0 || el.offsetHeight > 0 || el.getClientRects().length > 0)) {
          return el;
        }
      }
    }
    return null;
  }

  async function publishCommentToTikTok(text) {
    if (!text) return false;
    try {
      if (typeof globalThis.LiveWelComments?.publish === 'function') {
        const result = await globalThis.LiveWelComments.publish(text);
        await chrome.storage.local.set({ livewelCommentPublishStatus: { ok: Boolean(result?.ok), error: result?.ok ? '' : String(result?.reason || ''), text: String(text).slice(0, 80), at: Date.now() } }).catch(() => {});
        if (result?.ok) { toast('Comentário publicado no TikTok!'); return true; }
        toast(result?.reason || 'O TikTok não confirmou o comentário.');
        return false;
      }
      if (typeof globalThis.PLWDom?.trySendComment === 'function') {
        const result = await globalThis.PLWDom.trySendComment(text);
        if (result?.ok) {
          toast('Comentário publicado no TikTok!');
          return true;
        }
      }
    } catch {}
    const inputEl = findTikTokCommentInput();
    if (!inputEl) {
      toast('Campo de comentário do TikTok não foi encontrado na página.');
      return false;
    }
    try {
      if (inputEl.disabled) inputEl.disabled = false;
      if (inputEl.hasAttribute('disabled')) inputEl.removeAttribute('disabled');
      if (inputEl.classList?.contains('arco-textarea-disabled')) inputEl.classList.remove('arco-textarea-disabled');
      if (inputEl.classList?.contains('arco-input-disabled')) inputEl.classList.remove('arco-input-disabled');

      inputEl.click();
      inputEl.focus();

      if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
        const prototype = inputEl.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        const nativeSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        if (nativeSetter) nativeSetter.call(inputEl, text);
        else inputEl.value = text;
        try { inputEl.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); } catch {}
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        document.execCommand('insertText', false, text);
        if (!inputEl.textContent) inputEl.innerText = text;
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      }
      setTimeout(() => {
        const container = inputEl.closest('form, div[class*="chat"], div[class*="comment"], div[class*="input"], div[class*="arco-textarea"], div[class*="m4b"]') || inputEl.parentElement;
        const sendBtn = container?.querySelector('button[type="submit"], button[class*="arco-btn"], button[class*="m4b"], button[class*="send" i], button[class*="submit" i], button[class*="publish" i]');
        if (sendBtn) {
          if (sendBtn.disabled) sendBtn.disabled = false;
          if (sendBtn.hasAttribute('disabled')) sendBtn.removeAttribute('disabled');
          sendBtn.click();
        } else {
          const enterEvt = new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, code: 'Enter', which: 13, bubbles: true, cancelable: true });
          inputEl.dispatchEvent(enterEvt);
        }
      }, 100);
      toast('Comentário publicado no TikTok!');
      return true;
    } catch (err) {
      console.error('Erro ao publicar comentário:', err);
      toast('Erro ao tentar publicar comentário no TikTok.');
      return false;
    }
  }

  const $ = (selector, root = panel) => root?.querySelector(selector);
  const $$ = (selector, root = panel) => [...(root?.querySelectorAll(selector) || [])];
  const esc = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const uid = (prefix) => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const proRpc = (message, timeoutMs = 45000) => new Promise((resolve, reject) => {
    const port = chrome.runtime.connect({ name: 'liveos-pro-rpc' });
    const requestId = uid('rpc');
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      try { port.disconnect(); } catch {}
      callback(value);
    };
    const timeout = setTimeout(() => finish(reject, new Error('O serviço demorou para responder. Recarregue a extensão.')), timeoutMs);
    port.onMessage.addListener((response) => {
      if (response?.requestId === requestId) finish(resolve, response);
    });
    port.onDisconnect.addListener(() => {
      if (!settled) finish(reject, new Error('O serviço da extensão foi desconectado. Recarregue em brave://extensions.'));
    });
    port.postMessage({ ...message, requestId });
  });
  const fmtTime = (seconds) => {
    const value = Math.max(0, Number(seconds) || 0);
    const h = Math.floor(value / 3600);
    const m = Math.floor((value % 3600) / 60);
    const s = Math.floor(value % 60);
    return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };
  const formatMoney = (value) => Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const parseProductPrice = (input) => {
    if (!input) return 0;
    const str = typeof input === 'object' ? String(input.price || input.val || '') : String(input);
    if (!str) return 0;
    const cleaned = str.replace(/\u00a0/g, ' ').trim();
    const match = cleaned.match(/(?:R\$|BRL|\$)?\s*(\d[\d.,]*)/i);
    if (!match) return 0;
    let token = match[1];
    if (token.includes(',') && token.includes('.')) token = token.replace(/\./g, '').replace(',', '.');
    else if (token.includes(',')) token = token.replace(',', '.');
    else if (/^\d{1,3}(?:\.\d{3})+$/.test(token)) token = token.replace(/\./g, '');
    const val = Number(token);
    return Number.isFinite(val) && val > 0 ? val : 0;
  };
  const merge = (base, saved) => ({ ...base, ...saved, session: { ...base.session, ...(saved?.session || {}) }, analytics: { ...base.analytics, ...(saved?.analytics || {}) }, settings: { ...base.settings, ...(saved?.settings || {}) }, checklist: { ...base.checklist, ...(saved?.checklist || {}) } });
  const currentProduct = () => state.products.find((item) => item.id === state.currentProductId) || null;

  async function load() {
    try {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      state = merge(structuredClone(DEFAULTS), data[STORAGE_KEY] || {});
      if (Number(data[STORAGE_KEY]?.settings?.videoPipelineVersion) < 4) {
        state.settings.captureProfile = data[STORAGE_KEY]?.settings?.captureProfile === 'low' ? 'low' : 'performance';
        state.settings.safeScale = 1;
        state.settings.outputFps = 30;
        state.settings.videoPipelineVersion = 4;
        await chrome.storage.local.set({ [STORAGE_KEY]: state });
      }
      state.products = Array.isArray(state.products) ? state.products : [];
      state.comments = Array.isArray(state.comments) ? state.comments.slice(0, MAX_COMMENTS) : [];
      state.events = Array.isArray(state.events) ? state.events.slice(-MAX_EVENTS) : [];
      state.sales = Array.isArray(state.sales) ? state.sales.slice(-MAX_SALES) : [];
      state.analytics.viewerSamples = Array.isArray(state.analytics.viewerSamples) ? state.analytics.viewerSamples.slice(-720) : [];
      state.analytics.anomalies = Array.isArray(state.analytics.anomalies) ? state.analytics.anomalies.slice(-100) : [];
      state.analytics.processedMetricEvents = Array.isArray(state.analytics.processedMetricEvents) ? state.analytics.processedMetricEvents.slice(-1000) : [];
      state.analytics.sessionReports = Array.isArray(state.analytics.sessionReports) ? state.analytics.sessionReports.slice(-MAX_SESSION_REPORTS) : [];
      state.aiHistory = Array.isArray(state.aiHistory) ? state.aiHistory.slice(-20) : [];
      state.rundown = Array.isArray(state.rundown) ? state.rundown : structuredClone(DEFAULTS.rundown);
      const savedPosition = state.settings.hostPanelPosition;
      fixedHostPosition = savedPosition && Number.isFinite(savedPosition.left) && Number.isFinite(savedPosition.top)
        ? { left: Math.max(0, savedPosition.left), top: Math.max(0, savedPosition.top) }
        : null;
      state.comments.forEach((item) => seenComments.add(item.id));
    } catch (error) { console.warn('[LiveOS Central] Falha ao carregar:', error); }
  }

  function save(immediate = false) {
    clearTimeout(saveTimer);
    const run = () => {
      const snapshot = structuredClone(state);
      const snapshotJson = JSON.stringify(snapshot);
      localStateWrites.add(snapshotJson);
      setTimeout(() => localStateWrites.delete(snapshotJson), 5000);
      chrome.storage.local.set({ [STORAGE_KEY]: snapshot }).catch(() => {});
    };
    if (immediate) run(); else saveTimer = setTimeout(run, 220);
  }

  function log(type, data = {}) {
    state.events.push({ id: uid('ev'), type, at: Date.now(), productId: state.currentProductId, ...data });
    if (state.events.length > MAX_EVENTS) state.events.splice(0, state.events.length - MAX_EVENTS);
    save();
  }

  function toast(message) {
    $('.locc-toast')?.remove();
    const node = document.createElement('div');
    node.className = 'locc-toast';
    node.textContent = message;
    panel.appendChild(node);
    setTimeout(() => node.remove(), 2800);
  }

  function build() {
    launcher = document.createElement('button');
    launcher.id = 'liveos-cc-launcher';
    launcher.type = 'button';
    launcher.title = 'Abrir Central Ao Vivo (Ctrl+Shift+O)';
    launcher.textContent = 'IA';
    document.documentElement.appendChild(launcher);

    panel = document.createElement('section');
    panel.id = 'liveos-command-center';
    panel.hidden = true;
    panel.innerHTML = `
      <header class="locc-head">
        <div class="locc-logo">L</div>
        <div class="locc-head-copy"><strong>Central Ao Vivo</strong><small><i class="locc-status-dot"></i><span data-role="head-status">pronta para configurar</span></small></div>
        <button class="locc-icon-btn" data-action="moderator" title="Modo moderador">M</button>
        <button class="locc-icon-btn" data-action="close" title="Fechar">×</button>
      </header>
      <nav class="locc-tabs" aria-label="Seções">
        <button class="locc-tab active" data-tab="now">Agora</button>
        <button class="locc-tab" data-tab="comments">Comentários <span data-role="priority-count"></span></button>
        <button class="locc-tab" data-tab="ai">IA</button>
        <button class="locc-tab" data-tab="telegram">Telegram</button>
        <button class="locc-tab" data-tab="products">Produtos</button>
        <button class="locc-tab" data-tab="rundown">Roteiro</button>
        <button class="locc-tab" data-tab="metrics">Métricas</button>
        <button class="locc-tab" data-tab="safety">Segurança</button>
        <button class="locc-tab" data-tab="settings">Config.</button>
      </nav>
      <main class="locc-body">
        <div class="locc-pane" data-pane="now"></div>
        <div class="locc-pane" data-pane="comments" hidden></div>
        <div class="locc-pane" data-pane="ai" hidden></div>
        <div class="locc-pane" data-pane="telegram" hidden></div>
        <div class="locc-pane" data-pane="products" hidden></div>
        <div class="locc-pane" data-pane="rundown" hidden></div>
        <div class="locc-pane" data-pane="metrics" hidden></div>
        <div class="locc-pane" data-pane="safety" hidden></div>
        <div class="locc-pane" data-pane="settings" hidden></div>
      </main>`;
    document.documentElement.appendChild(panel);
    launcher.addEventListener('click', open);
    panel.addEventListener('click', onClick);
    panel.addEventListener('change', onChange);
    panel.addEventListener('submit', onSubmit);
    applyMode();
    renderAll();
    attachToFullPanel();
  }

  function open(tab = activeTab) {
    hostProSelected = true;
    if (attachToFullPanel()) activateHostProPane();
    panel.hidden = false;
    if (launcher) launcher.hidden = true;
    switchTab(tab);
  }
  function close() {
    if (hostProPane?.isConnected) {
      const fallback = [...hostProTab.parentElement.querySelectorAll('.plw-tab')].find((item) => item !== hostProTab);
      if (fallback) return fallback.click();
    }
    panel.hidden = true;
    launcher.hidden = false;
  }

  function activateHostProPane() {
    const root = hostProPane?.closest('#plw-liveops-root');
    if (!root) return;
    hostProSelected = true;
    preferredHostTabKey = 'id:plw-liveos-pro-tab';
    root.classList.remove('collapsed', 'hidden');
    root.querySelectorAll('.plw-tab.active').forEach((item) => item.classList.remove('active'));
    root.querySelectorAll('.plw-pane.active').forEach((item) => item.classList.remove('active'));
    hostProTab.classList.add('active');
    hostProPane.classList.add('active');
  }

  function hostTabKey(tab) {
    if (!tab) return '';
    if (tab.id) return `id:${tab.id}`;
    const dataKey = tab.dataset.tab || tab.dataset.pane || tab.getAttribute('aria-controls');
    if (dataKey) return `data:${dataKey}`;
    return `text:${String(tab.textContent || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('pt-BR')}`;
  }

  function hideLegacyWindowsApp(root = document.querySelector('#plw-liveops-root')) {
    if (!root) return;
    [...root.querySelectorAll('.plw-install-card')].forEach((card) => {
      card.classList.add('plw-legacy-windows-app');
      if (!card.hidden) card.hidden = true;
    });
  }

  function ensureVideoTools(root = document.querySelector('#plw-liveops-root')) {
    const pane = root?.querySelector('.plw-pane[data-pane="video"]');
    if (!pane || pane.querySelector('#plw-overlays-launcher-tools')) return;

    // Card 1: Overlays Dinâmicos & Player Feed
    const overlayCard = document.createElement('section');
    overlayCard.id = 'plw-overlays-launcher-tools';
    overlayCard.className = 'plw-card';
    overlayCard.style.border = '1px solid #2dd4bf55';
    overlayCard.style.background = 'linear-gradient(135deg, rgba(16, 24, 32, 0.95), rgba(15, 23, 42, 0.95))';
    overlayCard.style.padding = '12px';
    overlayCard.style.marginBottom = '10px';
    overlayCard.style.borderRadius = '10px';
    overlayCard.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <span class="plw-install-title" style="color:#2dd4bf; font-weight:800; font-size:13px;">🎥 LiveWelPro Câmera & Overlays</span>
        <span style="background:rgba(45,212,191,0.2); color:#2dd4bf; border-radius:999px; padding:2px 8px; font-size:10px; font-weight:700;">Ao Vivo</span>
      </div>
      <p class="plw-install-hint" style="font-size:11px; margin-bottom:10px; color:#94a3b8;">
        Vídeos POV, cronômetro de oferta auto-reset, banners rotativos e anti-hash.
      </p>
      <input type="file" id="plw-direct-video-input" accept="video/*" multiple style="display:none;" />
      <div style="display:grid; gap:8px;">
        <button type="button" class="plw-academia-btn btn-pick-video" style="background:linear-gradient(135deg, #10b981, #059669); color:#fff; font-weight:800; border:none; border-radius:8px; padding:10px; cursor:pointer;">
          📁 Selecionar Vídeos (Múltiplos Takes POV)
        </button>
        <button type="button" class="plw-academia-btn btn-open-feed-player" style="background:linear-gradient(135deg, #0d9488, #0284c7); color:#fff; font-weight:700; border:none; border-radius:8px; padding:8px; cursor:pointer;">
          🎬 Abrir Player & Customizar Overlays
        </button>
        <button type="button" class="plw-academia-btn btn-open-mobile-pwa" style="background:rgba(45,212,191,0.15); border:1px solid #2dd4bf; color:#ecfeff; font-weight:700; border-radius:8px; padding:8px; cursor:pointer;">
          📱 Abrir Controle no Celular
        </button>
      </div>
    `;

    const videoInput = overlayCard.querySelector('#plw-direct-video-input');
    let videoPlaylist = [];
    let currentVideoIdx = 0;

    overlayCard.querySelector('.btn-pick-video')?.addEventListener('click', () => {
      videoInput?.click();
    });

    videoInput?.addEventListener('change', (e) => {
      const files = [...(e.target.files || [])];
      if (!files.length) return;
      videoPlaylist = files;
      currentVideoIdx = 0;
      const file = videoPlaylist[0];
      const url = URL.createObjectURL(file);
      window.postMessage({
        source: 'LIVEWELPRO_EXTENSION',
        type: 'SET_VIDEO_SRC',
        blobUrl: url
      }, '*');
      const btnPick = overlayCard.querySelector('.btn-pick-video');
      if (btnPick) btnPick.textContent = `✅ ${files.length} Take(s) POV Ativo(s)`;
    });

    overlayCard.querySelector('.btn-open-feed-player')?.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'LIVEOS_OPEN_PLAYER_WINDOW' }).catch(() => {});
    });

    overlayCard.querySelector('.btn-open-mobile-pwa')?.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'LIVEOS_OPEN_MOBILE_WINDOW' }).catch(() => {});
    });

    pane.insertBefore(overlayCard, pane.firstChild);

    // Card 2: Importador de produtos
    if (!pane.querySelector('#plw-product-page-tools')) {
      const card = document.createElement('section');
      card.id = 'plw-product-page-tools';
      card.className = 'plw-card plw-product-page-tools';
      card.innerHTML = '<span class="plw-install-title">Produtos do TikTok Shop</span><p class="plw-install-hint">Leia nome, preço, estoque e imagem diretamente da lista de produtos aberta nesta página.</p><button type="button" class="plw-academia-btn">Abrir importador de produtos</button>';
      card.querySelector('button').addEventListener('click', () => {
        hostProSelected = true;
        panel.hidden = false;
        activateHostProPane();
        switchTab('products');
        panel.querySelector('[data-action="import-products"]')?.click();
      });
      pane.appendChild(card);
    }
  }

  function ensureAudioTools(root = document.querySelector('#plw-liveops-root')) {
    const pane = root?.querySelector('.plw-pane[data-pane="audio"]');
    if (!pane || pane.querySelector('#plw-livewelpro-audio-tools')) return;

    const audioCard = document.createElement('section');
    audioCard.id = 'plw-livewelpro-audio-tools';
    audioCard.className = 'plw-card';
    audioCard.style.border = '1px solid #f59e0b55';
    audioCard.style.background = 'linear-gradient(135deg, rgba(16, 24, 32, 0.95), rgba(15, 23, 42, 0.95))';
    audioCard.style.padding = '12px';
    audioCard.style.marginBottom = '10px';
    audioCard.style.borderRadius = '10px';
    audioCard.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <span class="plw-install-title" style="color:#f59e0b; font-weight:800; font-size:13px;">🎙️ LiveWelPro Microfone & Picotagem</span>
        <span style="background:rgba(245,158,11,0.2); color:#fbbf24; border-radius:999px; padding:2px 8px; font-size:10px; font-weight:700;">Anti-Ban Ativo</span>
      </div>
      <p class="plw-install-hint" style="font-size:11px; margin-bottom:10px; color:#94a3b8;">
        Adicione múltiplos áudios sem limite. O motor faz a picotagem e rotação contínua para o microfone virtual do TikTok.
      </p>

      <input type="file" id="plw-direct-audio-input" accept="audio/*" multiple style="display:none;" />
      
      <div style="display:grid; gap:8px;">
        <button type="button" class="plw-academia-btn btn-pick-audio" style="background:linear-gradient(135deg, #f59e0b, #d97706); color:#fff; font-weight:800; border:none; border-radius:8px; padding:10px; cursor:pointer;">
          🎵 Adicionar Áudios (Sem Limite de Músicas)
        </button>
      </div>

      <!-- Controles de Picotagem e Duração -->
      <div style="margin-top:10px; padding:8px; background:rgba(0,0,0,0.3); border-radius:8px; border:1px solid rgba(255,255,255,0.08);">
        <label style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#e2e8f0; cursor:pointer;">
          <input type="checkbox" id="plw-audio-picotagem-tog" checked />
          Picotar faixas automaticamente (anti-detecção)
        </label>

        <label style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:#e2e8f0; margin-top:6px; cursor:pointer;">
          <input type="checkbox" id="plw-audio-loop-tog" checked />
          Loop infinito (ShuffleBag sem repetição)
        </label>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:8px;">
          <div>
            <div style="display:flex; justify-content:space-between; font-size:10px; color:#94a3b8;">
              <span>Duração Mínima:</span>
              <b id="plw-dur-min-val" style="color:#f59e0b;">4s</b>
            </div>
            <input type="range" id="plw-dur-min" min="2" max="30" value="4" style="width:100%;" />
          </div>

          <div>
            <div style="display:flex; justify-content:space-between; font-size:10px; color:#94a3b8;">
              <span>Duração Máxima:</span>
              <b id="plw-dur-max-val" style="color:#f59e0b;">12s</b>
            </div>
            <input type="range" id="plw-dur-max" min="4" max="60" value="12" style="width:100%;" />
          </div>
        </div>

        <div style="margin-top:6px;">
          <div style="display:flex; justify-content:space-between; font-size:10px; color:#94a3b8;">
            <span>Pausa entre trechos (gap):</span>
            <b id="plw-gap-val" style="color:#f59e0b;">1.0s</b>
          </div>
          <input type="range" id="plw-dur-gap" min="0" max="8" step="0.5" value="1" style="width:100%;" />
        </div>
      </div>

      <!-- Status e Controles Rápidos -->
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
        <button type="button" id="plw-audio-btn-pause" style="background:#334155; color:#fff; border:none; padding:4px 10px; border-radius:6px; font-size:11px; font-weight:700; cursor:pointer;">⏸ Pausar</button>
        <button type="button" id="plw-audio-btn-play" style="background:#0d9488; color:#fff; border:none; padding:4px 10px; border-radius:6px; font-size:11px; font-weight:700; cursor:pointer;">▶ Play</button>
        <button type="button" id="plw-audio-btn-next" style="background:#d97706; color:#fff; border:none; padding:4px 10px; border-radius:6px; font-size:11px; font-weight:700; cursor:pointer;">⏭ Pular Trecho</button>
      </div>

      <div id="plw-audio-playlist-status" style="margin-top:8px; font-size:11px; color:#34d399; font-weight:600; word-break:break-word;">
        Aguardando áudios...
      </div>
    `;

    const audioInput = audioCard.querySelector('#plw-direct-audio-input');
    const statusEl = audioCard.querySelector('#plw-audio-playlist-status');
    const togPicotagem = audioCard.querySelector('#plw-audio-picotagem-tog');
    const togLoop = audioCard.querySelector('#plw-audio-loop-tog');
    const durMinInput = audioCard.querySelector('#plw-dur-min');
    const durMinVal = audioCard.querySelector('#plw-dur-min-val');
    const durMaxInput = audioCard.querySelector('#plw-dur-max');
    const durMaxVal = audioCard.querySelector('#plw-dur-max-val');
    const durGapInput = audioCard.querySelector('#plw-dur-gap');
    const durGapVal = audioCard.querySelector('#plw-dur-gap-val');

    let playlist = [];
    let audioPlaying = false;
    let currentTimer = null;
    let currentSliceIdx = 0;

    durMinInput?.addEventListener('input', () => {
      let min = Number(durMinInput.value);
      let max = Number(durMaxInput.value);
      if (min > max) { max = min; durMaxInput.value = max; durMaxVal.textContent = max + 's'; }
      durMinVal.textContent = min + 's';
    });

    durMaxInput?.addEventListener('input', () => {
      let min = Number(durMinInput.value);
      let max = Number(durMaxInput.value);
      if (max < min) { min = max; durMinInput.value = min; durMinVal.textContent = min + 's'; }
      durMaxVal.textContent = max + 's';
    });

    durGapInput?.addEventListener('input', () => {
      durGapVal.textContent = Number(durGapInput.value).toFixed(1) + 's';
    });

    audioCard.querySelector('.btn-pick-audio')?.addEventListener('click', () => {
      audioInput?.click();
    });

    function playSlice() {
      if (!playlist.length || !audioPlaying) return;
      if (currentTimer) clearTimeout(currentTimer);

      // Escolhe próxima faixa
      currentSliceIdx = (currentSliceIdx + 1) % playlist.length;
      const file = playlist[currentSliceIdx];
      const url = URL.createObjectURL(file);

      const isPicotagem = togPicotagem?.checked !== false;
      const minD = Math.max(1, Number(durMinInput?.value) || 4);
      const maxD = Math.max(minD, Number(durMaxInput?.value) || 12);
      const gapMs = (Number(durGapInput?.value) || 1) * 1000;

      let sliceLen = isPicotagem ? minD + Math.random() * (maxD - minD) : 300;
      let startOffset = isPicotagem ? Math.random() * 8 : 0;

      window.postMessage({
        source: 'LIVEWELPRO_EXTENSION',
        type: 'SET_AUDIO_SRC',
        blobUrl: url,
        currentTime: startOffset
      }, '*');

      if (statusEl) {
        statusEl.textContent = isPicotagem 
          ? `🎵 Picotando (${currentSliceIdx + 1}/${playlist.length}): ${file.name.slice(0, 22)}... [${sliceLen.toFixed(1)}s]`
          : `▶️ Tocando (${currentSliceIdx + 1}/${playlist.length}): ${file.name.slice(0, 22)}...`;
      }

      if (isPicotagem) {
        currentTimer = setTimeout(() => {
          if (!audioPlaying) return;
          window.postMessage({ source: 'LIVEWELPRO_EXTENSION', type: 'AUDIO_PAUSE' }, '*');
          currentTimer = setTimeout(() => {
            if (audioPlaying) playSlice();
          }, gapMs);
        }, sliceLen * 1000);
      }
    }

    audioInput?.addEventListener('change', (e) => {
      const files = [...(e.target.files || [])];
      if (!files.length) return;
      playlist = files;
      currentSliceIdx = -1;
      audioPlaying = true;
      playSlice();
      if (statusEl) statusEl.textContent = `✅ ${playlist.length} áudio(s) carregado(s)! Iniciando picotagem...`;
    });

    audioCard.querySelector('#plw-audio-btn-pause')?.addEventListener('click', () => {
      audioPlaying = false;
      if (currentTimer) clearTimeout(currentTimer);
      window.postMessage({ source: 'LIVEWELPRO_EXTENSION', type: 'AUDIO_PAUSE' }, '*');
      if (statusEl) statusEl.textContent = '⏸ Áudio pausado no microfone virtual.';
    });

    audioCard.querySelector('#plw-audio-btn-play')?.addEventListener('click', () => {
      if (!playlist.length) return;
      audioPlaying = true;
      playSlice();
    });

    audioCard.querySelector('#plw-audio-btn-next')?.addEventListener('click', () => {
      if (!playlist.length) return;
      audioPlaying = true;
      playSlice();
    });

    pane.insertBefore(audioCard, pane.firstChild);
  }

  function ensureHostStability() {
    const root = document.querySelector('#plw-liveops-root');
    if (!root) return;
    hideLegacyWindowsApp(root);
    ensureVideoTools(root);
    ensureAudioTools(root);
    if (fixedHostPosition && root.classList.contains('unlocked') && !draggingHostPanel) {
      const rect = root.getBoundingClientRect();
      if (Math.abs(rect.left - fixedHostPosition.left) > 2 || Math.abs(rect.top - fixedHostPosition.top) > 2) {
        root.style.setProperty('left', `${fixedHostPosition.left}px`, 'important');
        root.style.setProperty('top', `${fixedHostPosition.top}px`, 'important');
        root.style.setProperty('right', 'auto', 'important');
        root.style.setProperty('bottom', 'auto', 'important');
      }
    }
    if (hostProSelected) {
      if (!hostProTab?.isConnected || !hostProPane?.isConnected || !hostProTab.classList.contains('active') || !hostProPane.classList.contains('active')) attachToFullPanel();
      return;
    }
    if (!preferredHostTabKey || Date.now() - lastHostTabRestoreAt < 180) return;
    const tabs = [...root.querySelectorAll('.plw-tabs .plw-tab')];
    const preferred = tabs.find((tab) => hostTabKey(tab) === preferredHostTabKey);
    if (preferred && !preferred.classList.contains('active')) {
      lastHostTabRestoreAt = Date.now();
      preferred.click();
    }
  }

  function onHostPointerDown(event) {
    const root = event.target.closest?.('#plw-liveops-root.unlocked');
    if (!root || !event.target.closest('.plw-head') || event.target.closest('button,input,select,textarea,a')) return;
    draggingHostPanel = true;
  }

  function onHostPointerUp() {
    if (!draggingHostPanel) return;
    draggingHostPanel = false;
    setTimeout(() => {
      const root = document.querySelector('#plw-liveops-root.unlocked');
      if (!root) return;
      const rect = root.getBoundingClientRect();
      fixedHostPosition = { left: Math.max(0, Math.round(rect.left)), top: Math.max(0, Math.round(rect.top)) };
      state.settings.hostPanelPosition = { ...fixedHostPosition };
      save(true);
      root.style.setProperty('left', `${fixedHostPosition.left}px`, 'important');
      root.style.setProperty('top', `${fixedHostPosition.top}px`, 'important');
      root.style.setProperty('right', 'auto', 'important');
      root.style.setProperty('bottom', 'auto', 'important');
    }, 80);
  }

  function attachToFullPanel() {
    const root = document.querySelector('#plw-liveops-root');
    const tabs = root?.querySelector('.plw-tabs');
    const body = root?.querySelector('.plw-body');
    if (!root || !tabs || !body || !panel) return false;
    root.classList.add('plw-has-pro');
    hideLegacyWindowsApp(root);
    ensureVideoTools(root);
    ensureAudioTools(root);
    hostProTab = root.querySelector('#plw-liveos-pro-tab');
    hostProPane = root.querySelector('#plw-liveos-pro-pane');
    let rebuilt = false;
    if (!hostProTab) {
      rebuilt = true;
      hostProTab = document.createElement('button');
      hostProTab.id = 'plw-liveos-pro-tab';
      hostProTab.type = 'button';
      hostProTab.className = 'plw-tab';
      hostProTab.textContent = 'PRO';
      hostProTab.title = 'IA, Telegram e Central Ao Vivo';
      tabs.appendChild(hostProTab);
      hostProTab.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        hostProSelected = true;
        activateHostProPane();
        panel.hidden = false;
        switchTab(activeTab);
      }, true);
    }
    if (!hostProPane) {
      rebuilt = true;
      hostProPane = document.createElement('section');
      hostProPane.id = 'plw-liveos-pro-pane';
      hostProPane.className = 'plw-pane';
      body.appendChild(hostProPane);
    }
    if (panel.parentElement !== hostProPane) hostProPane.appendChild(panel);
    panel.classList.add('locc-embedded');
    launcher.hidden = true;
    if (!root.dataset.liveosProNavigation) {
      root.dataset.liveosProNavigation = '1';
      if (!preferredHostTabKey) preferredHostTabKey = hostTabKey(root.querySelector('.plw-tabs .plw-tab.active'));
      root.addEventListener('click', (event) => {
        const tab = event.target.closest('.plw-tab');
        if (!tab) return;
        preferredHostTabKey = hostTabKey(tab);
        if (tab === hostProTab) return;
        hostProSelected = false;
        hostProTab?.classList.remove('active');
        hostProPane?.classList.remove('active');
      }, true);
      root.addEventListener('scroll', (event) => {
        if (hostProSelected && event.target.matches?.('.plw-scroll')) hostScrollTop = event.target.scrollTop;
      }, true);
    }
    if (hostProSelected && (!hostProTab.classList.contains('active') || !hostProPane.classList.contains('active'))) {
      panel.hidden = false;
      activateHostProPane();
      if (rebuilt) requestAnimationFrame(() => {
        const scroll = root.querySelector('.plw-scroll');
        if (scroll) scroll.scrollTop = hostScrollTop;
      });
    }
    return true;
  }
  function switchTab(tab) {
    activeTab = tab;
    $$('.locc-tab').forEach((button) => button.classList.toggle('active', button.dataset.tab === tab));
    $$('.locc-pane').forEach((pane) => { pane.hidden = pane.dataset.pane !== tab; });
    render(tab);
  }

  function applyMode() {
    panel?.classList.toggle('locc-moderator', Boolean(state.settings.moderatorMode));
    if (state.settings.moderatorMode && !['comments', 'ai', 'products'].includes(activeTab)) activeTab = 'comments';
  }

  function renderAll() {
    ['now', 'comments', 'ai', 'telegram', 'products', 'rundown', 'metrics', 'safety', 'settings'].forEach(render);
    updateHeader();
  }
  function render(tab) {
    const pane = $(`[data-pane="${tab}"]`);
    if (!pane) return;
    const renderers = { now: renderNow, comments: renderComments, ai: renderAi, telegram: renderTelegram, products: renderProducts, rundown: renderRundown, metrics: renderMetrics, safety: renderSafety, settings: renderSettings };
    pane.innerHTML = renderers[tab]();
  }

  function updateHeader() {
    const dot = $('.locc-status-dot');
    const text = $('[data-role="head-status"]');
    if (!dot || !text) return;
    dot.classList.toggle('ok', state.session.active);
    text.textContent = state.session.active ? `live ativa · ${fmtTime((Date.now() - state.session.startedAt) / 1000)}` : 'pronta para configurar';
    const priority = state.comments.filter((item) => item.status === 'new' && ['compra', 'duvida', 'risco'].includes(item.category)).length;
    const count = $('[data-role="priority-count"]');
    if (count) count.textContent = priority ? `(${priority})` : '';
  }

  function renderNow() {
    const product = currentProduct();
    const pinElapsed = state.pinStartedAt ? (Date.now() - state.pinStartedAt) / 1000 : 0;
    const reminder = Number(state.settings.pinReminderSec || 30);
    const next = state.products.length ? state.products[(Math.max(0, state.products.findIndex((item) => item.id === state.currentProductId)) + 1) % state.products.length] : null;
    const sales = state.sales.filter((item) => !state.session.startedAt || item.at >= state.session.startedAt);
    const gmv = sales.reduce((sum, item) => sum + Number(item.value || 0), 0);
    const hasPanelGmv = hostState.metricsTrusted === true && Number.isFinite(Number(hostState.gmvCurrent));
    const displayGmv = hasPanelGmv ? Number(hostState.gmvCurrent) : gmv;
    const displayOrders = hostState.metricsTrusted === true && Number.isFinite(Number(hostState.gmvOrders)) ? Number(hostState.gmvOrders) : totalQuantity(sales);
    const displayCommission = Number.isFinite(Number(hostState.gmvCommission)) ? Number(hostState.gmvCommission) : sales.reduce((sum, item) => sum + saleCommission(item), 0);
    const appStatus = healthDetails.status === 'playing' ? 'reproduzindo' : healthDetails.status === 'stopped' ? 'parado' : healthDetails.status || (companionOnline ? 'conectado' : 'offline');
    const appQueue = Number.isFinite(healthDetails.totalVideos) ? `${healthDetails.currentIndex + 1}/${healthDetails.totalVideos}` : '';
    return `<div class="locc-grid">
      <div class="locc-card"><span class="locc-label">Tempo de live</span><div class="locc-big" data-live-clock>${state.session.active ? fmtTime((Date.now() - state.session.startedAt) / 1000) : '00:00'}</div><button class="locc-btn ${state.session.active ? 'danger' : 'primary'}" data-action="toggle-session">${state.session.active ? 'Encerrar sessão' : 'Iniciar sessão'}</button></div>
      <div class="locc-card"><span class="locc-label">${hasPanelGmv ? 'GMV pago do painel' : 'GMV registrado'}</span><div class="locc-big">${formatMoney(displayGmv)}</div><small class="locc-muted">${displayOrders} pedido(s)${hasPanelGmv ? ' · leitura confirmada' : ' · aguardando métrica confiável'}${displayCommission > 0 ? ` · comissão ${formatMoney(displayCommission)}` : ''}</small></div>
      <div class="locc-card locc-span2"><div class="locc-row locc-between"><div><span class="locc-label">Produto no ar</span><div class="locc-big">${esc(product?.name || 'Nenhum produto marcado')}</div></div><span class="locc-chip ${pinElapsed >= reminder ? 'warn' : ''}" data-pin-clock>${state.pinStartedAt ? fmtTime(pinElapsed) : '--:--'}</span></div>
        ${product ? `<p>${esc(product.pitch || 'Adicione os principais benefícios no cartão do produto.')}</p><div class="locc-row-wrap"><button class="locc-btn primary" data-action="refresh-pin">Renovei o pin</button><button class="locc-btn" data-action="copy-pitch">Copiar argumento</button><button class="locc-btn" data-action="sale">+ Venda</button><button class="locc-btn" data-action="next-product">Próximo produto</button></div>` : `<p class="locc-muted">Cadastre produtos e marque o que foi fixado no TikTok.</p><button class="locc-btn" data-tab="products">Cadastrar produtos</button>`}
      </div>
      <div class="locc-card locc-span2"><span class="locc-label">Próxima ação</span><strong>${esc(next ? `Preparar: ${next.name}` : 'Cadastre sua sequência de produtos')}</strong><p class="locc-muted">${esc(next?.script || next?.objections || 'Use o roteiro para conduzir cada bloco da apresentação.')}</p></div>
      <div class="locc-card locc-span2"><div class="locc-row locc-between"><span class="locc-label">App local · porta 18765</span><button class="locc-btn ghost" data-action="health-check">Testar agora</button></div><div class="locc-health"><div>Conexão<b>${companionOnline ? 'conectado' : 'offline'}</b></div><div>Status<b>${esc(appStatus)}${appQueue ? ` · ${esc(appQueue)}` : ''}</b></div><div>Câmera/áudio<b>${esc(healthDetails.label || (companionOnline ? 'sem telemetria' : 'indisponível'))}</b></div></div>${companionOnline ? '<div class="locc-row-wrap"><button class="locc-btn primary" data-action="app-command" data-command="play">▶ Reproduzir</button><button class="locc-btn" data-action="app-command" data-command="pause">⏸ Pausar</button><button class="locc-btn" data-action="app-command" data-command="next">⏭ Próximo</button></div>' : '<div class="locc-warning">Abra o seu app e confirme que ele responde em 127.0.0.1:18765.</div>'}</div>
    </div>`;
  }

  function classify(text) {
    const value = text.toLocaleLowerCase('pt-BR');
    if (/(whats|pix|telefone|direct|link|site|fora do tiktok)/i.test(value)) return 'risco';
    if (/(pre[cç]o|valor|quanto|cupom|desconto|frete|entrega|estoque|tem ainda|comprar)/i.test(value)) return 'compra';
    if (/(tamanho|medida|cor|garantia|serve|funciona|como|qual|pode|onde|quando|\?)/i.test(value)) return 'duvida';
    return 'geral';
  }

  function renderComments() {
    const order = { risco: 0, compra: 1, duvida: 2, geral: 3 };
    const comments = [...state.comments].filter((item) => item.status !== 'hidden').sort((a, b) => (order[a.category] - order[b.category]) || (b.at - a.at));
    const labels = { risco: 'Revisar', compra: 'Intenção de compra', duvida: 'Dúvida', geral: 'Geral' };
    const reminder = engagementNextAt ? Math.max(0, Math.ceil((engagementNextAt - Date.now()) / 1000)) : null;
    const minSec = Number(state.settings.engagementMinSec) || 45;
    const maxSec = Number(state.settings.engagementMaxSec) || 90;
    const isAuto = Boolean(state.settings.engagementAutoPublish);
    const isLowRisk = minSec >= 45;
    return `<div class="locc-card"><div class="locc-row locc-between"><div><span class="locc-label">Fila prioritária</span><strong>${comments.length} comentário(s)</strong></div><div class="locc-row"><button class="locc-btn ghost" data-action="scan-now">Buscar agora</button><button class="locc-btn ghost" data-action="clear-comments">Limpar</button></div></div></div>
      <div class="locc-card locc-stack">
        <div class="locc-row locc-between">
          <div>
            <span class="locc-label">Comentários Automáticos de Engajamento</span>
            <small class="locc-muted">Status: <strong>${state.settings.engagementReminderEnabled ? (isAuto ? 'Envio 100% Automático' : 'Lembrete Manual') : 'Desativado'}</strong> · Intervalo: ${minSec}s a ${maxSec}s</small>
          </div>
          <span class="locc-chip ${isLowRisk ? '' : 'warn'}">${isLowRisk ? '🛡️ Baixo Risco' : '⚠️ Risco Médio'}</span>
        </div>
        <p style="margin:4px 0;font-size:13px;line-height:1.4"><strong>Sugestão Atual:</strong> ${esc(engagementSuggestion || (state.settings.engagementReminderEnabled ? `Próximo ciclo em aprox. ${fmtTime(reminder || 0)}.` : 'Ative o recurso abaixo ou nas configurações.'))}</p>
        <div class="locc-row-wrap">
          <button class="locc-btn" data-action="engagement-generate">Gerar novo agora</button>
          <button class="locc-btn primary" data-action="engagement-publish" ${engagementSuggestion ? '' : 'disabled'}>Publicar no TikTok agora</button>
          <button class="locc-btn ghost" data-action="engagement-copy" ${engagementSuggestion ? '' : 'disabled'}>Copiar texto</button>
        </div>
        <div class="locc-form-grid" style="margin-top:4px">
          <label><span class="locc-label">Modo de Envio</span>
            <select class="locc-select" data-action-change="toggle-engagement-mode">
              <option value="off" ${!state.settings.engagementReminderEnabled ? 'selected' : ''}>Desativado</option>
              <option value="manual" ${state.settings.engagementReminderEnabled && !isAuto ? 'selected' : ''}>Manual (Sugerir e Revisar)</option>
              <option value="auto" ${state.settings.engagementReminderEnabled && isAuto ? 'selected' : ''}>100% Automático (Publicar Direto)</option>
            </select>
          </label>
          <label><span class="locc-label">Preset de Intervalo (Baixo Risco)</span>
            <select class="locc-select" data-action-change="apply-engagement-preset">
              <option value="">Selecione um preset…</option>
              ${ENGAGEMENT_PRESETS.map((p) => `<option value="${p.id}" ${minSec === p.min && maxSec === p.max ? 'selected' : ''}>${p.label}</option>`).join('')}
            </select>
          </label>
        </div>
        <small class="locc-muted">💡 <strong>Dica de Segurança:</strong> Intervalos dinâmicos aleatórios (ex.: 45s a 90s ou 60s a 120s) mantêm sua live em <strong>Baixo Risco</strong> contra filtros de spam do TikTok.</small>
      </div>
      <div class="locc-list">${comments.length ? comments.map((item) => `<article class="locc-item ${item.category !== 'geral' ? 'priority' : ''}"><div class="locc-row locc-between"><div><span class="locc-chip ${item.category === 'risco' ? 'danger' : item.category === 'compra' ? 'warn' : ''}">${labels[item.category]}</span>${item.repeats > 1 ? ` <span class="locc-chip">repetido ${item.repeats}×</span>` : ''}</div><small class="locc-muted">${new Date(item.at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</small></div><strong>${esc(item.author || 'Espectador')}</strong><p>${esc(item.text)}</p><div class="locc-row-wrap"><button class="locc-btn primary" data-action="ai-comment" data-id="${item.id}">IA responder</button><button class="locc-btn" data-action="copy-reply" data-id="${item.id}">Resposta padrão</button><button class="locc-btn" data-action="comment-done" data-id="${item.id}">Resolvido</button><button class="locc-btn ghost" data-action="comment-hide" data-id="${item.id}">Ignorar</button></div></article>`).join('') : '<div class="locc-empty">Os comentários encontrados na página aparecerão aqui.</div>'}</div>`;
  }

  function renderAi() {
    const providerReady = aiConfig.provider === 'gemini' ? aiConfig.hasGemini : aiConfig.hasGroq;
    const product = currentProduct();
    const latestComment = state.comments.find((item) => item.status === 'new');
    return `<div class="locc-card locc-stack"><div class="locc-row locc-between"><div><span class="locc-label">Copiloto de IA</span><strong>${aiConfig.provider === 'gemini' ? 'Google Gemini' : 'Groq'} · ${providerReady ? 'configurado' : 'sem chave'}</strong></div><span class="locc-chip ${providerReady ? '' : 'warn'}">${aiBusy ? 'pensando…' : providerReady ? 'pronto' : 'configure abaixo'}</span></div><div class="locc-warning">A IA cria rascunhos. Confira preço, estoque, frete e promessas antes de usar.</div><div class="locc-row-wrap"><button class="locc-btn primary" data-action="ai-task" data-task="reply" ${!latestComment || aiBusy ? 'disabled' : ''}>Responder comentário</button><button class="locc-btn" data-action="ai-task" data-task="pitch" ${!product || aiBusy ? 'disabled' : ''}>Melhorar argumento</button><button class="locc-btn" data-action="ai-task" data-task="script" ${!product || aiBusy ? 'disabled' : ''}>Criar roteiro</button><button class="locc-btn" data-action="ai-task" data-task="compliance" ${aiBusy ? 'disabled' : ''}>Revisar riscos</button><button class="locc-btn" data-action="ai-task" data-task="plan" ${aiBusy ? 'disabled' : ''}>Plano da live</button></div></div>
      <form class="locc-card locc-stack" data-form="ai-prompt"><span class="locc-label">Pedido livre</span><textarea class="locc-textarea" name="prompt" placeholder="Ex.: crie três formas de apresentar o produto sem inventar informações"></textarea><button class="locc-btn primary" ${aiBusy ? 'disabled' : ''}>Perguntar à IA</button></form>
      <div class="locc-card locc-stack"><div class="locc-row locc-between"><span class="locc-label">Resposta</span>${aiResult ? '<button class="locc-btn ghost" data-action="copy-ai">Copiar</button>' : ''}</div><div class="locc-ai-output">${aiBusy ? 'Gerando rascunho…' : aiResult ? esc(aiResult).replaceAll('\n','<br>') : '<span class="locc-muted">A resposta aparecerá aqui.</span>'}</div>${aiResult && product ? '<div class="locc-row-wrap"><button class="locc-btn" data-action="apply-ai-pitch">Usar como argumento</button><button class="locc-btn" data-action="apply-ai-script">Usar como roteiro</button></div>' : ''}</div>
      <form class="locc-card locc-stack" data-form="ai-config"><span class="locc-label">Provedor e chaves</span><select class="locc-select" name="provider"><option value="groq" ${aiConfig.provider === 'groq' ? 'selected' : ''}>Groq — resposta mais rápida</option><option value="gemini" ${aiConfig.provider === 'gemini' ? 'selected' : ''}>Google Gemini</option></select><div class="locc-form-grid"><label><span class="locc-label">Modelo Groq</span><input class="locc-input" name="groqModel" list="liveos-groq-models" value="${esc(aiConfig.groqModel)}"><datalist id="liveos-groq-models"><option value="openai/gpt-oss-20b"><option value="openai/gpt-oss-120b"><option value="llama-3.3-70b-versatile"></datalist></label><label><span class="locc-label">Modelo Gemini</span><input class="locc-input" name="geminiModel" list="liveos-gemini-models" value="${esc(aiConfig.geminiModel)}"><datalist id="liveos-gemini-models"><option value="gemini-3.6-flash"><option value="gemini-3.7-flash"><option value="gemini-3.5-flash-lite"></datalist></label></div><label><span class="locc-label">Nova chave Groq ${aiConfig.hasGroq ? '· salva' : ''}</span><input class="locc-input" type="password" name="groqKey" autocomplete="off" placeholder="Cole uma chave nova; nunca aparece novamente"></label><label><span class="locc-label">Nova chave Gemini ${aiConfig.hasGemini ? '· salva' : ''}</span><input class="locc-input" type="password" name="geminiKey" autocomplete="off" placeholder="Cole uma chave nova; nunca aparece novamente"></label><div class="locc-row-wrap"><button class="locc-btn primary">Salvar IA</button><button class="locc-btn" type="button" data-action="test-ai" ${providerReady || aiConfig.hasGemini || aiConfig.hasGroq ? '' : 'disabled'}>Testar conexão</button><button class="locc-btn" type="button" data-action="reset-ai-models">Restaurar modelos atuais</button><button class="locc-btn danger" type="button" data-action="clear-ai-keys">Apagar chaves</button></div><small class="locc-muted">Padrões atuais: Groq openai/gpt-oss-20b e Gemini gemini-3.6-flash. As chaves ficam no armazenamento local da extensão.</small></form>`;
  }

  function renderProducts() {
    return `<form class="locc-card locc-stack" data-form="product"><div class="locc-row locc-between"><span class="locc-label">Novo cartão de produto</span><button class="locc-btn ghost" type="button" data-action="import-products">Importar produtos da página</button></div><div class="locc-form-grid"><input class="locc-input" name="name" required placeholder="Nome do produto"><input class="locc-input" name="price" placeholder="Preço/oferta"><input class="locc-input" type="number" min="0" max="100" step="0.01" name="commissionRate" placeholder="Comissão %"></div><textarea class="locc-textarea" name="pitch" placeholder="Principais benefícios e argumento de venda"></textarea><textarea class="locc-textarea" name="objections" placeholder="Objeções: frete, tamanho, garantia, prazo…"></textarea><textarea class="locc-textarea" name="script" placeholder="Mini roteiro: mostrar → demonstrar → oferta → CTA"></textarea><button class="locc-btn primary" type="submit">Adicionar produto</button></form>
      <div class="locc-list">${state.products.length ? state.products.map((item, index) => `<article class="locc-item ${item.id === state.currentProductId ? 'current' : ''}"><div class="locc-row locc-between"><div><span class="locc-chip">#${index + 1}</span> <strong>${esc(item.name)}</strong></div><span>${esc(item.price || '')}</span></div>${item.stock ? `<small class="locc-muted">Estoque exibido: ${esc(item.stock)}</small>` : ''}${Number(item.commissionRate) > 0 ? `<small class="locc-muted">Comissão configurada: ${Number(item.commissionRate).toLocaleString('pt-BR')}%</small>` : ''}<p>${esc(item.pitch || 'Sem argumento cadastrado.')}</p><div class="locc-row-wrap"><button class="locc-btn primary" data-action="set-product" data-id="${item.id}">Marcar como fixado</button><button class="locc-btn" data-action="ai-product" data-task="pitch" data-id="${item.id}">IA melhorar</button><button class="locc-btn" data-action="edit-product" data-id="${item.id}">Editar</button><button class="locc-btn ghost" data-action="move-product" data-dir="-1" data-id="${item.id}">↑</button><button class="locc-btn ghost" data-action="move-product" data-dir="1" data-id="${item.id}">↓</button><button class="locc-btn danger" data-action="delete-product" data-id="${item.id}">Excluir</button></div></article>`).join('') : '<div class="locc-empty">Abra a lista de produtos do TikTok e clique em “Importar produtos da página”.</div>'}</div>`;
  }

  function renderRundown() {
    const done = state.rundown.filter((item) => item.done).length;
    const percent = state.rundown.length ? Math.round(done / state.rundown.length * 100) : 0;
    return `<div class="locc-card"><div class="locc-row locc-between"><div><span class="locc-label">Andamento da live</span><strong>${percent}% concluído</strong></div><button class="locc-btn" data-action="reset-rundown">Reiniciar</button></div><div class="locc-progress"><i style="width:${percent}%"></i></div></div>
      <form class="locc-card locc-form-grid" data-form="rundown"><input class="locc-input" name="title" required placeholder="Novo bloco"><input class="locc-input" type="number" name="minutes" min="1" value="5"><button class="locc-btn primary locc-span2">Adicionar bloco</button></form>
      <div class="locc-list">${state.rundown.map((item, index) => `<article class="locc-item ${item.done ? 'done' : ''}"><div class="locc-row locc-between"><div><span class="locc-chip">${index + 1}</span> <strong>${esc(item.title)}</strong></div><span>${Number(item.minutes) || 0} min</span></div><div class="locc-row-wrap"><button class="locc-btn primary" data-action="toggle-rundown" data-id="${item.id}">${item.done ? 'Reabrir' : 'Concluir bloco'}</button><button class="locc-btn danger" data-action="delete-rundown" data-id="${item.id}">Excluir</button></div></article>`).join('')}</div>`;
  }

  function productMetrics() {
    const sessionStart = Number(state.session.startedAt) || 0;
    const sessionSales = state.sales.filter((sale) => !sessionStart || sale.at >= sessionStart);
    return state.products.map((product) => {
      const pins = state.events.filter((item) => (!sessionStart || item.at >= sessionStart) && ['pin', 'pin_refresh'].includes(item.type) && item.productId === product.id);
      const seconds = state.events.filter((item) => (!sessionStart || item.at >= sessionStart) && item.type === 'pin_duration' && item.productId === product.id).reduce((sum, item) => sum + Number(item.seconds || 0), 0) + (state.currentProductId === product.id && state.pinStartedAt ? Math.max(0, (Date.now() - state.pinStartedAt) / 1000) : 0);
      const sales = sessionSales.filter((item) => item.productId === product.id);
      const quantity = totalQuantity(sales);
      const paidQuantity = sales.filter((item) => item.status === 'paid').reduce((sum, item) => sum + saleQuantity(item), 0);
      const gmv = sales.reduce((sum, item) => sum + Number(item.value || 0), 0);
      const commission = sales.reduce((sum, item) => sum + saleCommission(item), 0);
      const fastestSaleSec = sales.map((item) => Number(item.timeToSaleSec)).filter(Number.isFinite).sort((a, b) => a - b)[0];
      return { product, pins: pins.length, seconds, sales, quantity, paidQuantity, gmv, commission, fastestSaleSec, gmvPerMinute: seconds > 0 ? gmv / (seconds / 60) : 0, ticket: quantity ? gmv / quantity : 0 };
    }).sort((a, b) => b.gmvPerMinute - a.gmvPerMinute || b.gmv - a.gmv || b.quantity - a.quantity);
  }

  function renderMetrics() {
    const rows = productMetrics();
    const sessionComments = state.comments.filter((item) => !state.session.startedAt || item.at >= state.session.startedAt).length;
    const sales = currentSessionSales();
    const orders = totalQuantity(sales);
    const paidOrders = sales.filter((sale) => sale.status === 'paid').reduce((sum, sale) => sum + saleQuantity(sale), 0);
    const totalGmv = sales.reduce((sum, item) => sum + Number(item.value || 0), 0);
    const totalCommission = sales.reduce((sum, item) => sum + saleCommission(item), 0);
    const ticket = orders ? totalGmv / orders : 0;
    const best = rows.find((row) => row.quantity > 0);
    const anomalies = state.analytics.anomalies.filter((item) => !item.resolved);
    const history = [...state.analytics.sessionReports].reverse().slice(0, 10);
    return `<div class="locc-grid"><div class="locc-card"><span class="locc-label">GMV registrado</span><div class="locc-big">${formatMoney(totalGmv)}</div><small class="locc-muted">Ticket ${formatMoney(ticket)}</small></div><div class="locc-card"><span class="locc-label">Comissão estimada</span><div class="locc-big">${formatMoney(totalCommission)}</div><small class="locc-muted">${paidOrders || orders} venda(s)${paidOrders ? ' paga(s)' : ''}</small></div><div class="locc-card"><span class="locc-label">Pico de espectadores</span><div class="locc-big">${Number(state.analytics.peakViewers) || 0}</div><small class="locc-muted">${sessionComments} comentário(s)</small></div><div class="locc-card"><span class="locc-label">Melhor produto</span><div class="locc-big">${esc(best?.product.name || '—')}</div><small class="locc-muted">${best ? `${formatMoney(best.gmvPerMinute)}/min fixado${Number.isFinite(best.fastestSaleSec) ? ` · vendeu em ${fmtTime(best.fastestSaleSec)}` : ''}` : 'aguardando vendas'}</small></div></div>
      ${anomalies.length ? `<div class="locc-dangerbox"><strong>${anomalies.length} alteração bloqueada por segurança.</strong><div class="locc-list">${anomalies.slice(-5).reverse().map((item) => `<div class="locc-item"><span>Pedidos mudaram de ${item.previousOrders} para ${item.orders} (${item.delta > 0 ? '+' : ''}${item.delta}).</span><div class="locc-row-wrap"><button class="locc-btn" data-action="accept-metric-baseline" data-id="${item.id}">Usar somente como nova base</button><button class="locc-btn ghost" data-action="dismiss-anomaly" data-id="${item.id}">Ignorar</button></div></div>`).join('')}</div></div>` : ''}
      <div class="locc-card"><div class="locc-row locc-between"><span class="locc-label">Por produto</span><div class="locc-row"><button class="locc-btn" data-action="telegram-summary">Enviar resumo</button><button class="locc-btn" data-action="export-csv">Exportar CSV</button><button class="locc-btn" data-action="export-report">Relatório</button></div></div><div class="locc-list">${rows.some((row) => row.quantity) ? rows.filter((row) => row.quantity || row.seconds).map((row, index) => `<div class="locc-item"><div class="locc-row locc-between"><strong>${index + 1}. ${esc(row.product.name)}</strong><strong>${formatMoney(row.gmv)}</strong></div><small class="locc-muted">${row.pins} marcação(ões) · ${fmtTime(row.seconds)} no ar · ${row.quantity} venda(s) · comissão ${formatMoney(row.commission)} · ${formatMoney(row.gmvPerMinute)}/min${Number.isFinite(row.fastestSaleSec) ? ` · mais rápida ${fmtTime(row.fastestSaleSec)}` : ''}</small></div>`).join('') : '<div class="locc-empty">As métricas surgem após cadastrar produtos e registrar a sessão.</div>'}</div></div>
      <div class="locc-card"><span class="locc-label">Vendas recentes</span><div class="locc-list">${sales.length ? [...sales].reverse().slice(0, 20).map((sale) => `<div class="locc-item"><div class="locc-row locc-between"><strong>${esc(sale.productName || state.products.find((p) => p.id === sale.productId)?.name || 'Produto não atribuído')}</strong><strong>${formatMoney(sale.value)}</strong></div><small class="locc-muted">${saleQuantity(sale)} item(ns) · ${sale.status === 'paid' ? 'pago' : sale.status === 'pending' ? 'pendente' : sale.source === 'manual' ? 'manual' : 'detectado'}${Number.isFinite(Number(sale.timeToSaleSec)) ? ` · ${fmtTime(sale.timeToSaleSec)} até vender` : ''}</small><button class="locc-btn ghost" data-action="reattribute-sale" data-id="${sale.id}">Corrigir produto</button></div>`).join('') : '<div class="locc-empty">Nenhuma venda registrada nesta sessão.</div>'}</div></div>
      <div class="locc-card"><span class="locc-label">Comparativo das últimas lives</span><div class="locc-list">${history.length ? history.map((report) => `<div class="locc-item"><div class="locc-row locc-between"><strong>${new Date(report.startedAt || report.endedAt).toLocaleString('pt-BR')}</strong><strong>${formatMoney(report.gmv)}</strong></div><small class="locc-muted">${report.orders} venda(s) · comissão ${formatMoney(report.commission)} · ticket ${formatMoney(report.orders ? report.gmv / report.orders : 0)} · ${fmtTime(report.durationSec)}${report.bestProduct?.name ? ` · campeão: ${esc(report.bestProduct.name)}` : ''}</small></div>`).join('') : '<div class="locc-empty">O comparativo aparecerá após encerrar uma sessão.</div>'}</div></div>`;
  }

  function complianceFindings() {
    const text = state.products.flatMap((item) => [item.name, item.pitch, item.objections, item.script]).join(' ').toLocaleLowerCase('pt-BR');
    const terms = `${state.settings.riskTerms},${state.settings.blockedTerms}`.split(',').map((item) => item.trim()).filter(Boolean);
    return [...new Set(terms.filter((term) => text.includes(term.toLocaleLowerCase('pt-BR'))))];
  }

  function renderSafety() {
    const findings = complianceFindings();
    const checks = [
      ['disclosure', 'Ativei a divulgação de conteúdo comercial quando aplicável'],
      ['lighting', 'Iluminação e enquadramento estão bons'], ['audio', 'Microfone e áudio foram testados'],
      ['camera', 'Câmera virtual/Live Studio está funcionando'], ['productMatch', 'Produto mostrado corresponde ao produto fixado'],
      ['stock', 'Preço, estoque e variações foram conferidos'], ['moderator', 'Moderador ou plano de moderação definido'],
      ['links', 'Não há CTA de compra fora do TikTok Shop']
    ];
    return `<div class="locc-card"><span class="locc-label">Verificação de conformidade</span>${findings.length ? `<div class="locc-dangerbox">Revise estes termos nos cartões: <strong>${findings.map(esc).join(', ')}</strong>. O alerta não substitui a revisão das políticas.</div>` : '<div class="locc-warning">Nenhum termo configurado foi encontrado nos cartões. Ainda faça uma revisão humana.</div>'}<button class="locc-btn" data-action="scan-compliance">Verificar novamente</button></div>
      <div class="locc-card locc-stack"><span class="locc-label">Checklist antes da live</span>${checks.map(([key, label]) => `<label class="locc-check"><input type="checkbox" data-check="${key}" ${state.checklist[key] ? 'checked' : ''}><span>${label}</span></label>`).join('')}</div>
      <div class="locc-card"><span class="locc-label">Regra operacional</span><p>Esta central apenas organiza e copia respostas. Revise o texto e envie manualmente. Pins, bloqueios e encerramento continuam sob confirmação humana.</p></div>`;
  }

  function renderSettings() {
    return `<form class="locc-card locc-stack" data-form="settings">
      <label><span class="locc-label">Avisar renovação do pin (segundos)</span><input class="locc-input" type="number" min="15" max="300" name="pinReminderSec" value="${Number(state.settings.pinReminderSec) || 30}"></label>
      <label class="locc-check"><input type="checkbox" name="commentScan" ${state.settings.commentScan ? 'checked' : ''}><span>Monitorar comentários visíveis na página</span></label>
      <div class="locc-warning"><strong>Comentários Automáticos de Engajamento</strong><br>Sorteia comentários cadastrados e envia no chat da live em intervalos dinâmicos aleatórios para manter baixo risco.</div>
      <label class="locc-check"><input type="checkbox" name="engagementReminderEnabled" ${state.settings.engagementReminderEnabled ? 'checked' : ''}><span>Ativar sistema de comentários de engajamento</span></label>
      <label class="locc-check"><input type="checkbox" name="engagementAutoPublish" ${state.settings.engagementAutoPublish ? 'checked' : ''}><span><strong>Publicar automaticamente no TikTok</strong> (sem precisar clicar para copiar)</span></label>
      <label><span class="locc-label">Presets de Intervalo Sugeridos (Baixo Risco)</span>
        <select class="locc-select" data-action-change="apply-preset-settings">
          <option value="">Personalizado ou selecione um preset…</option>
          ${ENGAGEMENT_PRESETS.map((p) => `<option value="${p.id}" ${Number(state.settings.engagementMinSec) === p.min && Number(state.settings.engagementMaxSec) === p.max ? 'selected' : ''}>${p.label}</option>`).join('')}
        </select>
      </label>
      <div class="locc-row"><label><span class="locc-label">Intervalo mínimo (segundos)</span><input class="locc-input" type="number" min="15" max="3600" id="cfgEngagementMinSec" name="engagementMinSec" value="${Number(state.settings.engagementMinSec) || 45}"></label><label><span class="locc-label">Intervalo máximo (segundos)</span><input class="locc-input" type="number" min="15" max="3600" id="cfgEngagementMaxSec" name="engagementMaxSec" value="${Number(state.settings.engagementMaxSec) || 90}"></label></div>
      <label><span class="locc-label">Comentários, um por linha</span><textarea class="locc-textarea" name="engagementTemplates">${esc(state.settings.engagementTemplates || '')}</textarea></label>
      <label class="locc-check"><input type="checkbox" name="hotkeys" ${state.settings.hotkeys ? 'checked' : ''}><span>Ativar atalhos de teclado</span></label>
      <label><span class="locc-label">Endereço do app local</span><input class="locc-input" name="companionUrl" value="${esc(state.settings.companionUrl)}"></label>
      <div class="locc-warning"><strong>Saída de vídeo da clonagem</strong><br>Perfil recomendado para PCs de entrada: 720×1280 a 30 FPS. Use OBS Direto para deixar a GPU processar o vídeo.</div>
      <label><span class="locc-label">Enquadramento</span><select class="locc-input" name="videoFrameMode"><option value="fit" ${state.settings.videoFrameMode !== 'crop' ? 'selected' : ''}>Ajustar sem corte (recomendado)</option><option value="crop" ${state.settings.videoFrameMode === 'crop' ? 'selected' : ''}>Preencher tela (pode cortar)</option></select></label>
      <label><span class="locc-label">Captura da Live 1</span><select class="locc-input" name="captureProfile"><option value="performance" ${state.settings.captureProfile !== 'low' ? 'selected' : ''}>720×1280 — desempenho máximo</option><option value="low" ${state.settings.captureProfile === 'low' ? 'selected' : ''}>540×960 — PC fraco</option></select></label>
      <label><span class="locc-label">FPS da câmera virtual</span><select class="locc-input" name="outputFps" disabled><option value="30" selected>30 FPS — fixo para desempenho</option></select></label>
      <label><span class="locc-label">Zoom manual (100% = imagem original)</span><input class="locc-input" type="number" min="50" max="150" step="1" name="safeScale" value="${Math.round((Number(state.settings.safeScale) || 1) * 100)}"></label>
      <div class="locc-warning"><strong>Métricas e Telegram</strong><br>A leitura é confirmada duas vezes e saltos anormais são bloqueados antes de gerar uma venda.</div>
      <label><span class="locc-label">Resumo no Telegram (minutos; 0 desativa)</span><input class="locc-input" type="number" min="0" max="240" step="5" name="saleSummaryMinutes" value="${Number(state.settings.saleSummaryMinutes) || 0}"></label>
      <label><span class="locc-label">Máximo de novos pedidos por atualização</span><input class="locc-input" type="number" min="1" max="500" name="maxOrderJump" value="${Number(state.settings.maxOrderJump) || 10}"></label>
      <label><span class="locc-label">Confirmações consecutivas da métrica</span><input class="locc-input" type="number" min="2" max="5" name="metricConfirmReads" value="${Math.max(2, Number(state.settings.metricConfirmReads) || 2)}"></label>
      <label><span class="locc-label">Comissão padrão quando o TikTok não mostrar (%)</span><input class="locc-input" type="number" min="0" max="100" step="0.01" name="defaultCommissionRate" value="${Number(state.settings.defaultCommissionRate) || 0}"></label>
      <label class="locc-check"><input type="checkbox" name="telegramSummaryEnabled" ${state.settings.telegramSummaryEnabled ? 'checked' : ''}><span>Enviar resumo periódico e resumo final no Telegram</span></label>
      <label><span class="locc-label">Termos de risco, separados por vírgula</span><textarea class="locc-textarea" name="riskTerms">${esc(state.settings.riskTerms)}</textarea></label>
      <label><span class="locc-label">Outros termos bloqueados</span><textarea class="locc-textarea" name="blockedTerms">${esc(state.settings.blockedTerms)}</textarea></label>
      <button class="locc-btn primary">Salvar configurações</button></form>
      <div class="locc-card"><span class="locc-label">Atalhos</span><div class="locc-stack"><div><span class="locc-kbd">Ctrl Shift O</span> abrir/fechar</div><div><span class="locc-kbd">Alt P</span> renovar marcador do pin</div><div><span class="locc-kbd">Alt N</span> próximo produto</div><div><span class="locc-kbd">Alt R</span> abrir roteiro</div><div><span class="locc-kbd">Alt M</span> modo moderador</div></div></div>
      <div class="locc-card"><span class="locc-label">Backup</span><div class="locc-row-wrap"><button class="locc-btn" data-action="export-backup">Exportar JSON</button><label class="locc-btn">Importar JSON<input type="file" accept="application/json" data-import hidden></label><button class="locc-btn danger" data-action="reset-all">Restaurar central</button></div></div>`;
  }

  function renderTelegram() {
    return `<form class="locc-card locc-stack" data-form="telegram-config"><div class="locc-row locc-between"><div><span class="locc-label">Notificações da live</span><strong>Telegram · ${telegramConfig.ready ? 'configurado' : 'configure abaixo'}</strong></div><span class="locc-chip ${telegramConfig.ready ? '' : 'warn'}">${telegramConfig.ready ? 'pronto' : 'pendente'}</span></div><label class="locc-check"><input type="checkbox" name="enabled" ${telegramConfig.enabled ? 'checked' : ''}><span>Ativar notificações no Telegram</span></label><label class="locc-check"><input type="checkbox" name="notifySafety" ${telegramConfig.notifySafety ? 'checked' : ''}><span>Avisar violação, encerramento confirmado ou falha ao fechar a live</span></label><label class="locc-check"><input type="checkbox" name="notifyManual" ${telegramConfig.notifyManual ? 'checked' : ''}><span>Avisar vendas registradas em + Venda</span></label><label class="locc-check"><input type="checkbox" name="notifyDetected" ${telegramConfig.notifyDetected ? 'checked' : ''}><span>Avisar aumento de pedidos detectado no painel</span></label><label><span class="locc-label">Token do bot ${telegramConfig.hasToken ? '· salvo' : ''}</span><input class="locc-input" type="password" name="botToken" autocomplete="off" placeholder="Cole o token recebido do @BotFather"></label><label><span class="locc-label">Chat ID</span><input class="locc-input" name="chatId" value="${esc(telegramConfig.chatId)}" placeholder="Ex.: 123456789 ou -100..."></label><div class="locc-row-wrap"><button class="locc-btn primary">Salvar Telegram</button><button class="locc-btn" type="button" data-action="telegram-find-chat">Localizar chat ID</button><button class="locc-btn" type="button" data-action="telegram-test" ${telegramConfig.ready ? '' : 'disabled'}>Enviar teste</button><button class="locc-btn danger" type="button" data-action="telegram-clear">Apagar dados</button></div><small class="locc-muted">Envie primeiro qualquer mensagem para o seu bot. Depois use “Localizar chat ID”. O token fica no armazenamento local da extensão.</small></form><div class="locc-card"><span class="locc-label">Como funciona</span><p>O Telegram avisa quando uma violação é detectada, quando o fechamento começa, quando a live realmente sai do ar e quando é necessária ação manual. Também pode avisar vendas sem duplicação.</p></div>`;
  }

  const saleQuantity = (sale) => Math.max(1, Number(sale?.quantity || sale?.orderDelta) || 1);
  const saleCommission = (sale) => Math.max(0, Number(sale?.commission) || 0);
  const currentSessionSales = () => state.sales.filter((sale) => !state.session.startedAt || sale.at >= state.session.startedAt);
  const totalQuantity = (sales) => sales.reduce((sum, sale) => sum + saleQuantity(sale), 0);

  function sessionSnapshot(endedAt = Date.now()) {
    const sales = currentSessionSales();
    const rows = productMetrics();
    const best = rows.find((row) => row.quantity > 0) || null;
    const viewerSamples = state.analytics.viewerSamples.map((item) => Number(item.viewers)).filter(Number.isFinite);
    const averageViewers = viewerSamples.length ? Math.round(viewerSamples.reduce((sum, value) => sum + value, 0) / viewerSamples.length) : 0;
    const salesGmv = sales.reduce((sum, sale) => sum + Number(sale.value || 0), 0);
    const panelGmv = hostState.metricsTrusted === true && Number.isFinite(Number(hostState.gmvCurrent)) && Number(hostState.gmvCurrent) > 0 ? Number(hostState.gmvCurrent) : null;
    const sessionGmv = panelGmv ?? salesGmv;
    const salesComm = sales.reduce((sum, sale) => sum + saleCommission(sale), 0);
    const panelComm = Number.isFinite(Number(hostState.gmvCommission)) && Number(hostState.gmvCommission) > 0 ? Number(hostState.gmvCommission) : null;
    const sessionComm = panelComm ?? salesComm;
    return {
      id: state.session.id || uid('session'),
      startedAt: state.session.startedAt,
      endedAt,
      durationSec: state.session.startedAt ? Math.max(0, Math.round((endedAt - state.session.startedAt) / 1000)) : 0,
      orders: totalQuantity(sales),
      paidOrders: sales.filter((sale) => sale.status === 'paid').reduce((sum, sale) => sum + saleQuantity(sale), 0),
      gmv: sessionGmv,
      commission: sessionComm,
      peakViewers: Number(state.analytics.peakViewers) || 0,
      averageViewers,
      gmvPer100Viewers: averageViewers ? sessionGmv / averageViewers * 100 : 0,
      productsWithoutSales: rows.filter((row) => row.seconds > 0 && row.quantity === 0).map((row) => row.product.name),
      bestProduct: best ? { id: best.product.id, name: best.product.name, gmv: best.gmv, quantity: best.quantity, gmvPerMinute: best.gmvPerMinute, fastestSaleSec: best.fastestSaleSec } : null
    };
  }

  function telegramSummaryText(snapshot, final = false) {
    const ticket = snapshot.orders ? snapshot.gmv / snapshot.orders : 0;
    const lines = [final ? '🏁 RESUMO FINAL DA LIVE' : '📊 RESUMO DA LIVE'];
    lines.push(`Vendas registradas: ${snapshot.orders}`);
    if (snapshot.paidOrders) lines.push(`Vendas pagas: ${snapshot.paidOrders}`);
    lines.push(`GMV: ${formatMoney(snapshot.gmv)}`);
    if (snapshot.commission > 0) lines.push(`Comissão estimada: ${formatMoney(snapshot.commission)}`);
    lines.push(`Ticket médio: ${formatMoney(ticket)}`);
    if (snapshot.peakViewers) lines.push(`Pico de espectadores: ${snapshot.peakViewers}`);
    if (snapshot.averageViewers) lines.push(`Média de espectadores: ${snapshot.averageViewers}`);
    if (snapshot.gmvPer100Viewers > 0) lines.push(`GMV por 100 espectadores: ${formatMoney(snapshot.gmvPer100Viewers)}`);
    if (snapshot.bestProduct) {
      lines.push('', '🏆 Melhor produto:', snapshot.bestProduct.name);
      lines.push(`${snapshot.bestProduct.quantity} venda(s) · ${formatMoney(snapshot.bestProduct.gmv)}`);
      if (snapshot.bestProduct.gmvPerMinute > 0) lines.push(`Eficiência: ${formatMoney(snapshot.bestProduct.gmvPerMinute)}/min fixado`);
      if (Number.isFinite(snapshot.bestProduct.fastestSaleSec)) lines.push(`Venda mais rápida: ${fmtTime(snapshot.bestProduct.fastestSaleSec)}`);
    }
    if (snapshot.productsWithoutSales?.length) lines.push('', `Fixados sem venda: ${snapshot.productsWithoutSales.slice(0, 8).join(', ')}`);
    lines.push(`Duração: ${fmtTime(snapshot.durationSec)}`, `Horário: ${new Date().toLocaleString('pt-BR')}`);
    return lines.join('\n');
  }

  async function sendTelegramSummary(final = false) {
    if (!state.settings.telegramSummaryEnabled || !telegramConfig.ready) return { ok: true, skipped: true };
    const snapshot = sessionSnapshot();
    if (!snapshot.orders) return { ok: true, skipped: true };
    const bucket = final ? 'final' : Math.floor(Date.now() / Math.max(300000, Number(state.settings.saleSummaryMinutes || 60) * 60000));
    const eventId = `summary:${snapshot.id}:${bucket}`;
    const response = await proRpc({ type: 'LIVEOS_TG_SALE', source: 'detected', eventId, text: telegramSummaryText(snapshot, final) });
    if (response?.ok && !response.skipped && !response.duplicate) {
      state.analytics.lastSummaryAt = Date.now();
      save();
    }
    return response;
  }

  function toggleSession() {
    if (state.session.active) {
      if (!confirm('Encerrar esta sessão e manter o relatório salvo?')) return;
      closePinDuration();
      const snapshot = sessionSnapshot();
      state.analytics.sessionReports.push(snapshot);
      state.analytics.sessionReports = state.analytics.sessionReports.slice(-MAX_SESSION_REPORTS);
      void sendTelegramSummary(true);
      log('session_end');
      state.session.active = false;
      state.pinStartedAt = null;
    } else {
      state.session = { active: true, startedAt: Date.now(), id: uid('session') };
      state.analytics.peakViewers = 0;
      state.analytics.viewerSamples = [];
      state.analytics.anomalies = [];
      state.analytics.lastSummaryAt = Date.now();
      lastHostOrders = null;
      lastHostGmv = null;
      lastHostCommission = null;
      metricCandidateKey = '';
      metricCandidateHits = 0;
      state.rundown = state.rundown.map((item) => ({ ...item, done: false }));
      log('session_start');
    }
    save(true); renderAll();
  }

  function closePinDuration() {
    if (!state.currentProductId || !state.pinStartedAt) return;
    state.events.push({ id: uid('ev'), type: 'pin_duration', at: Date.now(), productId: state.currentProductId, seconds: Math.max(0, Math.round((Date.now() - state.pinStartedAt) / 1000)) });
  }

  function setProduct(id, refreshOnly = false) {
    const product = state.products.find((item) => item.id === id);
    if (!product) return;
    closePinDuration();
    state.currentProductId = id;
    state.pinStartedAt = Date.now();
    log(refreshOnly ? 'pin_refresh' : 'pin', { productId: id });
    save(true); renderAll(); toast(refreshOnly ? 'Cronômetro do pin renovado.' : `${product.name} marcado como fixado. Confirme o pin no TikTok.`);
  }

  function nextProduct() {
    if (!state.products.length) return switchTab('products');
    const index = state.products.findIndex((item) => item.id === state.currentProductId);
    setProduct(state.products[(index + 1 + state.products.length) % state.products.length].id);
  }

  function telegramSaleText({ product, value, commission, source, status, firstProductSale, orderDelta = 1, totalOrders, pendingOrders, cancelledOrders, totalGmv, totalCommission, timeToSaleSec }) {
    const lines = ['🛍️ NOVA VENDA NA LIVE!', `Origem: ${source === 'detected' ? 'detectada pelo painel' : 'registro manual'}`];
    if (product?.name) lines.push(`Produto: ${product.name}`);
    if (firstProductSale && product?.name) lines.push('Destaque: primeira venda deste produto na sessão.');
    if (Number(value) > 0) lines.push(`Valor: ${formatMoney(value)}`);
    if (Number(commission) > 0) lines.push(`Comissão estimada: ${formatMoney(commission)}`);
    if (status === 'paid') lines.push('Status: pago');
    else if (status === 'pending') lines.push('Status: pendente');
    if (Number.isFinite(Number(timeToSaleSec))) lines.push(`Tempo até a venda: ${fmtTime(timeToSaleSec)}`);
    if (orderDelta > 1) lines.push(`Novos pedidos: ${orderDelta}`);
    if (Number.isFinite(Number(totalOrders))) lines.push(`Pedidos no painel: ${Number(totalOrders)}`);
    if (Number.isFinite(Number(pendingOrders))) lines.push(`Pendentes/não pagos: ${Number(pendingOrders)}`);
    if (Number.isFinite(Number(cancelledOrders))) lines.push(`Cancelados: ${Number(cancelledOrders)}`);
    if (Number.isFinite(Number(totalGmv))) lines.push(`GMV no painel: ${formatMoney(totalGmv)}`);
    if (Number.isFinite(Number(totalCommission))) lines.push(`Comissão total estimada: ${formatMoney(totalCommission)}`);
    lines.push(`Horário: ${new Date().toLocaleString('pt-BR')}`);
    return lines.join('\n');
  }

  async function notifyTelegramSale(details) {
    try {
      return await proRpc({ type: 'LIVEOS_TG_SALE', ...details, text: telegramSaleText(details) });
    } catch (error) {
      return { ok: false, error: String(error?.message || error) };
    }
  }

  async function addSale() {
    const product = currentProduct();
    if (!product) return toast('Marque um produto primeiro.');
    const suggested = String(product.price || '').replace(/[^0-9,.-]/g, '').replace(',', '.');
    const input = prompt(`Valor da venda de ${product.name}:`, suggested || '0');
    if (input == null) return;
    const value = Number(String(input).replace(',', '.')) || 0;
    const commissionRate = Number(product.commissionRate) > 0 ? Number(product.commissionRate) : Math.max(0, Number(state.settings.defaultCommissionRate) || 0);
    const commission = value * commissionRate / 100;
    const firstProductSale = !currentSessionSales().some((item) => item.productId === product.id);
    const sale = { id: uid('sale'), at: Date.now(), sessionId: state.session.id, productId: product.id, productName: product.name, value, commission, quantity: 1, source: 'manual', status: 'manual', firstProductSale, timeToSaleSec: state.pinStartedAt ? Math.max(0, Math.round((Date.now() - state.pinStartedAt) / 1000)) : null };
    state.sales.push(sale);
    state.sales = state.sales.slice(-MAX_SALES);
    log('sale', { productId: product.id, value }); save(true); renderAll(); toast('Venda registrada.');
    const response = await notifyTelegramSale({ eventId: sale.id, source: 'manual', product, value, commission, firstProductSale, timeToSaleSec: sale.timeToSaleSec });
    if (response?.ok && !response.skipped && !response.duplicate) toast('Venda registrada e enviada ao Telegram.');
    else if (!response?.ok && telegramConfig.enabled) toast(response?.error || 'Venda registrada, mas o Telegram falhou.');
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); toast('Texto copiado. Revise antes de enviar.'); }
    catch { toast('Não foi possível copiar automaticamente.'); }
  }

  function suggestedReply(comment) {
    const product = currentProduct();
    if (comment.category === 'risco') return 'Por segurança, confira as informações e finalize somente pelo produto fixado no TikTok Shop.';
    if (comment.category === 'compra') return product ? `${product.name}: ${product.price || 'confira o valor atualizado'} no produto fixado. ${product.objections || ''}`.trim() : 'Confira o produto fixado para ver o valor e as condições atualizadas.';
    if (comment.category === 'duvida') return product?.objections || 'Vou explicar isso agora na live. Confira também os detalhes do produto fixado.';
    return 'Obrigada por participar! Se tiver dúvida sobre o produto, pode perguntar aqui.';
  }

  function aiPromptFor(task, extra = '') {
    const product = currentProduct();
    const comment = state.comments.find((item) => item.id === extra) || state.comments.find((item) => item.status === 'new');
    const productData = product ? `Produto: ${product.name}\nPreço informado: ${product.price || '[não informado]'}\nEstoque exibido: ${product.stock || '[não informado]'}\nBenefícios cadastrados: ${product.pitch || '[não informado]'}\nObjeções: ${product.objections || '[não informado]'}\nRoteiro atual: ${product.script || '[não informado]'}` : 'Nenhum produto atual foi informado.';
    if (task === 'reply') return `Crie uma resposta de no máximo 180 caracteres para este comentário da live: "${comment?.text || ''}".\n${productData}`;
    if (task === 'pitch') return `Melhore o argumento de venda abaixo em até 5 frases curtas para falar ao vivo. Não acrescente fatos.\n${productData}`;
    if (task === 'script') return `Crie um roteiro de 60 a 90 segundos com: gancho, demonstração, benefícios, objeção, oferta e CTA para o produto fixado. Não invente dados.\n${productData}`;
    if (task === 'compliance') return `Revise os textos abaixo. Liste: 1) promessas ou termos arriscados; 2) informações que precisam ser confirmadas; 3) versão mais segura.\n${state.products.map((item) => `${item.name}: ${item.pitch} ${item.objections} ${item.script}`).join('\n').slice(0, 9000) || 'Nenhum cartão cadastrado.'}`;
    if (task === 'plan') return `Crie um plano prático para esta live, usando os produtos e os blocos cadastrados. Inclua abertura, ordem, transições, momentos de perguntas e encerramento.\nProdutos:\n${state.products.map((item, index) => `${index + 1}. ${item.name} — ${item.pitch}`).join('\n')}\nBlocos:\n${state.rundown.map((item) => `${item.title} (${item.minutes} min)`).join('\n')}`;
    return String(extra || '').trim();
  }

  async function loadAiConfig() {
    try {
      const response = await proRpc({ type: 'LIVEOS_AI_GET_CONFIG' });
      if (response?.ok && response.config) aiConfig = { ...aiConfig, ...response.config };
    } catch {}
  }

  async function loadTelegramConfig() {
    try {
      const response = await proRpc({ type: 'LIVEOS_TG_GET_CONFIG' });
      if (response?.ok && response.config) telegramConfig = { ...telegramConfig, ...response.config };
    } catch {}
  }

  async function runAi(task, extra = '') {
    if (aiBusy) return;
    const prompt = aiPromptFor(task, extra);
    if (!prompt) return toast('Escreva um pedido para a IA.');
    aiBusy = true; aiResult = ''; open('ai'); render('ai');
    try {
      const response = await proRpc({ type: 'LIVEOS_AI_GENERATE', provider: aiConfig.provider, prompt });
      if (!response?.ok) throw new Error(response?.error || 'A IA não respondeu.');
      aiResult = String(response.text || '').trim();
      state.aiHistory.push({ id: uid('ai'), at: Date.now(), task, provider: response.provider, text: aiResult });
      state.aiHistory = state.aiHistory.slice(-20); log('ai', { task, provider: response.provider }); save();
    } catch (error) { aiResult = `Erro: ${String(error?.message || error)}`; }
    finally { aiBusy = false; render('ai'); }
  }

  function editProduct(id) {
    const item = state.products.find((product) => product.id === id);
    if (!item) return;
    const name = prompt('Nome do produto:', item.name); if (name == null) return;
    const price = prompt('Preço/oferta:', item.price || ''); if (price == null) return;
    const commissionRate = prompt('Comissão estimada do produto (%):', String(Number(item.commissionRate) || 0)); if (commissionRate == null) return;
    const pitch = prompt('Argumento principal:', item.pitch || ''); if (pitch == null) return;
    const objections = prompt('Respostas para objeções:', item.objections || ''); if (objections == null) return;
    const script = prompt('Mini roteiro:', item.script || ''); if (script == null) return;
    Object.assign(item, { name: name.trim() || item.name, price, commissionRate: Math.max(0, Math.min(100, Number(String(commissionRate).replace(',', '.')) || 0)), pitch, objections, script });
    save(true); renderAll();
  }

  const scrapeWait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

  function visibleTikTokProducts() {
    const products = [];
    const seen = new Set();
    const priceNodes = [...document.querySelectorAll('span')].filter((node) => {
      if (node.closest('#plw-liveops-root, #liveos-command-center')) return false;
      return /^R\$\s*[\d.]+,\d{2}$/.test(String(node.textContent || '').trim());
    });
    priceNodes.forEach((priceNode) => {
      let row = priceNode.closest('.rounded-4.mb-8');
      if (!row) {
        let candidate = priceNode.parentElement;
        for (let depth = 0; candidate && depth < 10; depth++, candidate = candidate.parentElement) {
          const text = String(candidate.innerText || candidate.textContent || '');
          if (/Em estoque:/i.test(text) && candidate.querySelector('img')) { row = candidate; break; }
        }
      }
      if (!row || row.closest('#plw-liveops-root, #liveos-command-center')) return;
      const rowText = String(row.innerText || row.textContent || '').replace(/\s+/g, ' ').trim();
      const nameNode = row.querySelector('[class*="text-body-m-regular"][class*="overflow-ellipsis"]');
      let name = String(nameNode?.textContent || '').replace(/\s+/g, ' ').trim();
      if (!name) {
        name = [...row.querySelectorAll('span')].map((node) => String(node.textContent || '').replace(/\s+/g, ' ').trim())
          .filter((text) => text.length > 3 && !/^R\$/.test(text) && !/^Em estoque:/i.test(text) && !/^Demonstração/i.test(text))
          .sort((a, b) => b.length - a.length)[0] || '';
      }
      if (!name) return;
      const key = name.toLocaleLowerCase('pt-BR');
      if (seen.has(key)) return;
      seen.add(key);
      const stockMatch = rowText.match(/Em estoque:\s*(.+?)(?=\s+Demonstração solicitada|$)/i);
      const orderInput = row.querySelector('.pc_order_input input[role="spinbutton"], input[role="spinbutton"]');
      const imageNode = row.querySelector('img');
      products.push({
        name,
        price: String(priceNode.textContent || '').trim(),
        stock: String(stockMatch?.[1] || '').trim(),
        image: String(imageNode?.currentSrc || imageNode?.src || ''),
        order: Number(orderInput?.value || orderInput?.getAttribute('value')) || 0,
        source: 'tiktok-dom'
      });
    });
    return products;
  }

  function productScroller() {
    const direct = document.querySelector('[class*="virtualized-container"]');
    if (direct && direct.scrollHeight > direct.clientHeight) return direct;
    const search = [...document.querySelectorAll('input')].find((input) => /nome do produto/i.test(input.placeholder || ''));
    let node = search?.parentElement;
    while (node && node !== document.body) {
      const style = getComputedStyle(node);
      if (node.scrollHeight > node.clientHeight + 20 && /(auto|scroll)/.test(style.overflowY)) return node;
      node = node.parentElement;
    }
    return null;
  }

  async function scrapeTikTokProducts() {
    const collected = new Map();
    const collect = () => visibleTikTokProducts().forEach((item) => collected.set(item.name.toLocaleLowerCase('pt-BR'), item));
    collect();
    const scroller = productScroller();
    if (scroller) {
      const originalTop = scroller.scrollTop;
      let previousTop = -1;
      for (let step = 0; step < 80; step++) {
        collect();
        const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
        if (scroller.scrollTop >= maxTop - 2 || scroller.scrollTop === previousTop) break;
        previousTop = scroller.scrollTop;
        scroller.scrollTop = Math.min(maxTop, scroller.scrollTop + Math.max(180, Math.round(scroller.clientHeight * 0.72)));
        scroller.dispatchEvent(new Event('scroll', { bubbles: true }));
        await scrapeWait(160);
      }
      collect();
      scroller.scrollTop = originalTop;
      scroller.dispatchEvent(new Event('scroll', { bubbles: true }));
      await scrapeWait(80);
    }
    return [...collected.values()].sort((a, b) => (a.order || Number.MAX_SAFE_INTEGER) - (b.order || Number.MAX_SAFE_INTEGER));
  }

  function download(name, type, content) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const link = document.createElement('a'); link.href = url; link.download = name; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function exportCsv() {
    const rows = [['produto','pins','segundos_no_ar','vendas','vendas_pagas','gmv','comissao_estimada','ticket_medio','gmv_por_minuto','venda_mais_rapida_seg'], ...productMetrics().map((row) => [row.product.name, row.pins, Math.round(row.seconds), row.quantity, row.paidQuantity, row.gmv, row.commission, row.ticket, row.gmvPerMinute, Number.isFinite(row.fastestSaleSec) ? row.fastestSaleSec : ''])];
    download(`liveos-metricas-${new Date().toISOString().slice(0,10)}.csv`, 'text/csv;charset=utf-8', '\ufeff' + rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"','""')}"`).join(';')).join('\n'));
  }

  function exportReport() {
    const rows = productMetrics();
    const snapshot = sessionSnapshot();
    const text = [`RELATÓRIO LIVEOS — ${new Date().toLocaleString('pt-BR')}`, '', `Duração: ${fmtTime(snapshot.durationSec)}`, `Comentários captados: ${state.comments.filter((item) => !state.session.startedAt || item.at >= state.session.startedAt).length}`, `Vendas: ${snapshot.orders}`, `Vendas pagas: ${snapshot.paidOrders}`, `GMV: ${formatMoney(snapshot.gmv)}`, `Comissão estimada: ${formatMoney(snapshot.commission)}`, `Ticket médio: ${formatMoney(snapshot.orders ? snapshot.gmv / snapshot.orders : 0)}`, `Pico de espectadores: ${snapshot.peakViewers}`, '', 'PRODUTOS', ...rows.filter((row) => row.quantity || row.seconds).map((row, i) => `${i+1}. ${row.product.name} — ${row.pins} pins, ${fmtTime(row.seconds)} no ar, ${row.quantity} venda(s), ${formatMoney(row.gmv)}, comissão ${formatMoney(row.commission)}, ${formatMoney(row.gmvPerMinute)}/min${Number.isFinite(row.fastestSaleSec) ? `, venda mais rápida ${fmtTime(row.fastestSaleSec)}` : ''}`)].join('\n');
    download(`liveos-relatorio-${new Date().toISOString().slice(0,10)}.txt`, 'text/plain;charset=utf-8', text);
  }

  async function onClick(event) {
    const tab = event.target.closest('[data-tab]');
    if (tab) return switchTab(tab.dataset.tab);
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const { action, id, dir } = button.dataset;
    if (action === 'close') return close();
    if (action === 'moderator') { state.settings.moderatorMode = !state.settings.moderatorMode; applyMode(); save(true); return switchTab(state.settings.moderatorMode ? 'comments' : 'now'); }
    if (action === 'toggle-session') return toggleSession();
    if (action === 'set-product') return setProduct(id);
    if (action === 'ai-task') return runAi(button.dataset.task);
    if (action === 'ai-comment') return runAi('reply', id);
    if (action === 'ai-product') { if (id && state.currentProductId !== id) state.currentProductId = id; return runAi(button.dataset.task || 'pitch'); }
    if (action === 'copy-ai') return copyText(aiResult);
    if (action === 'apply-ai-pitch' && currentProduct()) { currentProduct().pitch = aiResult; save(true); renderAll(); return toast('Argumento atualizado com o rascunho da IA.'); }
    if (action === 'apply-ai-script' && currentProduct()) { currentProduct().script = aiResult; save(true); renderAll(); return toast('Roteiro atualizado com o rascunho da IA.'); }
    if (action === 'test-ai') return runAi('custom', 'Responda somente com: conexão da IA funcionando.');
    if (action === 'reset-ai-models') {
      const response = await proRpc({ type: 'LIVEOS_AI_SAVE_CONFIG', config: { ...aiConfig, groqModel: 'openai/gpt-oss-20b', geminiModel: 'gemini-3.6-flash' } });
      if (!response?.ok) return toast(response?.error || 'Não foi possível atualizar os modelos.');
      aiConfig = { ...aiConfig, ...response.config }; render('ai'); return toast('Modelos atuais restaurados.');
    }
    if (action === 'clear-ai-keys' && confirm('Apagar as chaves Gemini e Groq salvas nesta extensão?')) {
      const response = await proRpc({ type: 'LIVEOS_AI_SAVE_CONFIG', config: { ...aiConfig, clearGemini: true, clearGroq: true } });
      if (response?.ok) aiConfig = { ...aiConfig, ...response.config }; render('ai'); return toast('Chaves removidas.');
    }
    if (action === 'telegram-test') {
      toast('Enviando mensagem de teste…');
      const response = await proRpc({ type: 'LIVEOS_TG_TEST' });
      return toast(response?.ok ? 'Mensagem de teste enviada ao Telegram.' : response?.error || 'O teste do Telegram falhou.');
    }
    if (action === 'telegram-find-chat') {
      const form = button.closest('[data-form="telegram-config"]');
      const data = new FormData(form);
      const saved = await proRpc({ type: 'LIVEOS_TG_SAVE_CONFIG', config: {
        enabled: data.get('enabled') === 'on', notifyManual: data.get('notifyManual') === 'on', notifyDetected: data.get('notifyDetected') === 'on', notifySafety: data.get('notifySafety') === 'on',
        botToken: String(data.get('botToken') || ''), chatId: String(data.get('chatId') || '')
      } });
      if (!saved?.ok) return toast(saved?.error || 'Não foi possível salvar o token.');
      telegramConfig = { ...telegramConfig, ...saved.config };
      const response = await proRpc({ type: 'LIVEOS_TG_FIND_CHAT' });
      if (!response?.ok) return toast(response?.error || 'Não foi possível localizar a conversa.');
      telegramConfig = { ...telegramConfig, ...response.config }; render('telegram');
      return toast(`Chat localizado: ${response.config.chatName || response.config.chatId}.`);
    }
    if (action === 'telegram-clear' && confirm('Apagar o token e o chat ID do Telegram?')) {
      const response = await proRpc({ type: 'LIVEOS_TG_SAVE_CONFIG', config: { ...telegramConfig, clearToken: true, clearChatId: true } });
      if (response?.ok) telegramConfig = { ...telegramConfig, ...response.config }; render('telegram'); return toast(response?.ok ? 'Dados do Telegram removidos.' : response?.error || 'Não foi possível apagar.');
    }
    if (action === 'import-products') {
      toast('Lendo os produtos da página…');
      await readHostState();
      const scraped = await scrapeTikTokProducts();
      const source = [...(Array.isArray(hostState.playlist) ? hostState.playlist : []), ...scraped];
      let added = 0;
      let updated = 0;
      source.forEach((item) => {
        const name = String(item.name || item.title || item.productName || '').trim();
        if (!name) return;
        const existing = state.products.find((product) => product.name.toLocaleLowerCase('pt-BR') === name.toLocaleLowerCase('pt-BR'));
        if (existing) {
          const before = JSON.stringify([existing.price, existing.stock, existing.image]);
          if (item.price) existing.price = String(item.price);
          if (item.stock) existing.stock = String(item.stock);
          if (item.image) existing.image = String(item.image);
          if (before !== JSON.stringify([existing.price, existing.stock, existing.image])) updated++;
          return;
        }
        state.products.push({ id: uid('product'), name, price: String(item.price || ''), stock: String(item.stock || ''), image: String(item.image || ''), commissionRate: 0, pitch: '', objections: '', script: '' }); added++;
      });
      save(true); renderAll();
      if (added || updated) return toast(`${added} produto(s) adicionado(s) e ${updated} atualizado(s).`);
      return toast(scraped.length ? 'Os produtos da página já estavam atualizados.' : 'Nenhum produto foi encontrado. Abra a lista de produtos do TikTok e tente novamente.');
    }
    if (action === 'refresh-pin') return currentProduct() && setProduct(state.currentProductId, true);
    if (action === 'next-product') return nextProduct();
    if (action === 'copy-pitch') return currentProduct() && copyText(currentProduct().pitch || currentProduct().script || currentProduct().name);
    if (action === 'sale') return addSale();
    if (action === 'edit-product') return editProduct(id);
    if (action === 'delete-product') { if (confirm('Excluir este cartão?')) { state.products = state.products.filter((item) => item.id !== id); if (state.currentProductId === id) { state.currentProductId = null; state.pinStartedAt = null; } save(true); renderAll(); } return; }
    if (action === 'move-product') { const from = state.products.findIndex((item) => item.id === id); const to = Math.max(0, Math.min(state.products.length - 1, from + Number(dir))); if (from >= 0 && from !== to) { state.products.splice(to, 0, state.products.splice(from, 1)[0]); save(true); render('products'); } return; }
    if (action === 'scan-now') { scanComments(); render('comments'); return toast('Página verificada.'); }
    if (action === 'clear-comments') { if (confirm('Limpar a fila de comentários captados?')) { state.comments = []; seenComments.clear(); save(true); renderAll(); } return; }
    if (action === 'copy-reply') { const item = state.comments.find((comment) => comment.id === id); if (item) copyText(suggestedReply(item)); return; }
    if (action === 'engagement-generate') { generateEngagementSuggestion(); return; }
    if (action === 'engagement-publish') { if (engagementSuggestion) publishCommentToTikTok(engagementSuggestion); return; }
    if (action === 'engagement-copy') { if (engagementSuggestion) copyText(engagementSuggestion); return; }
    if (action === 'comment-done' || action === 'comment-hide') { const item = state.comments.find((comment) => comment.id === id); if (item) item.status = action === 'comment-done' ? 'done' : 'hidden'; save(); renderAll(); return; }
    if (action === 'toggle-rundown') { const item = state.rundown.find((row) => row.id === id); if (item) { item.done = !item.done; log('rundown', { title: item.title, done: item.done }); save(); renderAll(); } return; }
    if (action === 'delete-rundown') { state.rundown = state.rundown.filter((row) => row.id !== id); save(); render('rundown'); return; }
    if (action === 'reset-rundown') { state.rundown = state.rundown.map((item) => ({ ...item, done: false })); save(); render('rundown'); return; }
    if (action === 'scan-compliance') { render('safety'); return toast(complianceFindings().length ? 'Foram encontrados termos para revisar.' : 'Nenhum termo configurado foi encontrado.'); }
    if (action === 'health-check') { toast('Procurando o app local…'); return checkHealth(); }
    if (action === 'app-command') return sendAppCommand(button.dataset.command);
    if (action === 'export-csv') return exportCsv();
    if (action === 'export-report') return exportReport();
    if (action === 'telegram-summary') {
      toast('Enviando resumo ao Telegram…');
      const response = await sendTelegramSummary(false);
      return toast(response?.ok && !response.skipped ? 'Resumo enviado ao Telegram.' : response?.error || 'Não há vendas ou Telegram configurado.');
    }
    if (action === 'accept-metric-baseline' || action === 'dismiss-anomaly') {
      const anomaly = state.analytics.anomalies.find((item) => item.id === id);
      if (!anomaly) return;
      anomaly.resolved = true;
      anomaly.resolution = action === 'accept-metric-baseline' ? 'baseline' : 'ignored';
      if (action === 'accept-metric-baseline') {
        lastHostOrders = Number(anomaly.orders);
        lastHostGmv = Number.isFinite(Number(anomaly.gmv)) ? Number(anomaly.gmv) : lastHostGmv;
        lastHostCommission = Number.isFinite(Number(anomaly.commission)) ? Number(anomaly.commission) : lastHostCommission;
      }
      save(true); render('metrics');
      return toast(action === 'accept-metric-baseline' ? 'Nova base aceita sem registrar venda.' : 'Alerta ignorado; nenhuma venda foi criada.');
    }
    if (action === 'reattribute-sale') {
      const sale = state.sales.find((item) => item.id === id);
      if (!sale || !state.products.length) return;
      const menu = state.products.map((product, index) => `${index + 1}. ${product.name}`).join('\n');
      const selected = Number(prompt(`Escolha o produto correto:\n${menu}`, '1')) - 1;
      const product = state.products[selected];
      if (!product) return toast('Produto não alterado.');
      sale.productId = product.id; sale.productName = product.name; sale.correctedAt = Date.now();
      save(true); render('metrics'); return toast(`Venda atribuída a ${product.name}.`);
    }
    if (action === 'export-backup') return download(`liveos-backup-${new Date().toISOString().slice(0,10)}.json`, 'application/json', JSON.stringify(state, null, 2));
    if (action === 'reset-all' && confirm('Restaurar apenas a nova Central Ao Vivo? Os recursos antigos não serão apagados.')) { state = structuredClone(DEFAULTS); save(true); applyMode(); renderAll(); }
  }

  function onChange(event) {
    const check = event.target.dataset.check;
    if (check) { state.checklist[check] = event.target.checked; save(); render('safety'); }
    if (event.target.matches('[data-import]')) importBackup(event.target.files?.[0]);
    const actionChange = event.target.dataset.actionChange;
    if (actionChange === 'toggle-engagement-mode') {
      const mode = event.target.value;
      if (mode === 'off') {
        state.settings.engagementReminderEnabled = false;
        state.settings.engagementAutoPublish = false;
      } else if (mode === 'manual') {
        state.settings.engagementReminderEnabled = true;
        state.settings.engagementAutoPublish = false;
      } else if (mode === 'auto') {
        state.settings.engagementReminderEnabled = true;
        state.settings.engagementAutoPublish = true;
      }
      save(true); scheduleEngagementReminder(true); renderAll();
      toast(mode === 'auto' ? 'Modo 100% Automático ativado!' : mode === 'manual' ? 'Modo Manual ativado.' : 'Comentários desativados.');
    }
    if (actionChange === 'apply-engagement-preset' || actionChange === 'apply-preset-settings') {
      const presetId = event.target.value;
      const preset = ENGAGEMENT_PRESETS.find((p) => p.id === presetId);
      if (preset) {
        state.settings.engagementMinSec = preset.min;
        state.settings.engagementMaxSec = preset.max;
        save(true); scheduleEngagementReminder(true); renderAll();
        toast(`Preset aplicado: ${preset.label}`);
      }
    }
  }

  async function onSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const data = new FormData(form);
    if (form.dataset.form === 'product') {
      state.products.push({ id: uid('product'), name: String(data.get('name') || '').trim(), price: String(data.get('price') || '').trim(), commissionRate: Math.max(0, Math.min(100, Number(data.get('commissionRate')) || 0)), pitch: String(data.get('pitch') || '').trim(), objections: String(data.get('objections') || '').trim(), script: String(data.get('script') || '').trim() });
      save(true); form.reset(); renderAll(); toast('Produto adicionado.');
    }
    if (form.dataset.form === 'rundown') {
      state.rundown.push({ id: uid('rd'), title: String(data.get('title') || '').trim(), minutes: Number(data.get('minutes')) || 5, done: false });
      save(true); render('rundown');
    }
    if (form.dataset.form === 'settings') {
      state.settings.pinReminderSec = Math.max(15, Math.min(300, Number(data.get('pinReminderSec')) || 30));
      state.settings.commentScan = data.get('commentScan') === 'on'; state.settings.hotkeys = data.get('hotkeys') === 'on';
      state.settings.engagementReminderEnabled = data.get('engagementReminderEnabled') === 'on';
      state.settings.engagementAutoPublish = data.get('engagementAutoPublish') === 'on';
      state.settings.engagementMinSec = Math.max(15, Math.min(3600, Number(data.get('engagementMinSec')) || 45));
      state.settings.engagementMaxSec = Math.max(state.settings.engagementMinSec, Math.min(3600, Number(data.get('engagementMaxSec')) || 90));
      state.settings.engagementTemplates = String(data.get('engagementTemplates') || '').trim();
      state.settings.companionUrl = String(data.get('companionUrl') || DEFAULTS.settings.companionUrl).trim();
      state.settings.videoFrameMode = data.get('videoFrameMode') === 'crop' ? 'crop' : 'fit';
      state.settings.captureProfile = data.get('captureProfile') === 'low' ? 'low' : 'performance';
      state.settings.safeScale = Math.max(0.5, Math.min(1.5, (Number(data.get('safeScale')) || 100) / 100));
      state.settings.outputFps = 30;
      state.settings.videoPipelineVersion = 4;
      state.settings.saleSummaryMinutes = Math.max(0, Math.min(240, Number(data.get('saleSummaryMinutes')) || 0));
      state.settings.maxOrderJump = Math.max(1, Math.min(500, Number(data.get('maxOrderJump')) || 10));
      state.settings.metricConfirmReads = Math.max(2, Math.min(5, Number(data.get('metricConfirmReads')) || 2));
      state.settings.defaultCommissionRate = Math.max(0, Math.min(100, Number(data.get('defaultCommissionRate')) || 0));
      state.settings.telegramSummaryEnabled = data.get('telegramSummaryEnabled') === 'on';
      state.settings.riskTerms = String(data.get('riskTerms') || ''); state.settings.blockedTerms = String(data.get('blockedTerms') || '');
      save(true); restartHealth(); scheduleEngagementReminder(true);
      try {
        const response = await proRpc({ type: 'LIVEOS_CC_OUTPUT_CONFIG', url: state.settings.companionUrl, config: { frameMode: state.settings.videoFrameMode, captureProfile: state.settings.captureProfile, safeScale: state.settings.safeScale, outputFps: state.settings.outputFps } }, 6000);
        toast(response?.ok ? 'Saída de vídeo aplicada no app.' : (response?.error || 'Configurações salvas; abra o app para aplicar o vídeo.'));
      } catch (error) { toast('Configurações salvas; abra o app para aplicar o vídeo.'); }
    }
    if (form.dataset.form === 'ai-prompt') return runAi('custom', String(data.get('prompt') || ''));
    if (form.dataset.form === 'ai-config') {
      const response = await proRpc({ type: 'LIVEOS_AI_SAVE_CONFIG', config: {
        provider: String(data.get('provider') || 'groq'), groqModel: String(data.get('groqModel') || ''), geminiModel: String(data.get('geminiModel') || ''), groqKey: String(data.get('groqKey') || ''), geminiKey: String(data.get('geminiKey') || '')
      } });
      if (!response?.ok) return toast(response?.error || 'Não foi possível salvar a IA.');
      aiConfig = { ...aiConfig, ...response.config }; form.reset(); render('ai'); toast('Configuração de IA salva localmente.');
    }
    if (form.dataset.form === 'telegram-config') {
      const response = await proRpc({ type: 'LIVEOS_TG_SAVE_CONFIG', config: {
        enabled: data.get('enabled') === 'on', notifyManual: data.get('notifyManual') === 'on', notifyDetected: data.get('notifyDetected') === 'on', notifySafety: data.get('notifySafety') === 'on',
        botToken: String(data.get('botToken') || ''), chatId: String(data.get('chatId') || '')
      } });
      if (!response?.ok) return toast(response?.error || 'Não foi possível salvar o Telegram.');
      telegramConfig = { ...telegramConfig, ...response.config }; render('telegram'); toast('Configuração do Telegram salva.');
    }
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.products)) throw new Error('Formato inválido');
      state = merge(structuredClone(DEFAULTS), parsed); save(true); applyMode(); renderAll(); toast('Backup importado.');
    } catch { toast('Este arquivo não é um backup válido da Central Ao Vivo.'); }
  }

  function scanComments() {
    if (!state.settings.commentScan) return;
    const selectors = ['[data-e2e*="comment"]','[class*="CommentItem"]','[class*="comment-item"]','[class*="ChatMessage"]','[class*="chat-message"]','[class*="comment"]'];
    const nodes = [...new Set(selectors.flatMap((selector) => [...document.querySelectorAll(selector)]))].slice(-120);
    let added = 0;
    for (const node of nodes) {
      if (node.closest('#liveos-command-center, #plw-liveops-root')) continue;
      const text = String(node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
      if (text.length < 3 || text.length > 420) continue;
      const normalized = text.toLocaleLowerCase('pt-BR');
      let hash = 2166136261;
      for (let i = 0; i < normalized.length; i++) hash = Math.imul(hash ^ normalized.charCodeAt(i), 16777619);
      const id = `comment_${(hash >>> 0).toString(36)}`;
      if (processedCommentNodes.get(node) === id) continue;
      processedCommentNodes.set(node, id);
      if (seenComments.has(id)) {
        const repeated = state.comments.find((item) => item.id === id);
        if (repeated) repeated.repeats = Number(repeated.repeats || 1) + 1;
        continue;
      }
      seenComments.add(id);
      const parts = text.split(/[:：]/, 2);
      state.comments.unshift({ id, author: parts.length > 1 && parts[0].length < 50 ? parts[0] : '', text: parts.length > 1 ? text.slice(parts[0].length + 1).trim() : text, category: classify(text), at: Date.now(), status: 'new' });
      added++; lastDomActivity = Date.now();
    }
    if (state.comments.length > MAX_COMMENTS) state.comments.length = MAX_COMMENTS;
    if (added) { log('comments', { count: added }); save(); if (activeTab === 'comments') render('comments'); updateHeader(); }
  }

  async function checkHealth() {
    try {
      const response = await proRpc({ type: 'LIVEOS_CC_HEALTH', url: state.settings.companionUrl }, 5000);
      companionOnline = Boolean(response?.ok);
      healthDetails = {};
      if (response?.data) {
        const data = response.data;
        const camera = data.camera ?? data.video ?? data.cameraActive;
        const audio = data.audio ?? data.audioActive;
        healthDetails.status = String(data.status || (data.is_playing ? 'playing' : '')).trim();
        healthDetails.currentIndex = Math.max(0, Number(data.currentIndex ?? data.current_index) || 0);
        const totalVideos = Number(data.totalVideos ?? data.total_videos ?? data.playlistLength ?? data.playlist?.length);
        if (Number.isFinite(totalVideos)) healthDetails.totalVideos = Math.max(0, totalVideos);
        if (camera === false || audio === false) healthDetails.label = camera === false ? 'câmera inativa' : 'áudio inativo';
        else if (camera === true || audio === true) healthDetails.label = 'sinais ativos';
      }
    }
    catch { companionOnline = false; healthDetails = {}; }
    finally { if (activeTab === 'now') render('now'); updateHeader(); }
  }
  async function sendAppCommand(command) {
    if (!['play', 'pause', 'next'].includes(command)) return;
    const labels = { play: 'Reproduzir', pause: 'Pausar', next: 'Próximo vídeo' };
    toast(`${labels[command]} no app…`);
    try {
      const response = await proRpc({ type: 'LIVEOS_CC_APP_COMMAND', url: state.settings.companionUrl, command }, 6000);
      if (!response?.ok) return toast(response?.error || 'O app não aceitou o comando.');
      await checkHealth();
      toast(`Comando enviado: ${labels[command]}.`);
    } catch (error) { toast(String(error?.message || error)); }
  }
  function restartHealth() { clearInterval(healthTimer); checkHealth(); healthTimer = setInterval(checkHealth, 8000); }

  function trackViewers(viewers) {
    if (!Number.isFinite(viewers) || viewers < 0) return;
    const now = Date.now();
    const lastSample = state.analytics.viewerSamples.at(-1);
    const newPeak = viewers > Number(state.analytics.peakViewers || 0);
    if (newPeak) state.analytics.peakViewers = viewers;
    if (!lastSample || now - lastSample.at >= 60000) state.analytics.viewerSamples.push({ at: now, viewers });
    if (state.analytics.viewerSamples.length > 720) state.analytics.viewerSamples.splice(0, state.analytics.viewerSamples.length - 720);
    if (newPeak || !lastSample || now - lastSample.at >= 60000) save();
  }

  async function maybeSendPeriodicSummary() {
    const minutes = Number(state.settings.saleSummaryMinutes) || 0;
    if (!state.session.active || !state.settings.telegramSummaryEnabled || minutes <= 0 || !telegramConfig.ready) return;
    const last = Number(state.analytics.lastSummaryAt || state.session.startedAt) || Date.now();
    if (Date.now() - last >= minutes * 60000) await sendTelegramSummary(false);
  }

  async function acceptHostState(nextState, metricsV2 = null) {
    hostState = nextState && typeof nextState === 'object' ? { ...nextState } : {};
    if (metricsV2 && typeof metricsV2 === 'object') {
      const rawOrders = Number(metricsV2.orders);
      const explicitPaidOrders = Number(metricsV2.paidOrders);
      const pendingOrders = Number(metricsV2.pendingOrders);
      const cancelledOrders = Number(metricsV2.cancelledOrders);
      const genericOrderLabel = String(metricsV2.evidence?.orders?.label || '');
      const genericMeansPaid = /itens?.*(?:atribu[ií]dos?.*vendidos?|vendidos?.*atribu[ií]dos?)/i.test(genericOrderLabel);
      const canDerivePaid = Number.isFinite(rawOrders) && Number.isFinite(pendingOrders) && /^(pedidos?|pedidos? criados?)$/i.test(genericOrderLabel);
      const orderValue = Number.isFinite(explicitPaidOrders)
        ? explicitPaidOrders
        : canDerivePaid ? Math.max(0, rawOrders - pendingOrders - (Number.isFinite(cancelledOrders) ? cancelledOrders : 0))
          : metricsV2.orderKey ? Number(metricsV2[metricsV2.orderKey]) : NaN;
      const effectiveOrderKey = Number.isFinite(explicitPaidOrders) ? 'paidOrders' : canDerivePaid ? 'derivedPaidOrders' : genericMeansPaid ? 'paidOrders' : metricsV2.orderKey;
      const gmvValue = metricsV2.gmvKey ? Number(metricsV2[metricsV2.gmvKey]) : NaN;
      hostState = {
        ...hostState,
        gmvOrders: Number.isFinite(orderValue) ? orderValue : undefined,
        gmvCurrent: Number.isFinite(gmvValue) ? gmvValue : undefined,
        gmvCommission: Number.isFinite(Number(metricsV2.commission)) ? Number(metricsV2.commission) : undefined,
        totalOrders: Number.isFinite(rawOrders) ? rawOrders : undefined,
        paidOrders: Number.isFinite(explicitPaidOrders) ? explicitPaidOrders : (canDerivePaid || genericMeansPaid) ? orderValue : undefined,
        pendingOrders: Number.isFinite(pendingOrders) ? pendingOrders : undefined,
        cancelledOrders: Number.isFinite(cancelledOrders) ? cancelledOrders : undefined,
        viewers: Number.isFinite(Number(metricsV2.viewers)) ? Number(metricsV2.viewers) : undefined,
        orderMetricKey: effectiveOrderKey,
        metricsTrusted: metricsV2.trustedOrders === true,
        metricsEvidence: metricsV2.evidence || {}
      };
    } else hostState.metricsTrusted = false;
    trackViewers(Number(hostState.viewers));
    void maybeSendPeriodicSummary();
    if (hostState.metricsTrusted !== true) return;
    const orders = Number(hostState.gmvOrders);
    const gmv = Number(hostState.gmvCurrent);
    const commissionTotal = Number(hostState.gmvCommission);
    if (!Number.isFinite(orders) || orders < 0) return;
    const candidateKey = `${orders}|${Number.isFinite(gmv) ? gmv : ''}|${Number.isFinite(commissionTotal) ? commissionTotal : ''}|${hostState.orderMetricKey || ''}`;
    if (candidateKey !== metricCandidateKey) {
      metricCandidateKey = candidateKey;
      metricCandidateHits = 1;
      return;
    }
    metricCandidateHits += 1;
    if (metricCandidateHits < Math.max(2, Number(state.settings.metricConfirmReads) || 2)) return;
    if (lastHostOrders == null) {
      lastHostOrders = orders;
      lastHostGmv = Number.isFinite(gmv) ? gmv : null;
      lastHostCommission = Number.isFinite(commissionTotal) ? commissionTotal : null;
      return;
    }
    if (orders < lastHostOrders) {
      lastHostOrders = orders;
      lastHostGmv = Number.isFinite(gmv) ? gmv : null;
      lastHostCommission = Number.isFinite(commissionTotal) ? commissionTotal : null;
      return;
    }
    if (orders === lastHostOrders) {
      if (Number.isFinite(gmv)) lastHostGmv = gmv;
      if (Number.isFinite(commissionTotal)) lastHostCommission = commissionTotal;
      return;
    }
    const previousOrders = lastHostOrders;
    const previousGmv = lastHostGmv;
    const previousCommission = lastHostCommission;
    const orderDelta = Math.max(1, orders - previousOrders);
    const maxJump = Math.max(1, Number(state.settings.maxOrderJump) || 10);
    if (orderDelta > maxJump) {
      const anomalyKey = `${previousOrders}:${orders}:${state.session.id || 'sem-sessao'}`;
      if (!state.analytics.anomalies.some((item) => item.key === anomalyKey && !item.resolved)) {
        state.analytics.anomalies.push({ id: uid('anomaly'), key: anomalyKey, at: Date.now(), previousOrders, orders, delta: orderDelta, gmv: Number.isFinite(gmv) ? gmv : null, commission: Number.isFinite(commissionTotal) ? commissionTotal : null, resolved: false, evidence: hostState.metricsEvidence });
        state.analytics.anomalies = state.analytics.anomalies.slice(-100);
        log('metric_anomaly', { previousOrders, orders, orderDelta });
        save(true);
        if (activeTab === 'metrics') render('metrics');
        toast(`Salto de ${orderDelta} pedidos bloqueado. Revise em Métricas.`);
      }
      return;
    }
    lastHostOrders = orders;
    lastHostGmv = Number.isFinite(gmv) ? gmv : previousGmv;
    lastHostCommission = Number.isFinite(commissionTotal) ? commissionTotal : previousCommission;
    const product = currentProduct();
    const productUnitPrice = parseProductPrice(product);

    let value = Number.isFinite(gmv) && Number.isFinite(previousGmv) ? Math.max(0, gmv - previousGmv) : 0;
    if (value <= 0 && productUnitPrice > 0 && orderDelta > 0) {
      value = productUnitPrice * orderDelta;
    }

    const commissionRate = Number(product?.commissionRate) > 0 ? Number(product.commissionRate) : Math.max(0, Number(state.settings.defaultCommissionRate) || 0);
    let commission = Number.isFinite(commissionTotal) && Number.isFinite(previousCommission)
      ? Math.max(0, commissionTotal - previousCommission)
      : value * commissionRate / 100;
    if (commission <= 0 && value > 0 && commissionRate > 0) {
      commission = value * commissionRate / 100;
    }

    const currentSessionGmv = currentSessionSales().reduce((sum, item) => sum + Number(item.value || 0), 0) + value;
    const currentSessionComm = currentSessionSales().reduce((sum, item) => sum + saleCommission(item), 0) + commission;
    const calculatedTotalGmv = Number.isFinite(gmv) && gmv > 0 ? gmv : (currentSessionGmv > 0 ? currentSessionGmv : null);
    const calculatedTotalCommission = Number.isFinite(commissionTotal) && commissionTotal > 0 ? commissionTotal : (currentSessionComm > 0 ? currentSessionComm : null);

    const status = ['paidOrders', 'derivedPaidOrders'].includes(hostState.orderMetricKey) ? 'paid' : 'detected';
    const eventId = `detected:${state.session.id || state.session.startedAt || 'sem-sessao'}:${status}:${orders}`;
    if (state.analytics.processedMetricEvents.includes(eventId)) return;
    state.analytics.processedMetricEvents.push(eventId);
    state.analytics.processedMetricEvents = state.analytics.processedMetricEvents.slice(-1000);
    const timeToSaleSec = state.pinStartedAt ? Math.max(0, Math.round((Date.now() - state.pinStartedAt) / 1000)) : null;
    const firstProductSale = Boolean(product?.id) && !currentSessionSales().some((item) => item.productId === product.id);
    const sale = { id: uid('sale'), eventId, at: Date.now(), sessionId: state.session.id, productId: product?.id || null, productName: product?.name || '', value, commission, quantity: orderDelta, source: 'detected', status, firstProductSale, timeToSaleSec, totalOrders: orders, totalGmv: calculatedTotalGmv, totalCommission: calculatedTotalCommission };
    state.sales.push(sale);
    state.sales = state.sales.slice(-MAX_SALES);
    save(true);
    const response = await notifyTelegramSale({
      eventId, source: 'detected', product, value, commission, status, firstProductSale, timeToSaleSec, orderDelta, totalOrders: orders, pendingOrders: hostState.pendingOrders, cancelledOrders: hostState.cancelledOrders, totalGmv: calculatedTotalGmv ?? undefined, totalCommission: calculatedTotalCommission ?? undefined
    });
    if (response?.ok && !response.skipped && !response.duplicate) {
      log('telegram_sale', { productId: product?.id || null, value, orderDelta, totalOrders: orders });
      toast(`${orderDelta} nova(s) venda(s) enviada(s) ao Telegram.`);
    } else if (!response?.ok && telegramConfig.enabled && telegramConfig.notifyDetected) {
      toast(response?.error || 'Venda detectada, mas o Telegram falhou.');
    }
  }

  async function readHostState() {
    let nextState = {};
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
      if (response && typeof response === 'object') nextState = response.state || response;
    } catch {}
    let metricsV2 = null;
    try { metricsV2 = globalThis.LiveOSMetricsV2?.scan(document) || null; } catch {}
    await acceptHostState(nextState, metricsV2);
  }

  function engagementTemplateList() {
    return String(state.settings.engagementTemplates || '')
      .split(/\r?\n/).map((item) => item.trim()).filter(Boolean).slice(0, 100);
  }

  function scheduleEngagementReminder(reset = false) {
    if (!state.settings.engagementReminderEnabled || !engagementTemplateList().length) {
      engagementNextAt = null;
      return;
    }
    if (engagementNextAt && !reset) return;
    const min = Math.max(15, Number(state.settings.engagementMinSec) || 45);
    const max = Math.max(min, Number(state.settings.engagementMaxSec) || 90);
    engagementNextAt = Date.now() + Math.round((min + Math.random() * (max - min)) * 1000);
  }

  function generateEngagementSuggestion(isAutomatic = false) {
    const templates = engagementTemplateList();
    if (!templates.length) return toast('Cadastre pelo menos um comentário nas configurações.');
    const choices = templates.length > 1 ? templates.filter((item) => item !== engagementSuggestion) : templates;
    engagementSuggestion = choices[Math.floor(Math.random() * choices.length)] || templates[0];
    scheduleEngagementReminder(true);
    if (activeTab === 'comments') render('comments');
    if (isAutomatic && state.settings.engagementAutoPublish) {
      toast('Publicando comentário automático no TikTok…');
      publishCommentToTikTok(engagementSuggestion);
    } else {
      toast('Nova sugestão pronta.');
    }
  }

  function tickEngagementReminder() {
    scheduleEngagementReminder();
    if (engagementNextAt && Date.now() >= engagementNextAt) generateEngagementSuggestion(true);
  }

  function onKey(event) {
    if (!state.settings.hotkeys || event.repeat || /INPUT|TEXTAREA|SELECT/.test(event.target?.tagName)) return;
    if (event.ctrlKey && event.shiftKey && event.code === 'KeyO') { event.preventDefault(); panel.hidden ? open() : close(); }
    else if (event.altKey && event.code === 'KeyP') { event.preventDefault(); currentProduct() && setProduct(state.currentProductId, true); }
    else if (event.altKey && event.code === 'KeyN') { event.preventDefault(); nextProduct(); }
    else if (event.altKey && event.code === 'KeyR') { event.preventDefault(); open('rundown'); }
    else if (event.altKey && event.code === 'KeyM') { event.preventDefault(); state.settings.moderatorMode = !state.settings.moderatorMode; applyMode(); save(true); open(state.settings.moderatorMode ? 'comments' : 'now'); }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'LIVEOS_CC_OPEN') {
      const requestedTab = ['now', 'comments', 'ai', 'telegram', 'products', 'rundown', 'metrics', 'safety', 'settings'].includes(message.tab) ? message.tab : activeTab;
      open(requestedTab);
      return Promise.resolve({ ok: true, version: PANEL_VERSION });
    }
    if (message?.type === 'STATE_UPDATED' && message.state) hostState = { ...hostState, ...message.state };
    if (message?.type === 'LIVEOS_STREAM_SYNC') {
      window.postMessage({
        source: 'LIVEWELPRO_EXTENSION',
        type: 'SYNC_PLAYER_FULL_STATE',
        ...message
      }, '*');
    }
    if (message?.type === 'LIVEOS_TRANSMIT_VIDEO_BUFFER' && message.buffer) {
      try {
        const blob = new Blob([message.buffer], { type: message.mimeType || 'video/mp4' });
        const localUrl = URL.createObjectURL(blob);
        window.postMessage({
          source: 'LIVEWELPRO_EXTENSION',
          type: 'SET_VIDEO_SRC',
          blobUrl: localUrl
        }, '*');
      } catch (e) {}
    }
    if (message?.type === 'LIVEOS_TRANSMIT_GHOST_BUFFER' && message.buffer) {
      try {
        const blob = new Blob([message.buffer], { type: message.mimeType || 'video/mp4' });
        const localUrl = URL.createObjectURL(blob);
        window.postMessage({
          source: 'LIVEWELPRO_EXTENSION',
          type: 'SET_GHOST_SRC',
          blobUrl: localUrl
        }, '*');
      } catch (e) {}
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes['liveos_player_sync']?.newValue) {
      window.postMessage({
        source: 'LIVEWELPRO_EXTENSION',
        type: 'SYNC_PLAYER_FULL_STATE',
        ...changes['liveos_player_sync'].newValue
      }, '*');
    }
    if (!changes[STORAGE_KEY]?.newValue) return;
    const incoming = changes[STORAGE_KEY].newValue;
    const incomingJson = JSON.stringify(incoming);
    if (localStateWrites.has(incomingJson)) { localStateWrites.delete(incomingJson); return; }
    state = merge(structuredClone(DEFAULTS), incoming);
    applyMode();
    scheduleEngagementReminder(true);
    renderAll();
  });
  document.addEventListener('keydown', onKey, true);
  document.addEventListener('pointerdown', onHostPointerDown, true);
  document.addEventListener('pointerup', onHostPointerUp, true);
  const observer = new MutationObserver(() => { lastDomActivity = Date.now(); attachToFullPanel(); clearTimeout(scanTimer); scanTimer = setTimeout(scanComments, 900); });

  (async () => {
    await load(); await Promise.all([loadAiConfig(), loadTelegramConfig()]); build();
    observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    scanComments(); restartHealth(); readHostState();
    scheduleEngagementReminder(true);
    tickTimer = setInterval(() => { updateHeader(); tickEngagementReminder(); if (activeTab === 'now' && !panel.hidden) render('now'); }, 1000);
    setInterval(ensureHostStability, 120);
    setInterval(readHostState, 5000);
  })();
})();
