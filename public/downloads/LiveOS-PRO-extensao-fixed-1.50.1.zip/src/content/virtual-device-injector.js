/**
 * LiveWelPro — Injetor de Câmera e Microfone Virtual no TikTok Shop Streamer
 * Executado no contexto principal (MAIN world) da página do TikTok.
 * Conecta em tempo real o Player, Overlays Customizáveis, Camada Ghost e Áudio Picotado Ultra-Rápido.
 */
(() => {
  if (globalThis.__LIVEWELPRO_VIRTUAL_DEVICE_INJECTED__) return;
  globalThis.__LIVEWELPRO_VIRTUAL_DEVICE_INJECTED__ = true;

  const VIRTUAL_CAMERA_ID = 'livewelpro-camera-source';
  const VIRTUAL_MIC_ID = 'livewelpro-mic-source';
  const VIRTUAL_GROUP_ID = 'livewelpro-group-media';

  const VIRTUAL_CAMERA_LABEL = 'LiveWelPro - Câmera Virtual (Player & Overlays)';
  const VIRTUAL_MIC_LABEL = 'LiveWelPro - Microfone Virtual (Áudio Picotado)';

  // Elementos de mídia internos
  const internalVideo = document.createElement('video');
  internalVideo.id = 'livewelpro-video-player';
  internalVideo.muted = true;
  internalVideo.loop = true;
  internalVideo.playsInline = true;
  internalVideo.crossOrigin = 'anonymous';
  internalVideo.style.display = 'none';
  document.documentElement.appendChild(internalVideo);

  // Vídeo secundário por cima (Ghost Layer)
  const ghostVideo = document.createElement('video');
  ghostVideo.id = 'livewelpro-ghost-video-player';
  ghostVideo.muted = true;
  ghostVideo.loop = true;
  ghostVideo.playsInline = true;
  ghostVideo.crossOrigin = 'anonymous';
  ghostVideo.style.display = 'none';
  document.documentElement.appendChild(ghostVideo);

  const internalAudio = document.createElement('audio');
  internalAudio.id = 'livewelpro-audio-player';
  internalAudio.playsInline = true;
  internalAudio.crossOrigin = 'anonymous';
  internalAudio.style.display = 'none';
  document.documentElement.appendChild(internalAudio);

  // Canvas virtual para stream da câmera
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1920;
  const ctx = canvas.getContext('2d');

  let videoStream = null;
  let audioStream = null;
  let audioCtx = null;
  let audioDest = null;
  let audioSourceNode = null;

  // Estado dos Overlays Sincronizados com o Player
  let timerSeconds = 300;
  let timerMax = 300;
  let timerTitle = '⚡ OFERTA RELÂMPAGO ENCERRA EM:';
  let timerEnabled = true;

  let bannerIndex = 0;
  let bannerEnabled = true;
  let banners = [
    { title: '🔥 OFERTA RELÂMPAGO', sub: 'Desconto exclusivo somente durante a live!' },
    { title: '🚚 FRETE GRÁTIS HOJE', sub: 'Envio prioritário para todo o Brasil' },
    { title: '🛡️ GARANTIA BLINDADA', sub: 'Satisfação garantida ou seu dinheiro de volta' },
    { title: '🎟️ CUPOM EXCLUSIVO', sub: 'Resgate o voucher no carrinho agora' }
  ];

  let ghostOpacity = 0.15;
  let ghostBlend = 'screen';
  let hasGhostVideo = false;

  let ghostBarEnabled = true;
  let ghostBarOpacity = 0.04;
  let ghostBarSpeed = 3;

  let emojisEnabled = true;

  // Emojis flutuantes
  const emojis = ['❤️', '🔥', '🛍️', '⭐', '👏', '💖', '🚀', '💯'];
  const particles = [];
  for (let i = 0; i < 18; i++) {
    particles.push({
      x: 100 + Math.random() * (canvas.width - 200),
      y: canvas.height + Math.random() * 300,
      char: emojis[Math.floor(Math.random() * emojis.length)],
      speed: 1.5 + Math.random() * 2.5,
      size: 28 + Math.random() * 20
    });
  }

  // Timer interval
  setInterval(() => {
    if (timerEnabled) {
      timerSeconds--;
      if (timerSeconds < 0) timerSeconds = timerMax;
    }
  }, 1000);

  // Banner interval
  setInterval(() => {
    if (bannerEnabled && banners.length > 0) {
      bannerIndex = (bannerIndex + 1) % banners.length;
    }
  }, 7500);

  // Render loop do vídeo virtual (60 FPS)
  let tick = 0;
  function renderVirtualCamera() {
    tick++;
    const hasMainVideo = internalVideo.readyState >= 2 && !internalVideo.paused && internalVideo.videoWidth > 0;

    if (hasMainVideo) {
      try {
        ctx.globalAlpha = 1.0;
        ctx.globalCompositeOperation = 'source-over';
        ctx.drawImage(internalVideo, 0, 0, canvas.width, canvas.height);
      } catch (e) {}

      // 1. Camada de Vídeo por Cima (Ghost Video Overlay)
      if (hasGhostVideo && ghostVideo.readyState >= 2 && !ghostVideo.paused) {
        try {
          ctx.save();
          ctx.globalAlpha = ghostOpacity;
          ctx.globalCompositeOperation = ghostBlend || 'screen';
          ctx.drawImage(ghostVideo, 0, 0, canvas.width, canvas.height);
          ctx.restore();
        } catch (e) {}
      }

      ctx.globalAlpha = 1.0;
      ctx.globalCompositeOperation = 'source-over';

      // 2. Badge LIVE
      ctx.fillStyle = 'rgba(239, 68, 68, 0.9)';
      ctx.beginPath();
      ctx.roundRect(40, 60, 140, 48, 24);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 20px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔴 AO VIVO', 110, 92);

      // 3. Cronômetro de Urgência
      if (timerEnabled) {
        const m = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
        const s = String(timerSeconds % 60).padStart(2, '0');
        const timeStr = `${m}:${s}`;

        ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        ctx.strokeStyle = '#2dd4bf';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.roundRect(canvas.width / 2 - 240, 130, 480, 88, 20);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 15px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(timerTitle, canvas.width / 2, 160);

        ctx.fillStyle = '#2dd4bf';
        ctx.font = 'bold 36px monospace';
        ctx.fillText(timeStr, canvas.width / 2, 200);
      }

      // 4. Banners Rotativos
      if (bannerEnabled && banners.length > 0) {
        const currentBanner = banners[bannerIndex] || banners[0];
        ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(60, canvas.height - 240, canvas.width - 120, 110, 18);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#fbbf24';
        ctx.font = 'bold 22px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(currentBanner.title, 90, canvas.height - 195);

        ctx.fillStyle = '#e2e8f0';
        ctx.font = '16px sans-serif';
        ctx.fillText(currentBanner.sub, 90, canvas.height - 160);
      }

      // 5. Emojis Flutuantes
      if (emojisEnabled) {
        for (const p of particles) {
          p.y -= p.speed;
          p.x += Math.sin(tick * 0.05 + p.speed) * 1.2;
          if (p.y < 300) {
            p.y = canvas.height + 50;
            p.x = 100 + Math.random() * (canvas.width - 200);
          }
          ctx.font = `${p.size}px sans-serif`;
          ctx.fillText(p.char, p.x, p.y);
        }
      }

      // 6. Barra de Interferência VHS / Scanline
      if (ghostBarEnabled) {
        const spd = Math.max(1, ghostBarSpeed);
        const ghostY = (tick * spd * 1.5) % canvas.height;
        const scanGrad = ctx.createLinearGradient(0, ghostY - 35, 0, ghostY + 35);
        scanGrad.addColorStop(0, `rgba(45, 212, 191, 0)`);
        scanGrad.addColorStop(0.5, `rgba(45, 212, 191, ${ghostBarOpacity * 1.5})`);
        scanGrad.addColorStop(1, `rgba(45, 212, 191, 0)`);
        ctx.fillStyle = scanGrad;
        ctx.fillRect(0, ghostY - 35, canvas.width, 70);
      }

      // 7. Camada Anti-Hash Sub-pixel
      ctx.fillStyle = 'rgba(255, 255, 255, 0.025)';
      for (let i = 0; i < 40; i++) {
        const rx = Math.random() * canvas.width;
        const ry = Math.random() * canvas.height;
        ctx.fillRect(rx, ry, 3, 3);
      }

    } else {
      // Tela de espera quando o player está sem vídeo
      const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      grad.addColorStop(0, '#0b0f14');
      grad.addColorStop(1, '#1e293b');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#2dd4bf';
      ctx.font = 'bold 54px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('LiveWelPro', canvas.width / 2, canvas.height / 2 - 40);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '30px sans-serif';
      ctx.fillText('Câmera Virtual Conectada', canvas.width / 2, canvas.height / 2 + 30);

      ctx.fillStyle = '#f59e0b';
      ctx.font = '22px sans-serif';
      ctx.fillText('Abra o Player no painel para reproduzir os vídeos', canvas.width / 2, canvas.height / 2 + 80);

      const pulse = Math.sin(tick * 0.05) * 8;
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2 - 120, 16 + pulse, 0, Math.PI * 2);
      ctx.fill();
    }

    requestAnimationFrame(renderVirtualCamera);
  }
  requestAnimationFrame(renderVirtualCamera);

  function getOrCreateVirtualVideoStream() {
    if (!videoStream || !videoStream.active) {
      videoStream = canvas.captureStream(30);
    }
    return videoStream;
  }

  function getOrCreateVirtualAudioStream() {
    if (!audioStream || !audioStream.active) {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        audioDest = audioCtx.createMediaStreamDestination();

        if (!audioSourceNode && internalAudio) {
          try {
            audioSourceNode = audioCtx.createMediaElementSource(internalAudio);
            audioSourceNode.connect(audioDest);
          } catch (e) {}
        }

        // Ruído ultra-baixo inaudível para manter conexão WebRTC sempre ativa
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        gain.gain.value = 0.0001;
        osc.connect(gain);
        gain.connect(audioDest);
        osc.start();

        audioStream = audioDest.stream;
      } catch (e) {
        audioStream = null;
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioStream;
  }

  // Listener para sincronização total com o Player e Áudio
  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.source !== 'LIVEWELPRO_EXTENSION') return;

    // Sincronização de Vídeo Principal
    if (data.type === 'SET_VIDEO_SRC' && data.blobUrl) {
      internalVideo.src = data.blobUrl;
      internalVideo.play().catch(() => {});
    }

    // Sincronização de Vídeo Sobreposto (Ghost Layer)
    if (data.type === 'SET_GHOST_SRC' && data.blobUrl) {
      hasGhostVideo = true;
      ghostVideo.src = data.blobUrl;
      ghostVideo.play().catch(() => {});
    }

    // Sincronização Completa do Player & Overlays
    if (data.type === 'SYNC_PLAYER_FULL_STATE') {
      if (data.currentSrc && internalVideo.src !== data.currentSrc) {
        internalVideo.src = data.currentSrc;
        internalVideo.play().catch(() => {});
      }

      if (data.ghostSrc) {
        hasGhostVideo = true;
        if (ghostVideo.src !== data.ghostSrc) {
          ghostVideo.src = data.ghostSrc;
          ghostVideo.play().catch(() => {});
        }
      } else {
        hasGhostVideo = false;
      }

      if (typeof data.ghostOpacity === 'number') ghostOpacity = data.ghostOpacity;
      if (data.ghostBlend) ghostBlend = data.ghostBlend;

      if (data.timerTitle) timerTitle = data.timerTitle;
      if (typeof data.timerDuration === 'number') {
        timerMax = data.timerDuration;
        timerSeconds = timerMax;
      }
      if (typeof data.timerEnabled === 'boolean') timerEnabled = data.timerEnabled;

      if (typeof data.bannerEnabled === 'boolean') bannerEnabled = data.bannerEnabled;
      if (data.bannersText) {
        const lines = String(data.bannersText).split('\n').filter(l => l.trim().length > 0);
        if (lines.length) {
          banners = lines.map(l => {
            const parts = l.split('|');
            return {
              title: parts[0]?.trim() || '🔥 OFERTA',
              sub: parts[1]?.trim() || 'Desconto exclusivo na live!'
            };
          });
        }
      }

      if (typeof data.ghostBarOpacity === 'number') ghostBarOpacity = data.ghostBarOpacity;
      if (typeof data.ghostBarSpeed === 'number') ghostBarSpeed = data.ghostBarSpeed;
      if (typeof data.ghostBarEnabled === 'boolean') ghostBarEnabled = data.ghostBarEnabled;

      if (typeof data.emojisEnabled === 'boolean') emojisEnabled = data.emojisEnabled;
    }

    // Áudio Ultra-Rápido
    if (data.type === 'SET_AUDIO_SRC' && data.blobUrl) {
      if (internalAudio.src !== data.blobUrl) {
        internalAudio.src = data.blobUrl;
      }
      if (typeof data.currentTime === 'number') {
        try { internalAudio.currentTime = data.currentTime; } catch (e) {}
      }
      internalAudio.play().catch(() => {});
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    }

    if (data.type === 'AUDIO_FAST_JUMP') {
      if (typeof data.currentTime === 'number') {
        try { internalAudio.currentTime = data.currentTime; } catch (e) {}
      }
      internalAudio.play().catch(() => {});
    }

    if (data.type === 'AUDIO_PLAY') {
      internalAudio.play().catch(() => {});
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    }

    if (data.type === 'AUDIO_PAUSE') {
      internalAudio.pause();
    }

    if (data.type === 'RESET_TIMER') {
      timerSeconds = timerMax;
    }
  });

  // Intercepta navigator.mediaDevices
  function createVirtualDevice(id, kind, label) {
    return {
      deviceId: id,
      kind: kind,
      label: label,
      groupId: VIRTUAL_GROUP_ID,
      toJSON: function () {
        return {
          deviceId: this.deviceId,
          kind: this.kind,
          label: this.label,
          groupId: this.groupId
        };
      }
    };
  }

  if (navigator.mediaDevices) {
    const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
    const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);

    navigator.mediaDevices.enumerateDevices = async function () {
      let devices = [];
      try {
        devices = await originalEnumerateDevices();
      } catch (e) {
        devices = [];
      }

      const virtualCam = createVirtualDevice(VIRTUAL_CAMERA_ID, 'videoinput', VIRTUAL_CAMERA_LABEL);
      const virtualMic = createVirtualDevice(VIRTUAL_MIC_ID, 'audioinput', VIRTUAL_MIC_LABEL);

      return [virtualCam, virtualMic, ...devices.filter(d => d.deviceId !== VIRTUAL_CAMERA_ID && d.deviceId !== VIRTUAL_MIC_ID)];
    };

    navigator.mediaDevices.getUserMedia = async function (constraints = {}) {
      const videoConstraint = constraints.video;
      const audioConstraint = constraints.audio;

      const wantsVirtualCamera = videoConstraint && (
        videoConstraint === true ||
        (typeof videoConstraint === 'object' && (
          videoConstraint.deviceId === VIRTUAL_CAMERA_ID ||
          videoConstraint.deviceId?.exact === VIRTUAL_CAMERA_ID ||
          videoConstraint.deviceId?.ideal === VIRTUAL_CAMERA_ID ||
          String(videoConstraint.deviceId).includes('livewelpro')
        ))
      );

      const wantsVirtualMic = audioConstraint && (
        (typeof audioConstraint === 'object' && (
          audioConstraint.deviceId === VIRTUAL_MIC_ID ||
          audioConstraint.deviceId?.exact === VIRTUAL_MIC_ID ||
          audioConstraint.deviceId?.ideal === VIRTUAL_MIC_ID ||
          String(audioConstraint.deviceId).includes('livewelpro')
        ))
      );

      if (wantsVirtualCamera || wantsVirtualMic) {
        const tracks = [];

        if (videoConstraint) {
          const vStream = getOrCreateVirtualVideoStream();
          if (vStream) {
            const vTrack = vStream.getVideoTracks()[0];
            if (vTrack) tracks.push(vTrack.clone());
          }
        }

        if (audioConstraint) {
          if (wantsVirtualMic) {
            const aStream = getOrCreateVirtualAudioStream();
            if (aStream) {
              const aTrack = aStream.getAudioTracks()[0];
              if (aTrack) tracks.push(aTrack.clone());
            }
          } else {
            try {
              const realAudio = await originalGetUserMedia({ audio: audioConstraint, video: false });
              const aTrack = realAudio.getAudioTracks()[0];
              if (aTrack) tracks.push(aTrack);
            } catch (e) {}
          }
        }

        if (tracks.length > 0) {
          return new MediaStream(tracks);
        }
      }

      return originalGetUserMedia(constraints);
    };
  }

  console.log('✅ [LiveWelPro] Câmera Virtual e Microfone Virtual sincronizados em tempo real!');
})();
