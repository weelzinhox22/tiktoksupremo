(() => {
  if (globalThis.__LIVEWEL_CAMERA_BRIDGE__) return;
  globalThis.__LIVEWEL_CAMERA_BRIDGE__ = true;

  const receiverId = `cam_${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2)}`;
  let canvas;
  let ctx;
  let decoding = false;
  let pendingFrame = null;
  let lastPaintedAt = 0;
  let lastSequence = 0;
  let rtcPort = null;
  let rtcPeer = null;
  let rtcReconnectTimer = 0;
  let remoteVideo = null;
  let remoteActive = false;
  let lastRtcFrameAt = 0;
  let pendingIceCandidates = [];
  let lastRtcStatus = '';
  let rtcRenderRunning = false;
  let audioReceiverActive = false;

  function drawWaitingSurface() {
    if (!ctx || !canvas) return;
    ctx.fillStyle = '#05070a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#e5edf5';
    ctx.font = '600 25px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText('LiveWelPro conectado', canvas.width / 2, canvas.height / 2 - 16);
    ctx.fillStyle = '#8da0b3';
    ctx.font = '18px system-ui';
    ctx.fillText('Abra o Player e pressione Play', canvas.width / 2, canvas.height / 2 + 22);
  }

  function ensureCanvas() {
    if (canvas?.isConnected) return canvas;
    const mount = document.body || document.documentElement;
    if (!mount) return null;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'livewel-virtual-camera-surface';
      canvas.width = 720;
      canvas.height = 1280;
      canvas.setAttribute('aria-hidden', 'true');
      canvas.style.cssText = 'position:fixed;width:1px;height:1px;left:-10000px;top:-10000px;pointer-events:none;opacity:.001';
      ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
      drawWaitingSurface();
    }
    mount.appendChild(canvas);
    window.dispatchEvent(new CustomEvent('livewel-surface-ready'));
    return canvas;
  }

  function ensureRemoteVideo() {
    if (remoteVideo?.isConnected) return remoteVideo;
    const mount = document.body || document.documentElement;
    if (!mount) return null;
    if (!remoteVideo) {
      remoteVideo = document.createElement('video');
      remoteVideo.id = 'livewel-webrtc-video';
      remoteVideo.autoplay = true;
      remoteVideo.muted = true;
      remoteVideo.playsInline = true;
      remoteVideo.setAttribute('aria-hidden', 'true');
      remoteVideo.style.cssText = 'position:fixed;width:1px;height:1px;left:-10000px;top:-10000px;pointer-events:none;opacity:.001';
    }
    mount.appendChild(remoteVideo);
    return remoteVideo;
  }

  function portMessage(message) {
    try {
      rtcPort?.postMessage({ ...message, receiverId });
      return true;
    } catch {
      return false;
    }
  }

  function reportRtcStatus(status) {
    if (status === lastRtcStatus) return;
    lastRtcStatus = status;
    portMessage({ type: 'receiver-status', status });
  }

  function drawRemoteFrame() {
    if (!remoteActive || !remoteVideo) {
      rtcRenderRunning = false;
      return;
    }
    rtcRenderRunning = true;
    if (remoteVideo.readyState >= 2 && remoteVideo.videoWidth > 0 && ensureCanvas()) {
      try {
        if (canvas.width !== remoteVideo.videoWidth || canvas.height !== remoteVideo.videoHeight) {
          canvas.width = remoteVideo.videoWidth;
          canvas.height = remoteVideo.videoHeight;
          ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
        }
        ctx.drawImage(remoteVideo, 0, 0, canvas.width, canvas.height);
        lastRtcFrameAt = Date.now();
        lastPaintedAt = lastRtcFrameAt;
        reportRtcStatus('connected');
        window.dispatchEvent(new CustomEvent('livewel-camera-frame', {
          detail: { paintedAt: lastPaintedAt, transport: 'webrtc' }
        }));
      } catch {}
    }
    if (remoteActive) {
      if (typeof remoteVideo.requestVideoFrameCallback === 'function') {
        remoteVideo.requestVideoFrameCallback(drawRemoteFrame);
      } else {
        requestAnimationFrame(drawRemoteFrame);
      }
    }
  }

  function startRemoteRenderer() {
    if (rtcRenderRunning || !remoteActive || !remoteVideo) return;
    drawRemoteFrame();
  }

  function closeRtcPeer(status = 'disconnected') {
    remoteActive = false;
    rtcRenderRunning = false;
    try { rtcPeer?.close(); } catch {}
    rtcPeer = null;
    pendingIceCandidates = [];
    if (remoteVideo) {
      try { remoteVideo.pause(); } catch {}
      remoteVideo.srcObject = null;
    }
    reportRtcStatus(status);
  }

  function newRtcPeer() {
    const queuedCandidates = pendingIceCandidates;
    closeRtcPeer('connecting');
    pendingIceCandidates = queuedCandidates;
    const peer = new RTCPeerConnection({ iceServers: [] });
    rtcPeer = peer;
    peer.onicecandidate = (event) => {
      if (event.candidate) {
        portMessage({ type: 'signal', signal: { candidate: event.candidate.toJSON() } });
      }
    };
    peer.ontrack = (event) => {
      const video = ensureRemoteVideo();
      if (!video) return;
      video.srcObject = event.streams[0] || new MediaStream([event.track]);
      remoteActive = true;
      video.play().then(startRemoteRenderer).catch(() => {
        remoteActive = false;
        reportRtcStatus('play-blocked');
      });
    };
    peer.onconnectionstatechange = () => {
      if (rtcPeer !== peer) return;
      const status = peer.connectionState;
      if (status === 'connected') {
        remoteActive = Boolean(remoteVideo?.srcObject);
        startRemoteRenderer();
        reportRtcStatus('connected');
      }
      else if (status === 'failed' || status === 'closed') closeRtcPeer(status);
      else if (status === 'disconnected') {
        remoteActive = false;
        reportRtcStatus(status);
      }
    };
    return peer;
  }

  async function handleRtcSignal(signal) {
    if (!signal || typeof RTCPeerConnection === 'undefined') return;
    if (signal.description?.type === 'offer') {
      const peer = newRtcPeer();
      await peer.setRemoteDescription(signal.description);
      for (const candidate of pendingIceCandidates.splice(0)) {
        await peer.addIceCandidate(candidate).catch(() => {});
      }
      const answer = await peer.createAnswer();
      await peer.setLocalDescription(answer);
      portMessage({
        type: 'signal',
        signal: { description: { type: peer.localDescription.type, sdp: peer.localDescription.sdp } }
      });
      return;
    }
    if (signal.candidate) {
      if (rtcPeer?.remoteDescription) await rtcPeer.addIceCandidate(signal.candidate).catch(() => {});
      else pendingIceCandidates.push(signal.candidate);
    }
  }

  function connectRtcTransport() {
    if (typeof RTCPeerConnection === 'undefined' || rtcPort) return;
    clearTimeout(rtcReconnectTimer);
    try {
      const port = chrome.runtime.connect({ name: 'LIVEWEL_CAMERA_RTC' });
      rtcPort = port;
      port.onMessage.addListener((message) => {
        if (message?.type === 'signal') handleRtcSignal(message.signal).catch(() => closeRtcPeer('failed'));
        if (message?.type === 'producer-offline') closeRtcPeer('producer-offline');
      });
      port.onDisconnect.addListener(() => {
        if (rtcPort === port) rtcPort = null;
        closeRtcPeer('relay-offline');
        rtcReconnectTimer = setTimeout(connectRtcTransport, 1000);
      });
      portMessage({ type: 'receiver-ready' });
    } catch {
      rtcPort = null;
      rtcReconnectTimer = setTimeout(connectRtcTransport, 1500);
    }
  }

  function frameBlob(dataUrl) {
    const separator = dataUrl.indexOf(',');
    if (separator < 0) throw new Error('Quadro de vídeo inválido.');
    const header = dataUrl.slice(0, separator);
    const mime = /^data:([^;,]+)/i.exec(header)?.[1] || 'image/webp';
    const body = dataUrl.slice(separator + 1);
    if (!/;base64/i.test(header)) return new Blob([decodeURIComponent(body)], { type: mime });
    const binary = atob(body);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return new Blob([bytes], { type: mime });
  }

  async function paint(frame, sequence = 0) {
    if (remoteActive && Date.now() - lastRtcFrameAt < 2500) {
      return { ok: true, transport: 'webrtc', paintedAt: lastRtcFrameAt, sequence: lastSequence };
    }
    if (decoding) {
      pendingFrame = { frame, sequence };
      return { ok: true, queued: true, paintedAt: lastPaintedAt, sequence: lastSequence };
    }
    decoding = true;
    try {
      if (!ensureCanvas()) throw new Error('Canvas da câmera ainda não está disponível.');
      const bitmap = await createImageBitmap(frameBlob(frame));
      if (canvas.width !== bitmap.width || canvas.height !== bitmap.height) {
        canvas.width = bitmap.width;
        canvas.height = bitmap.height;
        ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
      }
      ctx.drawImage(bitmap, 0, 0);
      bitmap.close();
      lastPaintedAt = Date.now();
      lastSequence = Number(sequence || lastSequence + 1);
      window.dispatchEvent(new CustomEvent('livewel-camera-frame', {
        detail: { paintedAt: lastPaintedAt, sequence: lastSequence, transport: 'frames' }
      }));
      return { ok: true, transport: 'frames', paintedAt: lastPaintedAt, sequence: lastSequence };
    } catch (error) {
      console.warn('[LiveWelPro] não foi possível pintar o quadro da câmera', error);
      return {
        ok: false,
        error: String(error?.message || error),
        paintedAt: lastPaintedAt,
        sequence: lastSequence
      };
    } finally {
      decoding = false;
      if (pendingFrame) {
        const next = pendingFrame;
        pendingFrame = null;
        queueMicrotask(() => paint(next.frame, next.sequence));
      }
    }
  }

  function mainWorldTargetOrigin() {
    return /^https?:$/i.test(location.protocol) ? location.origin : '*';
  }

  function postAudioToMainWorld(message) {
    window.postMessage({ source: 'livewel-extension', ...message }, mainWorldTargetOrigin());
  }

  function announceAudioReceiver(restore = false) {
    if (!audioReceiverActive) return;
    chrome.runtime.sendMessage({ type: 'LIVEWEL_AUDIO_BRIDGE_READY', restore })
      .then((response) => {
        if (!restore) return;
        for (const message of response?.messages || []) postAudioToMainWorld(message);
      })
      .catch(() => {});
  }

  function activateAudioReceiver() {
    if (audioReceiverActive) return;
    audioReceiverActive = true;
    announceAudioReceiver(true);
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'LIVEWEL_AUDIO_REGISTER_SOURCE' && typeof message.dataUrl === 'string') {
      if (audioReceiverActive) postAudioToMainWorld(message);
      sendResponse({ ok: true });
      return;
    }
    if (/^LIVEWEL_AUDIO_SOURCE_(BEGIN|CHUNK|END)$/.test(String(message?.type || ''))) {
      if (audioReceiverActive) postAudioToMainWorld(message);
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'LIVEWEL_AUDIO_SOURCE' && message.id) {
      if (audioReceiverActive) postAudioToMainWorld(message);
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'LIVEWEL_AUDIO_CONTROL' || message?.type === 'LIVEWEL_AUDIO_CONFIG') {
      if (audioReceiverActive) postAudioToMainWorld(message);
      sendResponse({ ok: true });
      return;
    }
    if (message?.type !== 'LIVEWEL_CAMERA_FRAME' || typeof message.frame !== 'string') return;
    paint(message.frame, message.sequence)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  });

  function announceReady(videoRequested = false) {
    chrome.runtime.sendMessage({
      type: 'LIVEWEL_CAMERA_BRIDGE_READY',
      href: location.href,
      topFrame: window === top,
      videoRequested
    }).then((response) => {
      if (response?.frame) return paint(response.frame, response.sequence);
    }).catch(() => {});
  }

  function activateVideoReceiver() {
    announceReady(true);
    connectRtcTransport();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      ensureCanvas();
      ensureRemoteVideo();
    }, { once: true });
  } else {
    ensureCanvas();
    ensureRemoteVideo();
  }
  window.addEventListener('livewel-virtual-video-requested', activateVideoReceiver);
  window.addEventListener('livewel-virtual-audio-requested', activateAudioReceiver);
  if (globalThis.__LIVEWEL_VIRTUAL_VIDEO_REQUESTED_AT__) activateVideoReceiver();
  if (globalThis.__LIVEWEL_VIRTUAL_AUDIO_REQUESTED_AT__) activateAudioReceiver();
  setInterval(() => announceAudioReceiver(false), 5000);
  announceReady();
})();
