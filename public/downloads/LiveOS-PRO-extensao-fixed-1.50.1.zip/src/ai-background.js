const AI_SECRET_KEY = 'liveosAiSecretsV1';
const AI_DEFAULTS = {
  provider: 'groq',
  geminiModel: 'gemini-3.6-flash',
  groqModel: 'openai/gpt-oss-20b',
  groqKey: '',
  geminiKey: ''
};

async function readAiConfig() {
  const stored = await chrome.storage.local.get(AI_SECRET_KEY);
  const config = { ...AI_DEFAULTS, ...(stored[AI_SECRET_KEY] || {}) };
  let migrated = false;
  if (config.geminiModel === 'gemini-2.5-flash') { config.geminiModel = AI_DEFAULTS.geminiModel; migrated = true; }
  if (config.groqModel === 'llama-3.1-8b-instant') { config.groqModel = AI_DEFAULTS.groqModel; migrated = true; }
  if (migrated) await chrome.storage.local.set({ [AI_SECRET_KEY]: config });
  return config;
}

async function publicAiConfig() {
  const config = await readAiConfig();
  return {
    provider: config.provider,
    geminiModel: config.geminiModel,
    groqModel: config.groqModel,
    hasGemini: Boolean(config.geminiKey),
    hasGroq: Boolean(config.groqKey),
    savedAt: Number(config.savedAt) || null,
    persistent: true
  };
}

async function saveAiConfig(input = {}) {
  const current = await readAiConfig();
  const next = {
    ...current,
    provider: input.provider === 'gemini' ? 'gemini' : 'groq',
    geminiModel: String(input.geminiModel || current.geminiModel).trim(),
    groqModel: String(input.groqModel || current.groqModel).trim(),
    savedAt: Date.now()
  };
  if (String(input.geminiKey || '').trim()) next.geminiKey = String(input.geminiKey).trim();
  if (String(input.groqKey || '').trim()) next.groqKey = String(input.groqKey).trim();
  if (input.clearGemini) next.geminiKey = '';
  if (input.clearGroq) next.groqKey = '';
  await chrome.storage.local.set({ [AI_SECRET_KEY]: next });
  return publicAiConfig();
}

const SYSTEM_PROMPT = `Você é um copiloto de vendas para uma LIVE do TikTok Shop em português do Brasil.
Crie textos naturais, curtos e fáceis de falar ao vivo. Nunca invente preço, estoque, frete,
garantia, eficácia ou característica que não esteja no contexto. Nunca direcione compra para
WhatsApp, Pix, direct, link externo ou outra loja. Não faça promessa de cura ou resultado garantido.
Quando faltar informação, escreva [CONFIRMAR]. A pessoa apresentadora sempre revisará a resposta.`;

async function callGemini(config, prompt) {
  if (!config.geminiKey) throw new Error('Configure uma chave nova do Gemini.');
  const model = encodeURIComponent(config.geminiModel || AI_DEFAULTS.geminiModel);
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': config.geminiKey },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: `${SYSTEM_PROMPT}\n\nPEDIDO:\n${prompt}` }] }],
      generationConfig: { maxOutputTokens: 700 }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error?.message || `Gemini respondeu HTTP ${response.status}.`);
  const text = (data.candidates?.[0]?.content?.parts || []).map((part) => part.text || '').join('').trim();
  if (!text) throw new Error('O Gemini não devolveu texto.');
  return text;
}

async function callGroq(config, prompt) {
  if (!config.groqKey) throw new Error('Configure uma chave nova do Groq.');
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.groqKey}` },
    body: JSON.stringify({
      model: config.groqModel || AI_DEFAULTS.groqModel,
      messages: [{ role: 'system', content: SYSTEM_PROMPT }, { role: 'user', content: prompt }],
      max_completion_tokens: 700
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error?.message || `Groq respondeu HTTP ${response.status}.`);
  const text = String(data.choices?.[0]?.message?.content || '').trim();
  if (!text) throw new Error('O Groq não devolveu texto.');
  return text;
}

async function handleAiMessage(message) {
    if (message.type === 'LIVEOS_AI_GET_CONFIG') return { ok: true, config: await publicAiConfig() };
    if (message.type === 'LIVEOS_AI_SAVE_CONFIG') return { ok: true, config: await saveAiConfig(message.config) };
    if (message.type === 'LIVEOS_AI_GENERATE') {
      const config = await readAiConfig();
      const prompt = String(message.prompt || '').slice(0, 12000);
      if (!prompt.trim()) throw new Error('Escreva um pedido para a IA.');
      const provider = message.provider === 'gemini' || message.provider === 'groq' ? message.provider : config.provider;
      const text = provider === 'gemini' ? await callGemini(config, prompt) : await callGroq(config, prompt);
      return { ok: true, provider, text };
    }
    return { ok: false, error: 'Ação de IA desconhecida.' };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!String(message?.type || '').startsWith('LIVEOS_AI_')) return false;
  handleAiMessage(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'liveos-pro-rpc') return;
  port.onMessage.addListener((message) => {
    if (!String(message?.type || '').startsWith('LIVEOS_AI_')) return;
    handleAiMessage(message)
      .then((response) => port.postMessage({ requestId: message.requestId, ...response }))
      .catch((error) => port.postMessage({ requestId: message.requestId, ok: false, error: String(error?.message || error) }));
  });
});
