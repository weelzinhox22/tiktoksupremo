const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');

function source(relativePath) {
  return fs.readFileSync(path.join(ROOT, relativePath), 'utf8');
}

function dispatch(listener, message, sender = {}) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timeout aguardando resposta para ${message.type}`)), 1500);
    const sendResponse = (response) => {
      clearTimeout(timer);
      resolve(response);
    };
    const keepPort = listener(message, sender, sendResponse);
    if (keepPort !== true && message.type !== 'LIVEWEL_CAMERA_BRIDGE_READY' && message.type !== 'LIVEWEL_PLAYER_STATUS') {
      queueMicrotask(() => {
        clearTimeout(timer);
        resolve(undefined);
      });
    }
  });
}

test('manifest injeta câmera e bridge em todos os frames do TikTok', () => {
  const manifest = JSON.parse(source('manifest.json'));
  assert.equal(manifest.version, '1.50.1');
  for (const entry of manifest.content_scripts.slice(0, 2)) {
    assert.equal(entry.run_at, 'document_start');
    assert.equal(entry.all_frames, true);
    assert.equal(entry.match_origin_as_fallback, true);
  }
  assert.equal(manifest.content_scripts[0].world, 'MAIN');
  const scripts = manifest.content_scripts.flatMap((entry) => entry.js || []);
  assert.ok(scripts.includes('src/content/comment-publisher.js'));
  assert.ok(scripts.includes('src/content/automation-runtime.js'));
  assert.match(source('player/player.html'), /capture-settings\.js/);
  assert.match(source('player/capture-settings.js'), /captureProfile === 'low' \? 540 : 720/);
  assert.match(source('player/capture-settings.js'), /outputFps: 30/);
});

test('publicador de comentários usa o setter do elemento real e confirma o envio', () => {
  const publisher = source('src/content/comment-publisher.js');
  const bridge = source('src/content/dashboard-bridge.js');
  const commandCenter = source('src/content/command-center.js');
  assert.match(publisher, /Object\.getPrototypeOf\(element\)/);
  assert.match(publisher, /O TikTok não confirmou o envio/);
  assert.match(bridge, /LiveWelComments\?\.publish/);
  assert.match(bridge, /livewelCommentPublishStatus/);
  assert.match(commandCenter, /LiveWelComments\?\.publish/);
});

test('ponte local expõe telemetria, OBS, destaque e reinício sem aceitar hosts externos', () => {
  const bridge = source('src/command-center-background.js');
  assert.match(bridge, /LIVEOS_CC_TELEMETRY/);
  assert.match(bridge, /LIVEOS_CC_OBS_SCENES/);
  assert.match(bridge, /LIVEOS_CC_OBS_SCENE/);
  assert.match(bridge, /LIVEOS_CC_HIGHLIGHT/);
  assert.match(bridge, /LIVEOS_CC_CAMERA_RESTART/);
  assert.match(bridge, /127\\\.0\\\.0\\\.1\|localhost/);
  assert.doesNotMatch(bridge, /0\.0\.0\.0\):18765/);
});

test('relay entrega quadros, mantém o último quadro e reporta conexão real', async () => {
  const listeners = [];
  const sent = [];
  const storageWrites = [];
  const context = vm.createContext({
    console,
    Date,
    Promise,
    String,
    chrome: {
      runtime: {
        sendMessage: async () => ({ ok: true }),
        onMessage: { addListener: (listener) => listeners.push(listener) },
        onConnect: { addListener() {} }
      },
      tabs: {
        query: async () => [{ id: 41 }],
        sendMessage: async (tabId, message, options) => {
          sent.push({ tabId, message, options });
          return { ok: true, paintedAt: Date.now(), sequence: message.sequence };
        }
      },
      storage: { local: { set: (value) => { storageWrites.push(value); return Promise.resolve(); } } }
    }
  });
  vm.runInContext(source('src/media-relay.js'), context, { filename: 'src/media-relay.js' });
  const listener = listeners[0];

  const sender = { tab: { id: 41 }, frameId: 7 };
  const initialReady = await dispatch(listener, { type: 'LIVEWEL_CAMERA_BRIDGE_READY', videoRequested: true }, sender);
  assert.equal(initialReady.sequence, 0);

  const delivered = await dispatch(listener, { type: 'LIVEWEL_PLAYER_FRAME', frame: 'data:image/webp;base64,AA==' });
  assert.equal(delivered.ok, true);
  assert.equal(delivered.delivered, 1);
  assert.equal(sent[0].tabId, 41);
  assert.equal(sent[0].message.type, 'LIVEWEL_CAMERA_FRAME');
  assert.equal(sent[0].message.sequence, 1);
  assert.equal(sent[0].options.frameId, 7);

  const ready = await dispatch(listener, { type: 'LIVEWEL_CAMERA_BRIDGE_READY', videoRequested: true }, sender);
  assert.equal(ready.ok, true);
  assert.equal(ready.sequence, 1);
  assert.equal(ready.frame, 'data:image/webp;base64,AA==');

  const throttled = await dispatch(listener, { type: 'LIVEWEL_PLAYER_FRAME', frame: 'data:image/webp;base64,AQ==' });
  assert.equal(throttled.ok, true);
  assert.equal(throttled.dropped, true);
  assert.ok(storageWrites.some((entry) => entry.livewelCameraFrameAt));
});

test('relay não informa câmera conectada quando nenhuma página recebeu o quadro', async () => {
  const listeners = [];
  const context = vm.createContext({
    console,
    Date,
    Promise,
    String,
    chrome: {
      runtime: {
        sendMessage: async () => ({ ok: true }),
        onMessage: { addListener: (listener) => listeners.push(listener) },
        onConnect: { addListener() {} }
      },
      tabs: { query: async () => [], sendMessage: async () => ({ ok: true }) },
      storage: { local: { set: () => Promise.resolve() } }
    }
  });
  vm.runInContext(source('src/media-relay.js'), context, { filename: 'src/media-relay.js' });

  const first = await dispatch(listeners[0], { type: 'LIVEWEL_PLAYER_FRAME', frame: 'data:image/webp;base64,AA==' });
  assert.equal(first.ok, false);
  assert.equal(first.delivered, 0);

  const throttled = await dispatch(listeners[0], { type: 'LIVEWEL_PLAYER_FRAME', frame: 'data:image/webp;base64,AQ==' });
  assert.equal(throttled.ok, false);
  assert.equal(throttled.dropped, true);
});

test('relay registra cada áudio uma vez e restaura o cache diretamente no frame', async () => {
  const listeners = [];
  const sent = [];
  const context = vm.createContext({
    console,
    Date,
    Promise,
    String,
    chrome: {
      runtime: {
        sendMessage: async () => ({ ok: true }),
        onMessage: { addListener: (listener) => listeners.push(listener) },
        onConnect: { addListener() {} }
      },
      tabs: {
        sendMessage: async (tabId, message, options) => {
          sent.push({ tabId, message, options });
          return { ok: true };
        }
      },
      storage: { local: { set: () => Promise.resolve() } }
    }
  });
  vm.runInContext(source('src/media-relay.js'), context, { filename: 'src/media-relay.js' });
  const listener = listeners[0];
  const sender = { tab: { id: 55 }, frameId: 7 };

  await dispatch(listener, { type: 'LIVEWEL_AUDIO_BRIDGE_READY', restore: false }, sender);
  await dispatch(listener, {
    type: 'LIVEWEL_AUDIO_SOURCE', id: 'audio-1', name: 'Faixa', currentTime: 2,
    startAt: Date.now(), playDurationSec: 6, dataUrl: 'data:audio/mpeg;base64,AAAA'
  });
  assert.equal(sent.at(-1).message.type, 'LIVEWEL_AUDIO_SOURCE');
  assert.match(sent.at(-1).message.dataUrl, /^data:audio/);

  for (const message of [
    { type: 'LIVEWEL_AUDIO_SOURCE_BEGIN', id: 'audio-long', token: 'transfer-1', size: 4, totalChunks: 1 },
    { type: 'LIVEWEL_AUDIO_SOURCE_CHUNK', id: 'audio-long', token: 'transfer-1', index: 0, data: 'AAAA' },
    { type: 'LIVEWEL_AUDIO_SOURCE_END', id: 'audio-long', token: 'transfer-1', totalChunks: 1 }
  ]) await dispatch(listener, message);
  assert.deepEqual(sent.slice(-3).map((entry) => entry.message.type), [
    'LIVEWEL_AUDIO_SOURCE_BEGIN', 'LIVEWEL_AUDIO_SOURCE_CHUNK', 'LIVEWEL_AUDIO_SOURCE_END'
  ]);

  sent.length = 0;
  const restored = await dispatch(listener, { type: 'LIVEWEL_AUDIO_BRIDGE_READY', restore: true }, sender);
  assert.equal(restored.messages.length, 0);
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(sent.map((entry) => entry.message.type), [
    'LIVEWEL_AUDIO_REGISTER_SOURCE', 'LIVEWEL_AUDIO_SOURCE', 'LIVEWEL_AUDIO_CONTROL'
  ]);
  assert.equal(sent[0].options.frameId, 7);
  assert.equal(sent[1].message.dataUrl, undefined, 'repetições usam somente uma referência leve ao cache');
});

test('fonte virtual aceita deviceId exact em lista e identifica a track', async () => {
  class FakeTrack {
    constructor(kind) {
      this.kind = kind;
      this.readyState = 'live';
      this.label = 'track real';
    }
    clone() { return new FakeTrack(this.kind); }
    stop() { this.readyState = 'ended'; }
    getSettings() { return { width: 720, height: 1280 }; }
  }

  class FakeMediaStream {
    constructor(tracks = []) { this.tracks = [...tracks]; }
    addTrack(track) { this.tracks.push(track); }
    getTracks() { return [...this.tracks]; }
    getVideoTracks() { return this.tracks.filter((track) => track.kind === 'video'); }
    getAudioTracks() { return this.tracks.filter((track) => track.kind === 'audio'); }
  }

  const nativeCalls = [];
  class FakeMediaDevices {
    async enumerateDevices() { return [{ kind: 'videoinput', deviceId: 'real-camera', label: 'Real', groupId: 'real' }]; }
    async getUserMedia(constraints) {
      nativeCalls.push(constraints);
      const tracks = [];
      if (constraints.video) tracks.push(new FakeTrack('video'));
      if (constraints.audio) tracks.push(new FakeTrack('audio'));
      return new FakeMediaStream(tracks);
    }
    dispatchEvent() { return true; }
  }

  const surface = {
    captureStream: () => new FakeMediaStream([new FakeTrack('video')])
  };
  const mediaDevices = new FakeMediaDevices();
  const windowObject = { addEventListener() {}, dispatchEvent() {} };
  const context = vm.createContext({
    console,
    navigator: { mediaDevices },
    document: {
      body: {},
      documentElement: {},
      getElementById: (id) => id === 'livewel-virtual-camera-surface' ? surface : null,
      createElement: () => ({ style: {}, addEventListener() {}, load() {}, pause() {}, play: async () => {} })
    },
    window: windowObject,
    MediaStream: FakeMediaStream,
    DOMException,
    CustomEvent: class CustomEvent { constructor(type) { this.type = type; } },
    Event,
    performance,
    Promise,
    Reflect,
    Object,
    Array,
    setTimeout,
    clearTimeout
  });
  vm.runInContext(source('src/page/virtual-devices.js'), context, { filename: 'src/page/virtual-devices.js' });

  const listed = await mediaDevices.enumerateDevices();
  assert.ok(listed.some((device) => device.deviceId === 'livewelpro-camera'));
  const stream = await mediaDevices.getUserMedia({
    video: { deviceId: { exact: ['livewelpro-camera'] } },
    audio: false
  });
  const track = stream.getVideoTracks()[0];
  assert.equal(track.label, 'LiveWelPro - Câmera Virtual');
  assert.equal(track.getSettings().deviceId, 'livewelpro-camera');
  assert.equal(nativeCalls.length, 0, 'a câmera virtual não deve abrir uma câmera física');

  await mediaDevices.getUserMedia({ video: { deviceId: { exact: 'real-camera' } } });
  assert.equal(nativeCalls.length, 1);
});

test('microfone virtual remonta áudio longo em blocos e libera uma URL Blob local', () => {
  const messageListeners = [];
  const createdBlobs = [];
  class FakeMediaDevices {
    async enumerateDevices() { return []; }
    async getUserMedia() { return { getTracks: () => [] }; }
    dispatchEvent() { return true; }
  }
  const windowObject = {
    addEventListener(type, listener) {
      if (type === 'message') messageListeners.push(listener);
    },
    dispatchEvent() {}
  };
  const context = vm.createContext({
    console,
    navigator: { mediaDevices: new FakeMediaDevices() },
    document: {
      body: {},
      documentElement: {},
      querySelectorAll: () => [],
      getElementById: () => null
    },
    window: windowObject,
    Blob,
    Uint8Array,
    ArrayBuffer,
    atob,
    URL: {
      createObjectURL(blob) {
        createdBlobs.push(blob);
        return 'blob:livewel-long-audio';
      },
      revokeObjectURL() {}
    },
    Reflect,
    Object,
    Array,
    Promise,
    setTimeout,
    clearTimeout
  });
  vm.runInContext(source('src/page/virtual-devices.js'), context, { filename: 'src/page/virtual-devices.js' });
  const emit = (data) => messageListeners.forEach((listener) => listener({ source: windowObject, data: { source: 'livewel-extension', ...data } }));
  emit({ type: 'LIVEWEL_AUDIO_SOURCE_BEGIN', id: 'long-1', token: 'token-1', mime: 'audio/mpeg', size: 4, totalChunks: 1 });
  emit({ type: 'LIVEWEL_AUDIO_SOURCE_CHUNK', id: 'long-1', token: 'token-1', index: 0, data: 'AQIDBA==' });
  emit({ type: 'LIVEWEL_AUDIO_SOURCE_END', id: 'long-1', token: 'token-1', totalChunks: 1 });
  assert.equal(createdBlobs.length, 1);
  assert.equal(createdBlobs[0].size, 4);
  assert.equal(createdBlobs[0].type, 'audio/mpeg');
});

test('bridge decodifica e pinta o quadro antes de confirmar', async () => {
  const listeners = [];
  const drawCalls = [];
  const appended = [];
  const context2d = {
    fillStyle: '',
    font: '',
    textAlign: '',
    fillRect() {},
    fillText() {},
    drawImage(bitmap) { drawCalls.push(bitmap); }
  };
  const canvas = {
    isConnected: false,
    width: 0,
    height: 0,
    setAttribute() {},
    style: {},
    getContext: () => context2d
  };
  const video = {
    isConnected: false,
    setAttribute() {},
    style: {},
    pause() {},
    play: async () => {}
  };
  const mount = {
    appendChild(node) {
      node.isConnected = true;
      appended.push(node);
    }
  };
  const windowObject = { addEventListener() {}, dispatchEvent() {}, postMessage() {} };
  const context = vm.createContext({
    console,
    chrome: {
      runtime: {
        onMessage: { addListener: (listener) => listeners.push(listener) },
        sendMessage: async () => ({ ok: true })
      }
    },
    document: {
      readyState: 'complete',
      body: mount,
      documentElement: mount,
      createElement: (name) => {
        if (name === 'canvas') return canvas;
        if (name === 'video') return video;
        throw new Error(`Elemento inesperado: ${name}`);
      }
    },
    window: windowObject,
    top: windowObject,
    location: { protocol: 'https:', origin: 'https://seller-br.tiktok.com', href: 'https://seller-br.tiktok.com/rlshop/streamer/live' },
    createImageBitmap: async () => ({ width: 2, height: 2, close() {} }),
    Blob,
    Uint8Array,
    atob,
    decodeURIComponent,
    Date,
    Number,
    Promise,
    CustomEvent: class CustomEvent { constructor(type, init) { this.type = type; this.detail = init?.detail; } },
    queueMicrotask,
    setInterval: () => 1
  });
  vm.runInContext(source('src/content/virtual-camera-bridge.js'), context, { filename: 'src/content/virtual-camera-bridge.js' });

  const response = await dispatch(listeners[0], {
    type: 'LIVEWEL_CAMERA_FRAME',
    frame: 'data:image/webp;base64,AA==',
    sequence: 7
  });
  assert.equal(response.ok, true);
  assert.equal(response.sequence, 7);
  assert.ok(response.paintedAt > 0);
  assert.equal(drawCalls.length, 1);
  assert.equal(appended.length, 2);
});

test('relay WebRTC encaminha sinal e quadros pelo canal privado sem unknown_message', async () => {
  const connectListeners = [];
  const storageWrites = [];
  const makePort = (name) => {
    const messageListeners = [];
    const disconnectListeners = [];
    return {
      name,
      sent: [],
      onMessage: { addListener: (listener) => messageListeners.push(listener) },
      onDisconnect: { addListener: (listener) => disconnectListeners.push(listener) },
      postMessage(message) { this.sent.push(message); },
      emit(message) { messageListeners.forEach((listener) => listener(message)); },
      disconnect() { disconnectListeners.forEach((listener) => listener()); }
    };
  };
  const context = vm.createContext({
    console,
    Date,
    Promise,
    String,
    chrome: {
      runtime: {
        onMessage: { addListener() {} },
        onConnect: { addListener: (listener) => connectListeners.push(listener) }
      },
      tabs: { query: async () => [], sendMessage: async () => ({ ok: true }) },
      storage: { local: { set: (value) => { storageWrites.push(value); return Promise.resolve(); } } }
    }
  });
  vm.runInContext(source('src/media-relay.js'), context, { filename: 'src/media-relay.js' });

  const player = makePort('LIVEWEL_PLAYER_RTC');
  const camera = makePort('LIVEWEL_CAMERA_RTC');
  connectListeners[0](player);
  connectListeners[0](camera);
  camera.emit({ type: 'receiver-ready', receiverId: 'camera-1' });
  assert.equal(player.sent.at(-1).type, 'receiver-ready');
  player.emit({ type: 'signal', receiverId: 'camera-1', signal: { description: { type: 'offer', sdp: 'offer' } } });
  assert.equal(camera.sent.at(-1).signal.description.type, 'offer');
  camera.emit({ type: 'signal', receiverId: 'camera-1', signal: { description: { type: 'answer', sdp: 'answer' } } });
  assert.equal(player.sent.at(-1).signal.description.type, 'answer');
  camera.emit({ type: 'receiver-status', receiverId: 'camera-1', status: 'connected' });
  assert.ok(storageWrites.some((entry) => entry.livewelCameraTransport === 'webrtc'));
  player.emit({ type: 'fallback-frame', requestId: 'frame-1', frame: 'data:image/webp;base64,AA==' });
  await new Promise((resolve) => setTimeout(resolve, 0));
  const fallbackResult = player.sent.find((message) => message.type === 'fallback-frame-result');
  assert.equal(fallbackResult.requestId, 'frame-1');
  assert.doesNotMatch(String(fallbackResult.error || ''), /unknown_message/i);
});

test('estúdio compõe várias camadas de vídeo e imagem na mesma câmera virtual', () => {
  const html = source('player/player.html');
  const player = source('player/player.js');
  const css = source('player/layers.css');
  assert.match(html, /id="layerVideoInput"[^>]*multiple/);
  assert.match(html, /id="layerImageInput"[^>]*multiple/);
  assert.match(html, /id="mediaLayerList"/);
  assert.doesNotMatch(html, /id="ghostVideo"/);
  assert.match(player, /mediaLayers:\s*\[\]/);
  assert.match(player, /importMediaLayers/);
  assert.match(player, /loadMediaLayer/);
  assert.match(player, /drawMediaLayer/);
  assert.match(player, /state\.mediaLayers\.forEach\(drawMediaLayer\)/);
  assert.match(player, /data-kind="media"/);
  assert.match(player, /moveMediaLayer/);
  assert.match(player, /normalizeMediaLayer/);
  assert.match(css, /media-drag-item/);
  assert.match(css, /media-layer-card/);
  assert.doesNotMatch(player, /setOutputResolution/, 'a resolução da trilha deve permanecer fixa entre vídeos');
  assert.match(player, /type: 'fallback-frame'/);
});

test('estúdio pré-carrega e inicia o próximo vídeo antes do crossfade sem trocar para um player pausado', () => {
  const html = source('player/player.html');
  const player = source('player/player.js');
  assert.match(html, /value="fade" selected>Fade suave/);
  assert.match(player, /transition: 'fade'/);
  assert.match(player, /function waitForFirstVideoFrame/);
  assert.match(player, /await startTakePlayback\(video\)/);
  assert.match(player, /if \(video\.paused\) throw new Error/);
  assert.match(player, /takeSwitchPromise/);
  assert.match(player, /monitorPlaybackBoundary\(\)/);
  assert.match(player, /video\.addEventListener\('pause'.*schedulePlaybackRecovery/);
  assert.doesNotMatch(player, /for \(const video of players\) playing \? video\.play/);
});

test('estúdio cria faixa de preço com rolagem vertical infinita e cores configuráveis', () => {
  const html = source('player/player.html');
  const player = source('player/player.js');
  const css = source('player/layers.css');
  assert.match(html, /id="btnAddPrice"/);
  assert.match(player, /type:'price-marquee'/);
  assert.match(player, /promoPrice:'R\$ 17,99'/);
  assert.match(player, /originalPrice:'R\$ 64,99'/);
  assert.match(player, /function drawPriceMarquee/);
  assert.match(player, /now % duration/);
  assert.match(player, /ctx\.clip\(\)/);
  assert.match(player, /data-field="speed"/);
  assert.match(player, /data-field="color"/);
  assert.match(player, /data-field="bg"/);
  assert.match(css, /overlay-range-pair/);
  assert.match(css, /price-drag-item/);
});

test('áudio mantém monitor local independente e inclui voz e ambiente leves', () => {
  const offscreen = source('offscreen/audio.js');
  const virtualDevices = source('src/page/virtual-devices.js');
  const idb = source('src/shared/idb.js');
  const dashboard = source('dashboard/index.html');
  assert.doesNotMatch(offscreen, /new Audio\s*\(/, 'o monitor não deve depender de elemento de áudio duplicado');
  assert.doesNotMatch(offscreen, /cable\.play/, 'não deve reproduzir o cabo virtual localmente');
  assert.match(offscreen, /monitorGain\.gain\.value = 0/);
  assert.match(offscreen, /config\.monitorEnabled === true \? 1 : 0/);
  assert.match(offscreen, /ensureAmbientMonitor/);
  assert.match(offscreen, /ambientVolumeForLevel/);
  assert.match(offscreen, /decodeLibraryItem/);
  assert.match(offscreen, /Promise\.race/);
  assert.match(offscreen, /ambientGain.*monitorGain/);
  assert.match(offscreen, /idbGetAudioBlob/);
  assert.match(offscreen, /AUDIO_TRANSFER_CHUNK_BYTES = 192 \* 1024/);
  assert.match(offscreen, /LIVEWEL_AUDIO_SOURCE_CHUNK/);
  assert.match(offscreen, /latencyHint: 'playback'/);
  assert.match(virtualDevices, /createMediaStreamDestination\(\)/);
  assert.match(virtualDevices, /createAmbientMicrophoneNoise/);
  assert.match(virtualDevices, /normalizedAmbient/);
  assert.match(virtualDevices, /voiceLowShelf/);
  assert.match(virtualDevices, /pendingAudioTransfers/);
  assert.match(virtualDevices, /URL\.createObjectURL\(blob\)/);
  assert.match(virtualDevices, /latencyHint: 'playback'/);
  assert.match(idb, /export async function idbGetAudioBlob/);
  assert.match(idb, /blob,\s*mime,/);
  assert.match(dashboard, /id="audioSpeed"/);
  assert.match(dashboard, /id="audioTone"/);
  assert.match(dashboard, /id="audioAmbientEnabled"/);
  assert.match(dashboard, /id="audioMonitorEnabled"/);
});

test('violação encerra por padrão usando a API DOM correta e observação visível', () => {
  const violation = source('src/content/violation-telegram-bridge.js');
  assert.match(violation, /PLWDom\?\.tryEndLive/);
  assert.match(violation, /state\.violationAutoEnd !== false/);
  assert.match(violation, /new MutationObserver\(queueVisibleViolationScan\)/);
  assert.match(violation, /setInterval\(scanVisibleViolation, 650\)/);
});
