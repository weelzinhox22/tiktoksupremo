const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');
const TELEGRAM_KEY = 'liveosTelegramSecretsV1';

function source(relativePath) {
  return fs.readFileSync(path.join(ROOT, relativePath), 'utf8');
}

function makeTelegramHarness() {
  const token = `12345:${'A'.repeat(25)}`;
  const store = {
    [TELEGRAM_KEY]: {
      enabled: true,
      notifyManual: true,
      notifyDetected: true,
      notifySafety: true,
      chatId: '777',
      botToken: token
    }
  };
  const runtimeListeners = [];
  const connectListeners = [];
  const intervalCallbacks = [];
  const sentTelegram = [];
  const tabMessages = [];
  const playerMessages = [];
  let telegramUpdates = [];

  const storage = {
    async get(keys) {
      if (keys == null) return { ...store };
      if (typeof keys === 'string') return { [keys]: store[keys] };
      const result = {};
      for (const key of keys) result[key] = store[key];
      return result;
    },
    async set(values) { Object.assign(store, values); },
    async remove(keys) { for (const key of Array.isArray(keys) ? keys : [keys]) delete store[key]; }
  };

  const fetch = async (url, options = {}) => {
    const method = String(url).split('/').at(-1);
    let result = true;
    if (method === 'getMe') result = { id: 1, username: 'livewel_test_bot' };
    else if (method === 'getChat') result = { id: 777, title: 'Operação LIVE' };
    else if (method.startsWith('getUpdates')) result = telegramUpdates.splice(0);
    else if (method === 'sendMessage') {
      const body = JSON.parse(options.body || '{}');
      sentTelegram.push(body);
      result = { message_id: sentTelegram.length };
    }
    return { ok: true, status: 200, json: async () => ({ ok: true, result }) };
  };

  const context = vm.createContext({
    console,
    Date,
    Intl,
    Math,
    Number,
    String,
    Promise,
    Map,
    Set,
    fetch,
    setInterval(callback) { intervalCallbacks.push(callback); return intervalCallbacks.length; },
    setTimeout() { return 1; },
    chrome: {
      storage: { local: storage },
      tabs: {
        query: async () => [{ id: 10, url: 'https://seller.tiktok.com/live' }],
        sendMessage: async (_tabId, message) => { tabMessages.push(message); return { ok: true, position: message.payload?.position }; }
      },
      runtime: {
        onMessage: { addListener: (listener) => runtimeListeners.push(listener) },
        onConnect: { addListener: (listener) => connectListeners.push(listener) },
        sendMessage: async (message) => {
          playerMessages.push(message);
          if (message.type === 'LIVEOS_CC_OBS_SCENES') return { ok: true, data: { scenes: ['Principal', 'Produtos'], current: 'Principal' } };
          if (message.type === 'LIVEOS_CC_TELEMETRY') return { ok: true, data: { actualFps: 29.7, targetFps: 30, width: 720, height: 1280, restartCount: 2, lastFrameAgeMs: 18, cameraConnected: true } };
          return { ok: true, data: { ok: true } };
        }
      },
      alarms: { create() {}, onAlarm: { addListener() {} } }
    },
    LiveWelAudioService: { command: async () => ({ ok: true }) }
  });
  vm.runInContext(source('src/telegram-background.js'), context, { filename: 'src/telegram-background.js' });

  const dispatch = (message) => new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`Telegram não respondeu: ${message.type}`)), 1500);
    const keep = runtimeListeners[0](message, {}, (response) => { clearTimeout(timeout); resolve(response); });
    if (keep !== true) { clearTimeout(timeout); resolve(undefined); }
  });

  const dispatchPrivate = (message) => new Promise((resolve, reject) => {
    const requestId = `private_${Date.now()}`;
    const inbound = [];
    const timeout = setTimeout(() => reject(new Error(`Canal privado não respondeu: ${message.type}`)), 1500);
    const port = {
      name: 'livewel-telegram-rpc-v1',
      onMessage: { addListener: (listener) => inbound.push(listener) },
      postMessage(response) {
        if (response?.requestId !== requestId) return;
        clearTimeout(timeout);
        resolve(response);
      }
    };
    for (const listener of connectListeners) listener(port);
    for (const listener of inbound) listener({ requestId, ...message });
  });

  return {
    store,
    sentTelegram,
    tabMessages,
    playerMessages,
    intervalCallbacks,
    dispatch,
    dispatchPrivate,
    setUpdates(updates) { telegramUpdates = [...updates]; }
  };
}

test('Telegram confirma bot/chat e envia teste real pela API simulada', async () => {
  const harness = makeTelegramHarness();
  const privateConfig = await harness.dispatchPrivate({ type: 'LIVEOS_TG_GET_CONFIG' });
  assert.equal(privateConfig.ok, true);
  assert.equal(privateConfig.config.chatId, '777');
  const checked = await harness.dispatch({ type: 'LIVEOS_TG_CHECK' });
  assert.equal(checked.ok, true);
  assert.equal(checked.config.connected, true);
  assert.equal(checked.config.botUsername, 'livewel_test_bot');

  const tested = await harness.dispatch({ type: 'LIVEOS_TG_TEST' });
  assert.equal(tested.ok, true);
  assert.match(harness.sentTelegram.at(-1).text, /GMV, pedidos, vendas, segurança/);
});

test('Telegram formata venda detectada com pedidos/GMV e não duplica o evento', async () => {
  const harness = makeTelegramHarness();
  const message = {
    type: 'LIVEOS_TG_SALE', source: 'detected', eventId: 'sale:orders:8',
    productName: 'Produto teste', orderDelta: 2, totalOrders: 8, value: 159.8, totalGmv: 799.4
  };
  const first = await harness.dispatch(message);
  const second = await harness.dispatch(message);
  assert.equal(first.ok, true);
  assert.equal(second.duplicate, true);
  const sent = harness.sentTelegram.at(-1).text;
  assert.match(sent, /NOVA VENDA DETECTADA/);
  assert.match(sent, /Novos pedidos: 2/);
  assert.match(sent, /Pedidos no painel: 8/);
  assert.match(sent, /GMV: R\$\s*799,40/);
});

test('Telegram envia todos os estados de segurança solicitados', async () => {
  const harness = makeTelegramHarness();
  const statuses = ['detected', 'close_requested', 'closed', 'platform_closed', 'close_failed'];
  for (const status of statuses) {
    const response = await harness.dispatch({ type: 'LIVEOS_TG_SAFETY', eventId: `violation:1:${status}`, status, detectedAt: Date.now(), autoEnd: true });
    assert.equal(response.ok, true);
  }
  const combined = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(combined, /AVISO DE VIOLAÇÃO DETECTADO/);
  assert.match(combined, /ENCERRAMENTO AUTOMÁTICO INICIADO/);
  assert.match(combined, /LIVE FECHADA/);
  assert.match(combined, /ENCERRADA PELO TIKTOK/);
  assert.match(combined, /FALHA AO FECHAR/);
});

test('comandos remotos persistem offset e chegam aos consumidores reais', async () => {
  const harness = makeTelegramHarness();
  harness.store.playlist = [{ name: 'Produto 1' }, { name: 'Produto 2' }, { name: 'Produto 3' }];
  harness.store.currentIndex = 0;
  harness.store.gmvCurrent = 100;
  harness.store.gmvOrders = 2;
  const poll = harness.intervalCallbacks[0];
  harness.setUpdates([
    { update_id: 101, message: { text: '/pin 2', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 102, message: { text: '/play', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 103, message: { text: '/timer', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 104, message: { text: '/pausa', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 105, message: { text: '/proximo', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 106, message: { text: '/venda 79,90', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 107, message: { text: '/status', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 108, message: { text: '/kill', chat: { id: 777 }, from: { first_name: 'Operador' } } }
  ]);
  await poll();
  assert.equal(harness.store.liveosTelegramLastUpdateV1, 108);
  assert.ok(harness.tabMessages.some((message) => message.type === 'LIVEWEL_DASH_COMMAND' && message.payload.position === 2));
  assert.ok(harness.tabMessages.some((message) => message.type === 'LIVEOS_EMERGENCY_KILL'));
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEWEL_PLAYER_COMMAND' && message.command === 'PLAY'));
  assert.ok(harness.playerMessages.some((message) => message.command === 'PAUSE'));
  assert.ok(harness.playerMessages.some((message) => message.command === 'NEXT'));
  assert.ok(harness.playerMessages.some((message) => message.command === 'RESET_TIMER'));
  assert.equal(harness.store.gmvCurrent, 179.9);
  assert.equal(harness.store.gmvOrders, 3);
  assert.equal(typeof harness.store.liveEmergencyKillTriggered, 'number');
  const replies = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(replies, /Produto #2 fixado/);
  assert.match(replies, /Reprodução iniciada/);
  assert.match(replies, /Cronômetro de oferta reiniciado/);
  assert.match(replies, /Reprodução pausada/);
  assert.match(replies, /Próximo take acionado/);
  assert.match(replies, /VENDA MANUAL REGISTRADA/);
  assert.match(replies, /Pedidos: 3/);
  assert.match(replies, /GMV Acumulado/);
  assert.match(replies, /Encerramento de emergência solicitado/);
});

test('Telegram desfaz venda antiga, remove venda por valor e expõe novas consultas', async () => {
  const harness = makeTelegramHarness();
  harness.store.playlist = [{ name: 'Produto A' }, { name: 'Produto B' }];
  harness.store.currentIndex = 0;
  harness.store.gmvCurrent = 200;
  harness.store.gmvOrders = 2;
  harness.store.lastManualSaleAt = Date.now() - 1000;
  harness.store.lastManualSaleValue = 50;
  harness.store.livewelAudioStatus = { playing: true, currentTrackName: 'Áudio 30 minutos', monitoring: false };
  harness.store.audioLibrary = [{ id: 'longa', name: 'Áudio 30 minutos', duration: 1800, streaming: true }];
  harness.store.audioPlayMode = 'full';
  const poll = harness.intervalCallbacks[0];
  harness.setUpdates([
    { update_id: 201, message: { text: '/desfazervenda', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 202, message: { text: '/venda 25,50', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 203, message: { text: '/vendas', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 204, message: { text: '/removervenda 25,50', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 205, message: { text: '/produtos', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 206, message: { text: '/audio', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 207, message: { text: '/anterior', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 208, message: { text: '/removervenda id-inexistente-999', chat: { id: 777 }, from: { first_name: 'Operador' } } }
  ]);
  await poll();
  assert.equal(harness.store.liveosTelegramLastUpdateV1, 208);
  assert.equal(harness.store.gmvCurrent, 150);
  assert.equal(harness.store.gmvOrders, 1);
  assert.equal(harness.store.currentIndex, 1);
  const sales = harness.store.liveosTelegramManualSalesV1;
  assert.equal(sales.length, 1);
  assert.equal(sales[0].value, 25.5);
  assert.equal(typeof sales[0].removedAt, 'number');
  assert.ok(sales[0].removedAt > 0);
  const replies = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(replies, /VENDA MANUAL REMOVIDA/);
  assert.match(replies, /VENDAS MANUAIS/);
  assert.match(replies, /FILA DE PRODUTOS/);
  assert.match(replies, /STATUS DO ÁUDIO/);
  assert.match(replies, /faixa longa em loop direto/);
  assert.match(replies, /Produto #2 fixado/);
  assert.match(replies, /Nenhuma venda manual ativa foi encontrada/);
});

test('Telegram controla cenas, câmera, destaque, telemetria e perfis leves', async () => {
  const harness = makeTelegramHarness();
  const poll = harness.intervalCallbacks[0];
  harness.setUpdates([
    { update_id: 151, message: { text: '/cenas', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 152, message: { text: '/cena 2', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 153, message: { text: '/destaque', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 154, message: { text: '/camera', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 155, message: { text: '/telemetria', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 156, message: { text: '/perfil fraco', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 157, message: { text: '/respostas on', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 158, message: { text: '/auto on', chat: { id: 777 }, from: { first_name: 'Operador' } } }
  ]);
  await poll();
  assert.equal(harness.store.liveosTelegramLastUpdateV1, 158);
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEOS_CC_OBS_SCENE' && message.scene === 'Produtos'));
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEOS_CC_HIGHLIGHT'));
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEOS_CC_CAMERA_RESTART'));
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEOS_CC_TELEMETRY'));
  assert.ok(harness.playerMessages.some((message) => message.type === 'LIVEOS_CC_OUTPUT_CONFIG' && message.config.captureProfile === 'low'));
  const settings = harness.store.liveosCommandCenterV1.settings;
  assert.equal(settings.captureProfile, 'low');
  assert.equal(settings.outputFps, 30);
  assert.equal(settings.autoReplyEnabled, true);
  assert.equal(settings.engagementAutoPublish, true);
  const replies = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(replies, /CENAS DO OBS/);
  assert.match(replies, /Cena alterada no OBS: Produtos/);
  assert.match(replies, /29\.7 \/ 30/);
  assert.match(replies, /PC fraco aplicado/);
});

test('Telegram executa resumo, meta, busca, comentário, alertas, segurança, bloqueio, ciclo e diagnóstico', async () => {
  const harness = makeTelegramHarness();
  harness.store.playlist = [
    { id: 'p1', name: 'Escova Modeladora', price: 79.9, stock: 20 },
    { id: 'p2', name: 'Kit Produto Beta', price: 'R$ 129,90', coupon: 'BETA10' }
  ];
  harness.store.currentIndex = 0;
  harness.store.gmvCurrent = 1250;
  harness.store.gmvOrders = 9;
  harness.store.gmvGoal = 2000;
  harness.store.liveOnAir = true;
  harness.store.livewelPlayerOnline = true;
  harness.store.livewelPlayerUpdatedAt = Date.now();
  harness.store.livewelPlayerTake = 'Take principal';
  harness.store.livewelCameraFrameAt = Date.now();
  harness.store.livewelAudioStatus = { playing: true, currentTrackName: 'Trilha longa' };
  harness.store.violationAutoEnd = true;
  harness.store.livewelCycleConfig = { enabled: true, hours: 2, minutes: 0, startedAt: Date.now(), products: 'p1\np2', lastStatus: 'Ciclo programado.' };
  const poll = harness.intervalCallbacks[0];
  harness.setUpdates([
    { update_id: 301, message: { text: '/meta 5.000', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 302, message: { text: '/faltameta', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 303, message: { text: '/produto', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 304, message: { text: '/buscarproduto beta', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 305, message: { text: '/pin Kit Produto Beta', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 306, message: { text: '/comentario Confira o produto fixado!', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 307, message: { text: '/alertas', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 308, message: { text: '/alertas vendas off', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 309, message: { text: '/seguranca', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 310, message: { text: '/bloquear @loja_teste', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 311, message: { text: '/ciclo', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 312, message: { text: '/diagnostico', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 313, message: { text: '/resumo', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 314, message: { text: '/historico', chat: { id: 777 }, from: { first_name: 'Operador' } } }
  ]);
  await poll();
  assert.equal(harness.store.liveosTelegramLastUpdateV1, 314);
  assert.equal(harness.store.gmvGoal, 5000);
  assert.equal(harness.store.currentIndex, 1);
  assert.equal(harness.store[TELEGRAM_KEY].notifyDetected, false);
  assert.equal(harness.store[TELEGRAM_KEY].notifyManual, false);
  assert.equal(harness.store.livewelModerationConfig.enabled, true);
  assert.ok(harness.store.livewelModerationConfig.profiles.includes('loja_teste'));
  assert.ok(harness.tabMessages.some((message) => message.action === 'pin-position' && message.payload.position === 2));
  assert.ok(harness.tabMessages.some((message) => message.action === 'send-comment' && /Confira/.test(message.payload.text)));
  assert.ok(harness.tabMessages.some((message) => message.action === 'block-profile' && message.payload.profile === 'loja_teste'));
  const replies = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(replies, /Meta atualizada/);
  assert.match(replies, /Falta: R\$\s*3\.750,00/);
  assert.match(replies, /PRODUTO ATUAL/);
  assert.match(replies, /RESULTADOS PARA/);
  assert.match(replies, /Kit Produto Beta fixado/);
  assert.match(replies, /Comentário publicado/);
  assert.match(replies, /ALERTAS DO TELEGRAM/);
  assert.match(replies, /SEGURANÇA DA LIVE/);
  assert.match(replies, /loja_teste foi cadastrado/);
  assert.match(replies, /CICLO AUTOMÁTICO/);
  assert.match(replies, /DIAGNÓSTICO RÁPIDO/);
  assert.match(replies, /RESUMO DA OPERAÇÃO/);
  assert.match(replies, /HISTÓRICO RECENTE/);
});

test('Telegram exige confirmação persistente para limpar fila, zerar GMV e executar ciclo', async () => {
  const harness = makeTelegramHarness();
  harness.store.playlist = [{ name: 'Produto A' }, { name: 'Produto B' }];
  harness.store.currentIndex = 1;
  harness.store.gmvCurrent = 999.9;
  harness.store.gmvOrders = 7;
  harness.store.liveosTelegramManualSalesV1 = [{ id: 'vteste', value: 99.9, at: Date.now(), removedAt: 0 }];
  harness.store.livewelCycleConfig = { enabled: true, hours: 2, minutes: 0, startedAt: Date.now(), products: 'Produto A' };
  const poll = harness.intervalCallbacks[0];
  harness.setUpdates([
    { update_id: 401, message: { text: '/limparfila', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 402, message: { text: '/cancelar', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 403, message: { text: '/limparfila', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 404, message: { text: '/confirmar', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 405, message: { text: '/zerargmv', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 406, message: { text: '/confirmar', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 407, message: { text: '/ciclo agora', chat: { id: 777 }, from: { first_name: 'Operador' } } },
    { update_id: 408, message: { text: '/confirmar', chat: { id: 777 }, from: { first_name: 'Operador' } } }
  ]);
  await poll();
  assert.equal(harness.store.liveosTelegramLastUpdateV1, 408);
  assert.equal(harness.store.playlist.length, 0);
  assert.equal(harness.store.currentIndex, 0);
  assert.equal(harness.store.gmvCurrent, 0);
  assert.equal(harness.store.gmvOrders, 0);
  assert.equal(harness.store.liveosTelegramManualSalesV1.length, 0);
  assert.equal(harness.store.liveosTelegramPendingActionV1, undefined);
  assert.ok(harness.tabMessages.some((message) => message.action === 'clear-queue'));
  assert.ok(harness.tabMessages.some((message) => message.action === 'run-cycle'));
  const replies = harness.sentTelegram.map((entry) => entry.text).join('\n');
  assert.match(replies, /CONFIRMAÇÃO NECESSÁRIA/);
  assert.match(replies, /Ação cancelada/);
  assert.match(replies, /Fila de produtos limpa/);
  assert.match(replies, /GMV e pedidos zerados/);
  assert.match(replies, /Ciclo imediato solicitado/);
});

test('canal privado do áudio mantém PLAY em loop sem recarregar a biblioteca nos ajustes', async () => {
  const connectListeners = [];
  const sentToEngine = [];
  const runtimeMessages = [];
  const openedPanels = [];
  const panelBehaviors = [];
  let actionClickListener = null;
  const store = {
    audioLibrary: [{ id: 'a1', name: 'Faixa 1' }, { id: 'a2', name: 'Faixa 2' }],
    audioPlayMode: 'segments',
    audioMonitorEnabled: true,
    audioSegmentMinSec: 4,
    audioSegmentMaxSec: 12,
    audioGapSec: 1
  };
  const context = vm.createContext({
    console,
    Date,
    Math,
    Promise,
    Map,
    Error,
    queueMicrotask,
    setTimeout,
    clearTimeout,
    setInterval() { return 1; },
    chrome: {
      action: { setPopup: async () => {}, onClicked: { addListener: (listener) => { actionClickListener = listener; } } },
      sidePanel: {
        setOptions: async () => {},
        setPanelBehavior: async (options) => { panelBehaviors.push(options); },
        open: async (options) => { openedPanels.push(options); }
      },
      windows: { getCurrent: async () => ({ id: 1 }) },
      tabs: { query: async () => [], create: async () => { throw new Error('não deve abrir aba'); } },
      offscreen: { createDocument: async () => {}, closeDocument: async () => {} },
      storage: {
        local: {
          get: async () => ({ ...store }),
          set: async (values) => Object.assign(store, values)
        },
        onChanged: { addListener() {} }
      },
      runtime: {
        getURL: (value) => `chrome-extension://test/${value}`,
        getContexts: async () => [{ contextType: 'OFFSCREEN_DOCUMENT' }],
        sendMessage: async (message) => { runtimeMessages.push(message); return { ok: false, error: 'unknown_message' }; },
        onMessage: { addListener() {} },
        onConnect: { addListener: (listener) => connectListeners.push(listener) },
        onInstalled: { addListener() {} },
        onStartup: { addListener() {} }
      }
    }
  });
  const dashboardService = source('src/dashboard-service.js');
  vm.runInContext(dashboardService, context, { filename: 'src/dashboard-service.js' });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(panelBehaviors.at(-1)?.openPanelOnActionClick, true);
  assert.equal(actionClickListener, null);
  assert.equal(openedPanels.length, 0);
  assert.doesNotMatch(dashboardService, /chrome\.tabs\.create\s*\(/);

  let receiveFromEngine = null;
  const enginePort = {
    name: 'livewel-audio-offscreen-v3',
    onMessage: { addListener: (listener) => { receiveFromEngine = listener; } },
    onDisconnect: { addListener() {} },
    postMessage(message) {
      sentToEngine.push(message.payload);
      const type = message.payload?.type;
      const result = type === 'OFFSCREEN_AUDIO_STATUS'
        ? { ok: true, engineVersion: '3.8.0', monitoring: true }
        : type === 'OFFSCREEN_AUDIO_PLAY'
          ? { ok: true, playing: true }
          : { ok: true };
      queueMicrotask(() => receiveFromEngine({ kind: 'response', requestId: message.requestId, result }));
    }
  };
  for (const listener of connectListeners) listener(enginePort);

  const played = await context.LiveWelAudioService.command('PLAY');
  assert.equal(played.playing, true);
  assert.deepEqual(sentToEngine.map((message) => message.type), [
    'OFFSCREEN_AUDIO_STATUS', 'OFFSCREEN_AUDIO_LOAD', 'OFFSCREEN_AUDIO_CONFIG', 'OFFSCREEN_AUDIO_PLAY'
  ]);
  assert.equal(sentToEngine[2].monitorEnabled, true);
  assert.equal(sentToEngine[2].minSec, 4);
  assert.equal(sentToEngine[2].maxSec, 12);
  const beforeConfig = sentToEngine.length;
  await context.LiveWelAudioService.command('CONFIG', { audioSegmentMinSec: 7, audioSegmentMaxSec: 18 });
  assert.deepEqual(sentToEngine.slice(beforeConfig).map((message) => message.type), ['OFFSCREEN_AUDIO_CONFIG']);
  assert.equal(sentToEngine.at(-1).minSec, 7);
  assert.equal(sentToEngine.at(-1).maxSec, 18);
  assert.equal(runtimeMessages.length, 0, 'o motor privado não pode receber unknown_message do canal legado');
});

test('áudio segmentado, monitor mudo, comentários e bloqueio estão ligados à interface', () => {
  const audio = source('offscreen/audio.js');
  const devices = source('src/page/virtual-devices.js');
  const dashboard = source('dashboard/index.html');
  const moderation = source('src/content/moderation-automation.js');
  const audioService = source('src/dashboard-service.js');
  const dashboardScript = source('dashboard/dashboard.js');
  assert.match(audio, /randomSegmentSelection/);
  assert.match(audio, /segmentBag/);
  assert.match(audio, /playDurationSec/);
  assert.match(audio, /Math\.round\(startAt \/ 10\)/);
  assert.match(audio, /const gap = chopping \?/);
  assert.match(audio, /keepScheduleAlive/);
  assert.match(audio, /firstDataUrl/);
  assert.match(audio, /try \{ return await registration; \}/);
  assert.match(dashboardScript, /audioImporting/);
  assert.match(dashboardScript, /clearAudioQueue/);
  assert.match(dashboardScript, /inspectAudioFile/);
  assert.match(dashboardScript, /LONG_AUDIO_MIN_DURATION_SEC/);
  assert.match(dashboardScript, /idbListAudioIds/);
  assert.match(dashboardScript, /failures\.push/);
  assert.match(audio, /schedulingChanged/);
  assert.match(audio, /playing && schedulingChanged/);
  assert.match(audio, /monitorGain/);
  assert.match(audio, /livewel-audio-offscreen-v3/);
  assert.match(audio, /ensureScheduler/);
  assert.match(audio, /startStreamedAudio/);
  assert.match(audio, /if \(isLongAudioTrack\(item\)\) return true/);
  assert.match(audio, /element\.loop = true/);
  assert.match(audioService, /reasons: \['AUDIO_PLAYBACK', 'BLOBS'\]/);
  assert.match(audioService, /recoverContinuousAudio/);
  assert.match(audioService, /normalizedCommand === 'RELOAD'/);
  assert.match(devices, /installVirtualMonitorMute/);
  assert.match(devices, /data-livewel-local-monitor/);
  assert.match(devices, /audioSourceUrls/);
  assert.match(devices, /element\.loop = data\.loop === true/);
  assert.match(dashboard, /id="audioSegmentMinNumber"/);
  assert.match(dashboard, /id="audioMonitorEnabled"/);
  assert.match(dashboard, /Segurança máxima · 60 a 120s/);
  assert.match(dashboard, /Super seguro · 120 a 300s/);
  assert.match(dashboard, /id="blockedProfiles"/);
  assert.match(moderation, /tryBlockNearbyComment/);
  assert.match(dashboardScript, /livewel-telegram-rpc-v1/);
  assert.match(dashboardScript, /livewel-dashboard-audio-rpc-v1/);
  const relay = source('src/media-relay.js');
  assert.match(relay, /audioSourceRegistry/);
  assert.match(relay, /LIVEWEL_AUDIO_REGISTER_SOURCE/);
});

test('todos os controles usados pelo dashboard existem no HTML', () => {
  const script = source('dashboard/dashboard.js');
  const html = source('dashboard/index.html');
  const usedIds = [...script.matchAll(/\$\('([^']+)'\)/g)].map((match) => match[1]);
  const htmlIds = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]));
  const missing = [...new Set(usedIds)].filter((id) => !htmlIds.has(id));
  assert.deepEqual(missing, []);
});

test('refresh do dashboard não percorre nem rola a fila de produtos periodicamente', () => {
  const bridge = source('src/content/dashboard-bridge.js');
  assert.match(bridge, /snapshot\(\{ allProducts = false \}/);
  assert.match(bridge, /allProducts: action === 'import-products'/);
  assert.match(bridge, /autoRepinEnabled: false/);
  assert.match(bridge, /action === 'send-comment'/);
  assert.match(bridge, /action === 'block-profile'/);
  assert.doesNotMatch(bridge, /keepFirstTick/);
  assert.doesNotMatch(bridge, /setInterval\([^)]*keepFirst/);
});
