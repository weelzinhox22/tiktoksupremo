import { idbGetAudio, idbGetAudioBlob } from '../src/shared/idb.js';

const AUDIO_ENGINE_VERSION = '3.8.0';
const AUDIO_ENGINE_PORT = 'livewel-audio-offscreen-v3';
const LONG_AUDIO_MIN_DURATION_SEC = 5 * 60;
const LONG_AUDIO_MIN_BYTES = 8 * 1024 * 1024;
const AUDIO_TRANSFER_CHUNK_BYTES = 192 * 1024;

const audioContext = new AudioContext({ latencyHint: 'playback' });
const outputGain = audioContext.createGain();
const streamDestination = audioContext.createMediaStreamDestination();
const monitorGain = audioContext.createGain();
let ambientGain = null;
let ambientSource = null;
outputGain.connect(streamDestination);
outputGain.connect(monitorGain).connect(audioContext.destination);
monitorGain.gain.value = 0;

let library = [];
let decoded = new Map();
let loading = null;
let libraryLoadGeneration = 0;
const invalidAudioIds = new Set();
let playing = false;
let generation = 0;
let scheduler = null;
let scheduledUntil = 0;
let cursor = 0;
let trackOffset = 0;
let activeSources = new Set();
let segmentBag = [];
let lastSegmentKey = '';
let lastScheduledItem = null;
let enginePort = null;
let reconnectTimer = 0;
let streamedAudioElement = null;
let streamedAudioSource = null;
let streamedAudioItemId = '';
let streamedAudioUrl = '';
let streamedAudioLoading = null;
const registeredPageAudioIds = new Map();
const pageAudioRegistrations = new Map();
let config = {
  minSec: 4,
  maxSec: 12,
  gapSec: 0,
  volume: 1,
  sinkId: '',
  playMode: 'full',
  voiceSpeed: 1,
  voiceTone: 0,
  ambientEnabled: true,
  ambientLevel: 10,
  monitorEnabled: false
};
let lastPageAudioKey = '';

function ambientVolumeForLevel(level, enabled = true) {
  const normalized = Math.max(0, Math.min(100, Number(level) || 0)) / 100;
  if (!enabled || normalized <= 0) return 0;
  // Mantém o chiado perceptível já nos níveis baixos sem encobrir a narração.
  return .003 + normalized * .035;
}

function ensureAmbientMonitor() {
  if (ambientSource) return;
  const sampleRate = audioContext.sampleRate || 48000;
  const buffer = audioContext.createBuffer(1, sampleRate * 2, sampleRate);
  const samples = buffer.getChannelData(0);
  let softNoise = 0;
  for (let index = 0; index < samples.length; index += 1) {
    const white = Math.random() * 2 - 1;
    softNoise = softNoise * .965 + white * .035;
    samples[index] = white * .68 + softNoise * .32;
  }
  // Fecha o ponto de loop sem um salto brusco na onda, evitando estalos ou
  // a impressão de que o ruído está ligando e desligando.
  const fadeSamples = Math.min(1024, samples.length - 1);
  const loopValue = samples[0];
  for (let index = 0; index < fadeSamples; index += 1) {
    const mix = (index + 1) / fadeSamples;
    const target = samples.length - fadeSamples + index;
    samples[target] = samples[target] * (1 - mix) + loopValue * mix;
  }
  ambientSource = audioContext.createBufferSource();
  ambientSource.buffer = buffer;
  ambientSource.loop = true;
  const highPass = audioContext.createBiquadFilter();
  highPass.type = 'highpass';
  highPass.frequency.value = 380;
  const lowPass = audioContext.createBiquadFilter();
  lowPass.type = 'lowpass';
  lowPass.frequency.value = 6800;
  ambientGain = audioContext.createGain();
  ambientGain.gain.value = 0;
  ambientSource.connect(highPass).connect(lowPass).connect(ambientGain).connect(monitorGain);
  ambientSource.start();
}

function updateAmbientMonitor() {
  ensureAmbientMonitor();
  const volume = ambientVolumeForLevel(config.ambientLevel, playing && config.ambientEnabled !== false);
  ambientGain.gain.setTargetAtTime(volume, audioContext.currentTime, .018);
}

function rememberRegisteredAudio(id) {
  registeredPageAudioIds.delete(id);
  registeredPageAudioIds.set(id, Date.now());
  while (registeredPageAudioIds.size > 12) registeredPageAudioIds.delete(registeredPageAudioIds.keys().next().value);
}

function bytesToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return btoa(binary);
}

async function sendAudioTransferMessage(message) {
  const response = await chrome.runtime.sendMessage(message).catch(() => null);
  if (!response?.ok) {
    throw new Error(response?.waitingForMicrophone
      ? 'Aguardando o microfone virtual da página da LIVE.'
      : response?.error || 'A página da LIVE não recebeu o áudio.');
  }
  return response;
}

async function registerLongAudioInChunks(item, expectedGeneration = null) {
  const stored = await idbGetAudioBlob(item.id);
  if (!stored?.blob) throw new Error(`Áudio longo não encontrado: ${item.name || item.id}`);
  const blob = stored.blob;
  const totalChunks = Math.ceil(blob.size / AUDIO_TRANSFER_CHUNK_BYTES);
  const token = `audio_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
  await sendAudioTransferMessage({
    type: 'LIVEWEL_AUDIO_SOURCE_BEGIN',
    id: item.id,
    token,
    name: item.name || stored.name || '',
    mime: item.mime || stored.mime || blob.type || 'audio/mpeg',
    size: blob.size,
    totalChunks
  });
  for (let index = 0; index < totalChunks; index += 1) {
    if (expectedGeneration != null && expectedGeneration !== generation) {
      throw new Error('Transferência de áudio cancelada.');
    }
    const start = index * AUDIO_TRANSFER_CHUNK_BYTES;
    const buffer = await blob.slice(start, start + AUDIO_TRANSFER_CHUNK_BYTES).arrayBuffer();
    await sendAudioTransferMessage({
      type: 'LIVEWEL_AUDIO_SOURCE_CHUNK',
      id: item.id,
      token,
      index,
      data: bytesToBase64(buffer)
    });
    if ((index + 1) % 4 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
  }
  await sendAudioTransferMessage({
    type: 'LIVEWEL_AUDIO_SOURCE_END',
    id: item.id,
    token,
    totalChunks
  });
}

async function ensurePageAudioRegistered(item, expectedGeneration = null) {
  if (registeredPageAudioIds.has(item.id)) {
    rememberRegisteredAudio(item.id);
    return '';
  }
  if (pageAudioRegistrations.has(item.id)) {
    const dataUrl = await pageAudioRegistrations.get(item.id);
    rememberRegisteredAudio(item.id);
    return dataUrl;
  }
  const registration = (async () => {
    if (isLongAudioTrack(item)) {
      await registerLongAudioInChunks(item, expectedGeneration);
      rememberRegisteredAudio(item.id);
      return '';
    }
    const dataUrl = await dataUrlFromStored(item);
    rememberRegisteredAudio(item.id);
    return dataUrl;
  })();
  pageAudioRegistrations.set(item.id, registration);
  try { return await registration; }
  finally { pageAudioRegistrations.delete(item.id); }
}

async function dataUrlFromStored(item) {
  const stored = await idbGetAudioBlob(item.id);
  if (!stored?.blob) throw new Error(`Áudio não encontrado: ${item.name || item.id}`);
  const blob = stored.blob;
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('Falha ao preparar o áudio.'));
    reader.readAsDataURL(blob);
  });
}

async function syncPageAudio(item, currentTime = 0, startAt = Date.now(), playDurationSec = 0, loop = false, expectedGeneration = null) {
  // startAt faz parte da identidade: repetir o mesmo arquivo/trecho em um novo
  // ciclo é uma reprodução legítima, não uma mensagem duplicada.
  const key = `${item.id}:${Math.round(currentTime * 1000)}:${Math.round(playDurationSec * 1000)}:${loop}:${Math.round(startAt / 10)}`;
  if (key === lastPageAudioKey) return;
  lastPageAudioKey = key;
  const firstDataUrl = await ensurePageAudioRegistered(item, expectedGeneration);
  if (expectedGeneration != null && expectedGeneration !== generation) return;
  await chrome.runtime.sendMessage({
    type: 'LIVEWEL_AUDIO_SOURCE',
    id: item.id,
    name: item.name || '',
    currentTime,
    startAt,
    playDurationSec,
    loop,
    ...(firstDataUrl ? { dataUrl: firstDataUrl } : {})
  }).catch(() => {});
}

function replyStatus(extra = {}) {
  const current = lastScheduledItem || library[cursor] || library[0] || null;
  const longTrackCount = library.filter(isLongAudioTrack).length;
  const status = { ok: true, engineVersion: AUDIO_ENGINE_VERSION, monitoring: config.monitorEnabled === true, playing, loaded: decoded.size + longTrackCount, total: library.length, currentTrackId: current?.id || '', currentTrackName: current?.name || '', ...extra };
  try { enginePort?.postMessage({ kind: 'status', status }); } catch {}
  return status;
}

function isLongAudioTrack(item) {
  return item?.streaming === true
    || Number(item?.duration || 0) >= LONG_AUDIO_MIN_DURATION_SEC
    || Number(item?.size || 0) >= LONG_AUDIO_MIN_BYTES;
}

function currentLongTrack() {
  return config.playMode !== 'segments' && library.length === 1 && isLongAudioTrack(library[0])
    ? library[0]
    : null;
}

function ensureStreamedAudioElement() {
  if (streamedAudioElement) return streamedAudioElement;
  const element = document.createElement('audio');
  element.id = 'livewel-long-audio-stream';
  element.preload = 'auto';
  element.playsInline = true;
  element.style.display = 'none';
  document.body.appendChild(element);
  streamedAudioSource = audioContext.createMediaElementSource(element);
  streamedAudioSource.connect(outputGain);
  streamedAudioElement = element;
  return element;
}

function releaseStreamedAudio({ reset = false, release = false } = {}) {
  if (!streamedAudioElement) return;
  streamedAudioElement.pause();
  if (reset) {
    try { streamedAudioElement.currentTime = 0; } catch {}
  }
  if (!release) return;
  streamedAudioElement.removeAttribute('src');
  streamedAudioElement.load();
  if (streamedAudioUrl) URL.revokeObjectURL(streamedAudioUrl);
  streamedAudioUrl = '';
  streamedAudioItemId = '';
  streamedAudioLoading = null;
}

async function loadStreamedAudio(item) {
  const element = ensureStreamedAudioElement();
  if (streamedAudioItemId === item.id && element.src) return element;
  if (streamedAudioLoading?.id === item.id) return streamedAudioLoading.promise;
  const promise = (async () => {
    const stored = await idbGetAudioBlob(item.id);
    if (!stored?.blob) throw new Error(`Áudio longo não encontrado: ${item.name || item.id}`);
    releaseStreamedAudio({ release: true });
    const blob = stored.blob;
    streamedAudioUrl = URL.createObjectURL(blob);
    streamedAudioItemId = item.id;
    element.src = streamedAudioUrl;
    element.loop = true;
    element.load();
    await Promise.race([
      new Promise((resolve, reject) => {
        element.addEventListener('canplay', resolve, { once: true });
        element.addEventListener('error', () => reject(element.error || new Error('Falha ao abrir o áudio longo.')), { once: true });
      }),
      new Promise((resolve) => setTimeout(resolve, 8000))
    ]);
    return element;
  })();
  streamedAudioLoading = { id: item.id, promise };
  try { return await promise; }
  finally { if (streamedAudioLoading?.promise === promise) streamedAudioLoading = null; }
}

async function startStreamedAudio(item, { restart = false } = {}) {
  const startGeneration = generation;
  const element = await loadStreamedAudio(item);
  if (!playing || startGeneration !== generation) return replyStatus({ streaming: true });
  element.loop = true;
  element.playbackRate = Math.max(.75, Math.min(1.25, Number(config.voiceSpeed) || 1));
  if (restart) {
    try { element.currentTime = 0; } catch {}
  }
  await element.play();
  if (!playing || startGeneration !== generation) {
    element.pause();
    return replyStatus({ streaming: true });
  }
  lastScheduledItem = item;
  await syncPageAudio(item, Number(element.currentTime) || 0, Date.now(), 0, true, startGeneration)
    .catch((error) => console.warn('[LiveWelPro] microfone virtual longo:', error));
  return replyStatus({ streaming: true, currentTrackId: item.id, currentTrackName: item.name || '' });
}

function broadcastAudioConfig() {
  return chrome.runtime.sendMessage({
    type: 'LIVEWEL_AUDIO_CONFIG',
    config: {
      volume: Math.max(0, Math.min(1, Number(config.volume) || 0)),
      voiceSpeed: Math.max(.75, Math.min(1.25, Number(config.voiceSpeed) || 1)),
      voiceTone: Math.max(-100, Math.min(100, Number(config.voiceTone) || 0)),
      ambientEnabled: config.ambientEnabled !== false,
      ambientLevel: Math.max(0, Math.min(100, Number(config.ambientLevel) || 0))
    }
  }).catch(() => null);
}

async function decodeLibraryItem(item, loadGeneration) {
  if (!item?.id || loadGeneration !== libraryLoadGeneration) return false;
  if (isLongAudioTrack(item)) return true;
  if (decoded.has(item.id)) return true;
  if (invalidAudioIds.has(item.id)) return false;
  try {
    const stored = await idbGetAudio(item.id);
    if (loadGeneration !== libraryLoadGeneration) return false;
    if (!stored?.data) {
      invalidAudioIds.add(item.id);
      return false;
    }
    const buffer = await audioContext.decodeAudioData(stored.data.slice(0));
    if (loadGeneration !== libraryLoadGeneration) return false;
    decoded.set(item.id, buffer);
    replyStatus({ libraryLoading: true });
    if (playing) {
      ensureScheduler();
      keepScheduleAlive();
    }
    return true;
  } catch (error) {
    invalidAudioIds.add(item.id);
    console.warn('[LiveWelPro] áudio inválido:', item.name, error);
    return false;
  }
}

async function loadLibrary(items = library) {
  library = Array.isArray(items) ? items.filter((item) => item?.id) : [];
  const loadGeneration = ++libraryLoadGeneration;
  const currentIds = new Set(library.map((item) => item.id));
  for (const id of decoded.keys()) {
    const item = library.find((entry) => entry.id === id);
    if (!currentIds.has(id) || isLongAudioTrack(item)) decoded.delete(id);
  }
  if (streamedAudioItemId && !currentIds.has(streamedAudioItemId)) releaseStreamedAudio({ release: true });
  invalidAudioIds.clear();
  cursor = Math.min(cursor, Math.max(0, library.length - 1));
  trackOffset = 0;
  segmentBag = [];
  lastSegmentKey = '';

  const firstCandidate = library.find((item) => !isLongAudioTrack(item) && !decoded.has(item.id));
  if (!firstCandidate) {
    loading = null;
    return replyStatus({ libraryLoading: false });
  }

  // O primeiro áudio recebe apenas uma pequena janela para ficar pronto. A
  // interface nunca espera a decodificação dos outros 41+ arquivos.
  const firstDecode = decodeLibraryItem(firstCandidate, loadGeneration);
  await Promise.race([
    firstDecode,
    new Promise((resolve) => setTimeout(resolve, 800))
  ]);

  const backgroundLoad = (async () => {
    await firstDecode;
    for (const item of library) {
      if (loadGeneration !== libraryLoadGeneration) return;
      if (item.id === firstCandidate.id || isLongAudioTrack(item) || decoded.has(item.id)) continue;
      await decodeLibraryItem(item, loadGeneration);
    }
    replyStatus({ libraryLoading: false });
  })();
  loading = backgroundLoad;
  backgroundLoad.finally(() => {
    if (loading === backgroundLoad) loading = null;
  });
  return replyStatus({ libraryLoading: true });
}

function stopSources() {
  generation += 1;
  for (const source of activeSources) {
    try { source.stop(); } catch {}
  }
  activeSources.clear();
  releaseStreamedAudio();
  if (scheduler) clearInterval(scheduler);
  scheduler = null;
}

function nextAvailableTrack() {
  if (!library.length) return null;
  for (let attempts = 0; attempts < library.length; attempts++) {
    const item = library[cursor % library.length];
    const buffer = decoded.get(item.id);
    if (buffer) return { item, buffer };
    cursor = (cursor + 1) % library.length;
    trackOffset = 0;
  }
  return null;
}

function advanceTrack() {
  cursor = (cursor + 1) % Math.max(1, library.length);
  trackOffset = 0;
}

function refillSegmentBag() {
  segmentBag = library.filter((item) => decoded.has(item.id)).map((item) => item.id);
  for (let index = segmentBag.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    [segmentBag[index], segmentBag[swap]] = [segmentBag[swap], segmentBag[index]];
  }
  const previousTrackId = lastSegmentKey.split(':')[0];
  if (segmentBag.length > 1 && segmentBag.at(-1) === previousTrackId) {
    [segmentBag[0], segmentBag[segmentBag.length - 1]] = [segmentBag.at(-1), segmentBag[0]];
  }
}

function randomSegmentSelection() {
  if (!segmentBag.length) refillSegmentBag();
  const trackId = segmentBag.pop();
  const item = library.find((entry) => entry.id === trackId);
  const buffer = decoded.get(trackId);
  if (!item || !buffer) return null;
  const min = Math.max(.5, Math.min(Number(config.minSec) || 4, Number(config.maxSec) || 12));
  const max = Math.max(min, Number(config.maxSec) || 12);
  const requested = min + Math.random() * (max - min);
  const duration = Math.min(buffer.duration, requested);
  const maxOffset = Math.max(0, buffer.duration - duration);
  let offset = maxOffset ? Math.random() * maxOffset : 0;
  let key = `${item.id}:${Math.round(offset * 2)}`;
  for (let attempt = 0; key === lastSegmentKey && attempt < 8 && maxOffset > .5; attempt += 1) {
    offset = Math.random() * maxOffset;
    key = `${item.id}:${Math.round(offset * 2)}`;
  }
  lastSegmentKey = key;
  return { item, buffer, offset, duration };
}

function scheduleOne() {
  const chopping = config.playMode === 'segments';
  const selected = chopping ? randomSegmentSelection() : nextAvailableTrack();
  if (!selected) return false;
  const { item, buffer } = selected;
  const offset = chopping ? selected.offset : trackOffset;
  const remaining = Math.max(0, buffer.duration - offset);
  if (remaining < .025) { if (!chopping) advanceTrack(); return scheduleOne(); }
  const duration = chopping ? selected.duration : remaining;
  const when = Math.max(scheduledUntil, audioContext.currentTime + .035);
  const playbackRate = Math.max(.75, Math.min(1.25, Number(config.voiceSpeed) || 1));
  const outputDuration = duration / playbackRate;
  const source = audioContext.createBufferSource();
  const envelope = audioContext.createGain();
  source.buffer = buffer;
  source.playbackRate.value = playbackRate;
  source.connect(envelope).connect(outputGain);

  // A tiny equal-power style overlap removes MP3 boundary clicks without
  // creating an audible pause. At gap=0, the next source is pre-scheduled.
  const edge = Math.min(.008, outputDuration / 4);
  envelope.gain.setValueAtTime(0, when);
  envelope.gain.linearRampToValueAtTime(1, when + edge);
  envelope.gain.setValueAtTime(1, Math.max(when + edge, when + outputDuration - edge));
  envelope.gain.linearRampToValueAtTime(0, when + outputDuration);
  source.start(when, offset, duration);
  const pageStartAt = Date.now() + Math.max(0, when - audioContext.currentTime) * 1000;
  syncPageAudio(item, offset, pageStartAt, outputDuration).catch((error) => console.warn('[LiveWelPro] microfone virtual:', error));
  activeSources.add(source);
  source.onended = () => activeSources.delete(source);

  lastScheduledItem = item;
  if (!chopping) {
    trackOffset += duration;
    const endedTrack = trackOffset >= buffer.duration - .025;
    if (endedTrack) advanceTrack();
  }
  const gap = chopping ? Math.max(0, Number(config.gapSec) || 0) : 0;
  scheduledUntil = when + outputDuration + gap;
  replyStatus({ currentTrackId: item.id, currentTrackName: item.name, scheduledGapSec: gap });
  return true;
}

function fillSchedule() {
  if (!playing) return;
  // Um segundo de antecedência é suficiente e evita ocupar os dois decks com
  // muitos trechos curtos ao mesmo tempo.
  let guard = 0;
  while (scheduledUntil < audioContext.currentTime + 1 && guard++ < 4) {
    if (!scheduleOne()) break;
  }
}

function keepScheduleAlive() {
  if (!playing) return;
  try {
    if (scheduledUntil < audioContext.currentTime - .25) scheduledUntil = audioContext.currentTime + .035;
    fillSchedule();
  } catch (error) {
    console.warn('[LiveWelPro] agendador de áudio recuperado:', error);
    scheduledUntil = audioContext.currentTime + .08;
  }
}

function ensureScheduler() {
  if (scheduler) return;
  scheduler = setInterval(keepScheduleAlive, 100);
}

async function start() {
  const longTrack = currentLongTrack();
  if (!longTrack && !decoded.size && library.length && !loading) void loadLibrary(library);
  await audioContext.resume();
  await broadcastAudioConfig();
  if (playing) {
    if (longTrack) return startStreamedAudio(longTrack);
    ensureScheduler();
    keepScheduleAlive();
    return replyStatus({ recovered: true });
  }
  playing = true;
  updateAmbientMonitor();
  chrome.runtime.sendMessage({ type: 'LIVEWEL_AUDIO_CONTROL', action: 'play' }).catch(() => {});
  if (longTrack) return startStreamedAudio(longTrack, { restart: Number(streamedAudioElement?.currentTime || 0) <= 0 });
  scheduledUntil = audioContext.currentTime + .06;
  keepScheduleAlive();
  ensureScheduler();
  return replyStatus();
}

function stop({ reset = false } = {}) {
  playing = false;
  updateAmbientMonitor();
  stopSources();
  chrome.runtime.sendMessage({ type: 'LIVEWEL_AUDIO_CONTROL', action: reset ? 'stop' : 'pause' }).catch(() => {});
  if (reset) {
    cursor = 0;
    trackOffset = 0;
    releaseStreamedAudio({ reset: true });
  }
  scheduledUntil = 0;
  return replyStatus();
}

async function skip() {
  const wasPlaying = playing;
  const longTrack = currentLongTrack();
  stopSources();
  if (longTrack) {
    try { streamedAudioElement.currentTime = 0; } catch {}
    playing = wasPlaying;
    if (wasPlaying) return startStreamedAudio(longTrack, { restart: true });
    return replyStatus({ streaming: true, currentTrackId: longTrack.id, currentTrackName: longTrack.name || '' });
  }
  advanceTrack();
  scheduledUntil = audioContext.currentTime + .035;
  playing = wasPlaying;
  if (wasPlaying) { keepScheduleAlive(); ensureScheduler(); }
  return replyStatus();
}

async function setSink(sinkId = config.sinkId) {
  // O monitor local é independente do MediaStream usado pela LIVE.
  config.sinkId = String(sinkId || '');
  monitorGain.gain.setTargetAtTime(config.monitorEnabled === true ? 1 : 0, audioContext.currentTime, .012);
  return { ok: true, sinkId: '', monitoring: config.monitorEnabled === true };
}

async function handleAudioEngineMessage(message) {
  const type = String(message?.type || '');
  if (!type.startsWith('OFFSCREEN_AUDIO_')) return { ok: false, error: `Comando de áudio desconhecido: ${type}` };
  if (type.endsWith('_LOAD') || type.endsWith('_LIBRARY')) return loadLibrary(message.library || []);
  if (type.endsWith('_CONFIG')) {
    const schedulingChanged = String(message.playMode ?? config.playMode) !== String(config.playMode)
      || Number(message.minSec ?? message.audioSliceMinSec ?? config.minSec) !== Number(config.minSec)
      || Number(message.maxSec ?? message.audioSliceMaxSec ?? config.maxSec) !== Number(config.maxSec)
      || Number(message.gapSec ?? message.audioGapSec ?? config.gapSec) !== Number(config.gapSec);
    config = {
      ...config,
      minSec: Number(message.minSec ?? message.audioSliceMinSec ?? config.minSec),
      maxSec: Number(message.maxSec ?? message.audioSliceMaxSec ?? config.maxSec),
      gapSec: Number(message.gapSec ?? message.audioGapSec ?? config.gapSec),
      volume: Number(message.volume ?? message.audioVolume ?? config.volume),
      sinkId: String(message.sinkId ?? message.audioSinkId ?? config.sinkId),
      playMode: String(message.playMode ?? config.playMode),
      voiceSpeed: Number(message.voiceSpeed ?? message.audioVoiceSpeed ?? config.voiceSpeed),
      voiceTone: Number(message.voiceTone ?? message.audioVoiceTone ?? config.voiceTone),
      ambientEnabled: message.ambientEnabled ?? message.audioAmbientEnabled ?? config.ambientEnabled,
      ambientLevel: Number(message.ambientLevel ?? message.audioAmbientLevel ?? config.ambientLevel),
      monitorEnabled: message.monitorEnabled ?? message.audioMonitorEnabled ?? config.monitorEnabled
    };
    outputGain.gain.setTargetAtTime(Math.max(0, Math.min(1, config.volume)), audioContext.currentTime, .01);
    if (streamedAudioElement) {
      streamedAudioElement.playbackRate = Math.max(.75, Math.min(1.25, Number(config.voiceSpeed) || 1));
    }
    updateAmbientMonitor();
    await setSink().catch(() => {});
    await broadcastAudioConfig();
    if (playing && schedulingChanged) {
      const longTrack = currentLongTrack();
      stopSources();
      if (longTrack) return startStreamedAudio(longTrack);
      scheduledUntil = audioContext.currentTime + .055;
      keepScheduleAlive();
      ensureScheduler();
    }
    return replyStatus();
  }
  if (type.endsWith('_PLAY') || type.endsWith('_START')) return start();
  if (type.endsWith('_PAUSE')) return stop();
  if (type.endsWith('_STOP') || type.endsWith('_KILL')) return stop({ reset: true });
  if (type.endsWith('_NEXT') || type.endsWith('_SKIP')) return skip();
  if (type.endsWith('_STATUS')) return replyStatus();
  if (type.endsWith('_SINK')) return setSink(message.sinkId);
  return { ok: false, error: `Comando de áudio desconhecido: ${type}` };
}

function connectAudioEnginePort() {
  clearTimeout(reconnectTimer);
  try {
    const port = chrome.runtime.connect({ name: AUDIO_ENGINE_PORT });
    enginePort = port;
    port.onMessage.addListener((message) => {
      if (message?.kind !== 'command' || !message.requestId) return;
      handleAudioEngineMessage(message.payload || {})
        .then((result) => port.postMessage({ kind: 'response', requestId: message.requestId, result }))
        .catch((error) => port.postMessage({ kind: 'response', requestId: message.requestId, result: { ok: false, error: String(error?.message || error) } }));
    });
    port.onDisconnect.addListener(() => {
      if (enginePort === port) enginePort = null;
      registeredPageAudioIds.clear();
      pageAudioRegistrations.clear();
      reconnectTimer = setTimeout(connectAudioEnginePort, 250);
    });
    replyStatus({ ready: true });
  } catch {
    reconnectTimer = setTimeout(connectAudioEnginePort, 500);
  }
}

// Compatibilidade com versões anteriores; o motor 3.1 usa o canal privado acima.
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'LIVEWEL_AUDIO_TARGET_READY') {
    const item = currentLongTrack();
    if (!playing || !item) {
      sendResponse({ ok: true, skipped: true });
      return;
    }
    registeredPageAudioIds.delete(item.id);
    lastPageAudioKey = '';
    syncPageAudio(item, Number(streamedAudioElement?.currentTime) || 0, Date.now(), 0, true, generation)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
  if (message?.source === 'livewel-offscreen' || !String(message?.type || '').startsWith('OFFSCREEN_AUDIO_')) return;
  handleAudioEngineMessage(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});

connectAudioEnginePort();

// Watchdog independente: mantém o loop vivo mesmo se um timer for cancelado
// durante uma retomada do Chrome ou uma troca de configuração.
setInterval(() => {
  if (!playing) return;
  if (audioContext.state !== 'running') audioContext.resume().catch(() => {});
  ensureScheduler();
  keepScheduleAlive();
}, 1000);
