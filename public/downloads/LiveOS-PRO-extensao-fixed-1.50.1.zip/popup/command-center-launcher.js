(() => {
  const PANEL_VERSION = '1.22.0';
  const isTikTok = (url = '') => /https?:\/\/([^/]+\.)?(tiktok\.com|tiktokshop\.com)\//i.test(url);

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  async function sendOpen(tabId, targetTab) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { type: 'LIVEOS_CC_OPEN', tab: targetTab });
      if (response?.version === PANEL_VERSION) return;
      if (response?.ok) throw new Error('PAINEL_DESATUALIZADO');
    } catch (error) {
      if (error?.message === 'PAINEL_DESATUALIZADO') throw new Error('Painel antigo na página. Pressione Ctrl+Shift+R no TikTok e tente novamente.');
      await chrome.scripting.insertCSS({ target: { tabId }, files: ['styles/command-center.css'] });
      await chrome.scripting.executeScript({ target: { tabId }, files: ['src/content/command-center.js'] });
    }
    let lastError;
    for (let attempt = 0; attempt < 8; attempt += 1) {
      try {
        const response = await chrome.tabs.sendMessage(tabId, { type: 'LIVEOS_CC_OPEN', tab: targetTab });
        if (response?.version === PANEL_VERSION) return;
      } catch (error) {
        lastError = error;
        await delay(150);
      }
    }
    throw lastError || new Error('A Central ainda não respondeu. Recarregue a página do TikTok.');
  }

  async function openFromButton(button) {
    const original = button.innerHTML;
    button.disabled = true;
    const targetTab = button.dataset.openTab || 'now';
    button.textContent = targetTab === 'ai' ? 'Abrindo Copiloto IA…' : 'Procurando a live…';
    try {
      const tabs = await chrome.tabs.query({});
      let tab = tabs.find((item) => item.active && isTikTok(item.url));
      if (!tab) tab = tabs.find((item) => isTikTok(item.url));
      if (!tab?.id) throw new Error('Abra a página da live do TikTok Shop primeiro.');
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
      await sendOpen(tab.id, targetTab);
      window.close();
    } catch (error) {
      button.textContent = error?.message || 'Não foi possível abrir';
      setTimeout(() => {
        button.disabled = false;
        button.innerHTML = original;
      }, 2600);
    }
  }

  const playerBtn = document.getElementById('btnOpenPlayerVisible');
  if (playerBtn) {
    playerBtn.addEventListener('click', () => {
      chrome.windows.create({
        url: chrome.runtime.getURL('player/player.html'),
        type: 'popup',
        width: 1080,
        height: 720
      });
      window.close();
    });
  }

  const mobileBtn = document.getElementById('btnOpenMobileControl');
  if (mobileBtn) {
    mobileBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('mobile/index.html') });
      window.close();
    });
  }

  ['btnOpenCommandCenter', 'btnOpenAi', 'btnOpenTelegram'].forEach((id) => {
    const button = document.getElementById(id);
    if (button) button.addEventListener('click', () => openFromButton(button));
  });
})();
