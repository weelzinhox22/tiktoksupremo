# LiveWelPro — guia completo de configuração

Este guia explica como instalar, configurar e usar tanto o painel original quanto a nova **Central Ao Vivo**.

> Importante: teste tudo em uma live de prática antes de usar em uma transmissão real. A extensão ajuda na operação, mas você continua responsável pelo conteúdo, pelos comentários enviados e pelas ações executadas no TikTok.

## 1. Instalação da extensão

1. Abra o Chrome.
2. Digite `chrome://extensions` na barra de endereço.
3. Ative **Modo do desenvolvedor**, no canto superior direito.
4. Clique em **Carregar sem compactação**.
5. Escolha a pasta `LiveOS-PRO-extensao`.
6. Fixe o ícone **LiveWelPro** na barra do Chrome.
7. Depois de atualizar os arquivos da extensão, volte a `chrome://extensions` e clique no botão de **recarregar** da extensão.

Se o Chrome mostrar um erro, abra **Erros** no cartão da extensão e copie a mensagem completa.

## 2. Primeira abertura

1. Entre na página de operação da sua LIVE ou do TikTok Shop.
2. Clique no ícone da extensão.
3. Se aparecer a tela de licença, informe o e-mail e a chave recebida.
4. Clique em **Abrir painel na live** para abrir o painel original.
5. Clique em **Abrir Central Ao Vivo** para abrir a nova central.

Também é possível abrir a nova central pelo botão flutuante **LIVE**, no canto inferior direito da página, ou pelo atalho `Ctrl + Shift + O`.

## 3. Configuração recomendada antes da primeira live

Faça nesta ordem:

1. Configure sua câmera e seu microfone no TikTok LIVE Studio.
2. Abra o painel original e monte a fila de produtos.
3. Configure o pin no modo manual durante os primeiros testes.
4. Cadastre respostas rápidas.
5. Monte o roteiro da apresentação.
6. Adicione áudios e vídeos somente se realmente forem usados.
7. Abra a Central Ao Vivo e cadastre os cartões dos produtos.
8. Confira os termos de segurança e conclua o checklist.
9. Faça uma live de prática de pelo menos 10 minutos.

## 4. Painel original — aba Operar

A aba **Operar** concentra a fila e o controle principal da live.

### Fila de produtos

1. Abra a lista de produtos disponíveis na página do TikTok Shop.
2. Atualize ou sincronize a fila no painel.
3. Organize os produtos na mesma ordem em que pretende apresentá-los.
4. Comece usando o modo de avanço **Manual**.
5. Ao trocar de produto, confirme visualmente no TikTok se o item correto ficou fixado.

### Modos de avanço

- **Manual:** você decide cada troca. É o modo indicado para configurar e testar.
- **Por tempo:** troca de acordo com o tempo definido para o produto.
- **Smart:** usa os sinais disponíveis na página para ajudar na sequência. Supervisione todas as trocas.

### Renovação do pin

O card do produto pode deixar de ficar evidente para o espectador depois de algum tempo. Configure o lembrete ou a renovação conforme sua operação. Na nova Central, o padrão é um aviso visual após 30 segundos.

### Pular produto esgotado

Ative **Pular esgotados** somente depois de conferir se a extensão identifica corretamente o estoque na sua página. Faça um teste com um produto indisponível antes da live.

### Meta de GMV e alertas de venda

1. Em **Operar → Opções avançadas**, informe a meta de GMV.
2. Ative os alertas de venda.
3. Ajuste o volume dos sons.
4. Use o botão de teste, se estiver disponível.

Os números dependem dos dados que o TikTok exibe na página. Use o Seller Center como fonte final de conferência.

### Temporizadores

- Use o contador de live para acompanhar a duração total.
- Configure o temporizador de encerramento apenas como lembrete.
- Não deixe o encerramento automático ativado durante o primeiro teste.

## 5. Painel original — respostas rápidas e comentários

1. Abra **Operar → Opções avançadas**.
2. Cadastre respostas para preço, frete, prazo, garantia, tamanho e estoque.
3. Use frases curtas e compatíveis com a página do produto.
4. Configure palavras de intenção de compra, como `preço`, `frete`, `quero`, `tamanho` e `garantia`.
5. Configure palavras de risco ou concorrentes conforme sua operação.

Recomendação: mantenha o comentário automático desligado até conhecer bem o recurso. Prefira selecionar, revisar e enviar manualmente. Nunca use respostas que direcionem a compra para WhatsApp, Pix, link externo ou outra loja.

## 6. Painel original — roteiro/teleprompter

1. Abra o estúdio de roteiro.
2. Crie um roteiro geral de abertura.
3. Crie roteiros menores vinculados a cada produto.
4. Use esta estrutura:
   - mostrar o produto;
   - explicar o problema que ele resolve;
   - demonstrar o uso;
   - informar preço e condições reais;
   - responder uma objeção;
   - pedir que a pessoa confira o produto fixado.
5. Ajuste a velocidade da rolagem.
6. Ative o acompanhamento do produto somente depois de testar os vínculos.

Evite ler mecanicamente. O roteiro deve apoiar uma apresentação ao vivo e interativa.

## 7. Painel original — aba Vídeo

O caminho recomendado é o estúdio **LiveWelPro**.

1. Abra o LiveWelPro.
2. Adicione os vídeos.
3. No TikTok Shop Streamer, selecione a câmera **LiveWelPro - Câmera Virtual**.
4. Na aba Vídeo da extensão, acompanhe o status e use próximo/anterior.
5. Deixe os vídeos mudos se sua voz entrar pelo microfone do LIVE Studio.
6. Teste transição, Reverse e Drift antes de entrar ao vivo.

O **Player e Overlays** é a central oficial de vídeo do LiveWelPro.

Use vídeos como apoio visual, demonstração ou B-roll enquanto uma pessoa continua presente e interagindo. Não use o recurso para deixar uma transmissão gravada rodando sozinha.

## 8. Painel original — aba Áudio

1. Abra a aba **Áudio**.
2. Adicione os arquivos aceitos pela extensão.
3. Dê nomes fáceis de reconhecer, como `entrada`, `oferta`, `aplausos` e `encerramento`.
4. Ajuste o volume primeiro em nível baixo.
5. Use Play e Stop para testar.
6. Se utilizar VB-Cable, selecione o cabo como saída da extensão e como entrada auxiliar no LIVE Studio.
7. Confirme que sua voz continua audível e sem retorno.

Evite músicas sem direito de uso e não deixe efeitos cobrirem sua voz.

## 9. Painel original — checklist, relatórios e backup

### Checklist

Antes da live, confira câmera, microfone, luz, internet, produtos, preços, estoque, roteiro, moderador e divulgação comercial.

### Relatórios

Gere o relatório ao fim da sessão e confira os números com os dados oficiais do Seller Center.

### Configurações salvas

Use **Salvar setup** para criar perfis como:

- Beleza — manhã;
- Eletrônicos — noite;
- Live curta de lançamento;
- Live longa de catálogo.

Use nomes descritivos e faça backup antes de grandes alterações.

## 10. Nova Central Ao Vivo — visão geral

A Central Ao Vivo fica integrada ao painel original na aba **PRO**. Ela não apaga nem substitui os recursos existentes.

### Aba Agora

1. Clique em **Iniciar sessão** quando começar a operação.
2. Veja a duração, o GMV registrado manualmente e a saúde da página.
3. Ao fixar um produto no TikTok, clique em **Marcar como fixado** na Central.
4. Quando renovar o card no TikTok, clique em **Renovei o pin**.
5. Clique em **+ Venda** para registrar uma venda manual e o valor.
6. Use **Próximo produto** para avançar no planejamento. A troca real no TikTok continua sob sua confirmação.

### Aba Comentários

1. Ative o monitoramento em **Config.**.
2. A Central procura comentários visíveis na página.
3. Ela separa intenção de compra, dúvidas e mensagens que merecem revisão.
4. Clique em **Copiar resposta**.
5. Revise o texto.
6. Cole e envie manualmente no TikTok.
7. Marque como **Resolvido** ou **Ignorar**.

Use **IA responder** quando quiser uma resposta adaptada ao comentário e ao produto atual. A resposta abre na aba IA para revisão; ela não é enviada automaticamente.

A leitura depende da estrutura da página do TikTok e pode precisar de ajustes quando o site mudar.

### Aba Produtos

Cadastre os produtos na ordem da apresentação. Para cada um, informe:

- nome;
- preço ou oferta atual;
- principais benefícios;
- respostas para objeções;
- mini roteiro de demonstração.

Se a fila já estiver montada no painel original, clique em **Importar fila original**. A Central copiará os nomes e preços que conseguir identificar; depois complete benefícios, objeções e mini roteiro.

Use as setas para ordenar. **Marcar como fixado** inicia a medição daquele produto, mas não clica no botão de pin do TikTok.

Use **IA melhorar** para criar um argumento baseado somente nas informações cadastradas. Se faltar um dado, a IA deve marcar `[CONFIRMAR]`.

### Aba IA

A IA foi colocada ao lado de Comentários e Produtos porque são as telas usadas durante a transmissão. Ela oferece:

- resposta curta para comentários;
- melhoria do argumento do produto atual;
- roteiro de 60 a 90 segundos;
- revisão de promessas e termos arriscados;
- plano completo da live;
- pedido livre.

#### Configurar Gemini e Groq

1. Revogue qualquer chave que tenha sido enviada em conversa, mensagem ou captura de tela.
2. Gere chaves novas nos painéis oficiais do Google AI Studio e do Groq Console.
3. Abra **Central Ao Vivo → IA**.
4. Escolha o provedor.
5. Para Groq, mantenha inicialmente o modelo `openai/gpt-oss-20b`.
6. Para Gemini, mantenha inicialmente `gemini-3.6-flash`.
7. Cole a nova chave somente no campo correspondente.
8. Clique em **Salvar IA**.
9. Clique em **Testar conexão**.

Use Groq para respostas rápidas durante a live. Use Gemini para roteiros, planejamento e revisões mais longas. É possível trocar o provedor a qualquer momento.

As chaves ficam em uma área separada do armazenamento local da extensão e não aparecem novamente depois de salvas. Mesmo assim, uma extensão instalada localmente não é um cofre de alta segurança: para distribuição comercial, use um servidor próprio que guarde as chaves e aplique limites por licença.

#### Usar a IA com segurança

1. Marque o produto correto antes de pedir um argumento.
2. Confira se preço, frete, estoque e garantia estão cadastrados.
3. Gere o rascunho.
4. Leia tudo antes de copiar ou aplicar.
5. Substitua qualquer ocorrência de `[CONFIRMAR]` por informação verificada.
6. Nunca envie automaticamente mensagens geradas pela IA.

Os botões **Usar como argumento** e **Usar como roteiro** atualizam o cartão do produto atual. Faça backup antes de substituir muitos textos.

### Aba Roteiro

1. Ajuste os blocos padrão.
2. Informe uma duração aproximada.
3. Clique em **Concluir bloco** ao terminar.
4. Adicione blocos de oferta, perguntas, demonstração ou encerramento.
5. Use **Reiniciar** antes de uma nova sessão.

### Aba Métricas

A Central calcula métricas a partir das ações registradas nela:

- quantas vezes cada produto foi marcado/renovado;
- vendas manuais;
- GMV manual;
- quantidade de comentários captados.

Use **Exportar CSV** para abrir os números em uma planilha. Use **Relatório** para baixar um resumo em texto. Esses dados são operacionais e não substituem os dados oficiais do TikTok.

### Aba Segurança

1. Conclua o checklist.
2. Clique em **Verificar novamente**.
3. Revise todos os termos destacados.
4. Compare cada promessa, preço e benefício com a página e a embalagem do produto.

O verificador procura palavras configuradas; ele não garante conformidade sozinho.

### Aba Config.

- **Aviso de pin:** comece com 30 segundos.
- **Monitorar comentários:** deixe ativo na página da live; desligue se captar elementos incorretos.
- **Atalhos:** deixe ativo somente se não conflitar com o LIVE Studio.
- **Endereço local do LiveWelPro:** mantenha `http://127.0.0.1:18765/`, salvo se o programa usar outra porta.
- **Termos de risco:** personalize para seu catálogo.
- **Backup:** exporte um JSON depois de configurar os produtos e o roteiro.

## 11. Modo moderador

Clique no botão **M** no cabeçalho da Central ou use `Alt + M`.

Nesse modo aparecem somente as telas mais úteis para um assistente:

- comentários;
- produtos.

O apresentador pode continuar usando o painel original enquanto o moderador organiza a fila. A Central aberta no mesmo perfil do Chrome compartilha os dados armazenados pela extensão.

## 12. Atalhos da nova Central

- `Ctrl + Shift + O`: abrir ou fechar a Central.
- `Alt + P`: renovar o cronômetro do produto atual.
- `Alt + N`: avançar para o próximo cartão de produto.
- `Alt + R`: abrir o roteiro.
- `Alt + M`: ativar ou desativar o modo moderador.

Os atalhos não funcionam enquanto você estiver digitando em um campo de texto.

## 13. Rotina recomendada de live

### 30 minutos antes

1. Abra LIVE Studio, TikTok Shop e a extensão.
2. Confira câmera, microfone e conexão.
3. Sincronize produtos e estoque.
4. Importe ou confira os cartões da Central.
5. Revise roteiro e termos de segurança.

### 5 minutos antes

1. Faça o teste final de áudio e vídeo.
2. Abra a Central na aba Agora.
3. Deixe o painel original no modo manual.
4. Confirme o moderador.
5. Conclua o checklist.

### Durante

1. Inicie a sessão na Central.
2. Fixe o produto no TikTok e marque o mesmo produto na Central.
3. Demonstre o produto real e responda comentários.
4. Renove o card quando necessário.
5. Registre vendas apenas se quiser uma prévia operacional.
6. Avance o roteiro sem deixar de interagir ao vivo.

### Depois

1. Encerre a sessão.
2. Exporte relatório e CSV.
3. Compare com o Seller Center.
4. Anote quais argumentos e produtos funcionaram melhor.
5. Exporte um backup JSON.

## 14. Solução de problemas

### A Central não aparece

1. Recarregue a extensão em `chrome://extensions`.
2. Atualize a página do TikTok.
3. Clique novamente em **Abrir Central Ao Vivo**.
4. Confira se a página pertence a `tiktok.com` ou `tiktokshop.com`.

### O painel antigo não aparece

1. Confirme que a licença está ativa.
2. Use **Abrir painel na live**.
3. Atualize a página depois de recarregar a extensão.

### Comentários incorretos aparecem

Desative **Monitorar comentários** em Config., limpe a fila e continue usando a Central manualmente. O TikTok altera a estrutura da página com frequência.

### Companion aparece offline

1. Abra o LiveWelPro.
2. Confira se ele usa a porta `18765`.
3. Permita o programa no Firewall do Windows.
4. Não altere o endereço para um servidor externo.

### Áudio com eco

Desative o monitoramento duplicado. Deixe apenas uma rota do áudio entrando no LIVE Studio e use fones durante o teste.

### Notificação de venda pelo Telegram

1. No Telegram, abra a conversa oficial `@BotFather` e envie `/newbot`.
2. Escolha o nome e o usuário do bot e copie o token entregue pelo BotFather.
3. Abra o bot que você criou, toque em **Iniciar** e envie qualquer mensagem, como `teste`.
4. Na extensão, clique em **Configurar notificações do Telegram**.
5. Cole o token em **Token do bot** e clique em **Localizar chat ID**. A extensão salva o token e preenche o chat automaticamente.
6. Deixe marcadas as opções de venda manual e venda detectada e clique em **Salvar Telegram**.
7. Clique em **Enviar teste**. Confira se a mensagem chegou à conversa.
8. Faça uma live de teste e registre uma venda em **+ Venda** antes de usar em produção.

O aviso automático depende de o painel fornecer `Pedidos` e `GMV` à extensão. Quando esses números não estiverem disponíveis, use **+ Venda** para enviar o aviso manual. A extensão usa um identificador de deduplicação para não reenviar o mesmo aumento detectado.

O token permite enviar mensagens em nome do bot. Não compartilhe nem coloque o token em capturas de tela. Caso ele seja exposto, use `/revoke` no BotFather e gere outro.

## 15. Configuração inicial segura sugerida

- Avanço de produtos: **Manual**.
- Renovação do pin: lembrete de **30 segundos**.
- Comentário automático: **desligado**.
- Encerramento automático: **desligado**.
- Pular esgotados: ativar somente após teste.
- Vídeos: mudos, com voz ao vivo.
- Respostas: copiar, revisar e enviar manualmente.
- Backup: ao final de cada preparação importante.
