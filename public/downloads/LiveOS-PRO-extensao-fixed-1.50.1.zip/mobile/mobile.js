function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  if (navigator.vibrate) navigator.vibrate(50);
  setTimeout(() => toast.classList.remove('show'), 2200);
}

async function sendExtensionMsg(type, payload = {}) {
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
      chrome.runtime.sendMessage({ type, ...payload }).catch(() => {});
    }
    if (typeof chrome !== 'undefined' && chrome.tabs?.query) {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((t) => {
          if (t.id) chrome.tabs.sendMessage(t.id, { type, ...payload }).catch(() => {});
        });
      });
    }
  } catch (e) {
    console.warn(e);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btnRemoteNextProduct')?.addEventListener('click', () => {
    sendExtensionMsg('LIVEOS_REMOTE_NEXT_PRODUCT');
    sendExtensionMsg('PLW_NEXT_TAKE', { force: true });
    showToast('📌 Avançando próximo produto!');
  });

  document.getElementById('btnRemoteNextTake')?.addEventListener('click', () => {
    sendExtensionMsg('PLW_NEXT_TAKE', { force: true });
    showToast('🎬 Trocando take de vídeo!');
  });

  document.getElementById('btnRemoteResetTimer')?.addEventListener('click', () => {
    sendExtensionMsg('LIVEOS_OVERLAY_RESET_TIMER');
    showToast('⏱️ Cronômetro de oferta reiniciado!');
  });

  document.getElementById('btnRemotePlay')?.addEventListener('click', () => {
    sendExtensionMsg('PLW_RESUME_PLAY');
    sendExtensionMsg('AUDIO_PLAY');
    showToast('▶️ Play executado!');
  });

  document.getElementById('btnRemotePause')?.addEventListener('click', () => {
    sendExtensionMsg('PLW_USER_PAUSE');
    sendExtensionMsg('AUDIO_PAUSE');
    showToast('⏸️ Mídia pausada!');
  });

  document.getElementById('btnRemoteSale49')?.addEventListener('click', () => {
    sendExtensionMsg('LIVEOS_REMOTE_MANUAL_SALE', { amount: 49.9 });
    showToast('💰 Venda de R$ 49,90 registrada!');
  });

  document.getElementById('btnRemoteSale99')?.addEventListener('click', () => {
    sendExtensionMsg('LIVEOS_REMOTE_MANUAL_SALE', { amount: 99.9 });
    showToast('💰 Venda de R$ 99,90 registrada!');
  });

  document.getElementById('btnPanicKill')?.addEventListener('click', () => {
    if (confirm('🛑 ATENÇÃO: Deseja realmente abortar e ENCERRAR a transmissão imediatamente para proteger sua conta?')) {
      sendExtensionMsg('LIVEOS_EMERGENCY_KILL', { requestedBy: 'Mobile Painel' });
      showToast('🚨 LIVE ENCERRADA COM SUCESSO!');
    }
  });

  async function updateStats() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage?.local) {
        const data = await chrome.storage.local.get(['gmvCurrent', 'gmvOrders', 'liveOnAir']);
        if (data) {
          const gmv = Number(data.gmvCurrent || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
          const gmvEl = document.getElementById('mobileGmv');
          const ordersEl = document.getElementById('mobileOrders');
          if (gmvEl) gmvEl.textContent = gmv;
          if (ordersEl) ordersEl.textContent = String(data.gmvOrders || 0);

          const badge = document.getElementById('liveStatusBadge');
          if (badge && data.liveOnAir === false) {
            badge.style.color = '#ef4444';
            badge.style.borderColor = '#ef4444';
            badge.innerHTML = '<span class="status-dot" style="background:#ef4444; box-shadow:0 0 8px #ef4444"></span> FORA DO AR';
          }
        }
      }
    } catch (e) {}
  }

  setInterval(updateStats, 2500);
  updateStats();
});
