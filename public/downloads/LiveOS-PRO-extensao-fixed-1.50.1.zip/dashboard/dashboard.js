import { idbPutAudio, idbGetAudioMetadata, idbDeleteAudio, idbListAudioIds } from '../src/shared/idb.js';

const $ = (id) => document.getElementById(id);
const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const pages = {
  operation: ['Operação', 'Tudo que importa durante a transmissão.'],
  studio: ['Estúdio', 'A saída de vídeo e os overlays em uma única tela.'],
  audio: ['Áudio', 'Microfone virtual contínuo e sem pausas.'],
  automation: ['Automação', 'Reinício programado e reposição de produtos.'],
  telegram: ['Telegram', 'Notificações, alertas e controle remoto.'],
  pro: ['PRO', 'Conta, conexão e diagnóstico da transmissão.']
};
let state = {};
let snapshot = { metrics: {}, products: [], onAir: null };
let audioLibrary = [];
let audioImporting = false;
let audioImportProgress = null;
let audioRecoveryDone = false;
let toastTimer = 0;
let audioConfigTimer = 0;
let localControlBusy = false;
let localTelemetry = {};
let previousFrameSample = { count: 0, at: 0 };
let browserDeliveryFps = 0;
const LOCAL_APP_URL = 'http://127.0.0.1:18765/';
const LONG_AUDIO_MIN_DURATION_SEC = 5 * 60;
const LONG_AUDIO_MIN_BYTES = 8 * 1024 * 1024;

function isLongAudioTrack(track) {
  return track?.streaming === true
    || Number(track?.duration || 0) >= LONG_AUDIO_MIN_DURATION_SEC
    || Number(track?.size || 0) >= LONG_AUDIO_MIN_BYTES;
}

function inspectAudioFile(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const element = document.createElement('audio');
    let settled = false;
    const finish = (duration = 0) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      element.removeAttribute('src');
      element.load();
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(duration) ? Math.max(0, duration) : 0);
    };
    const timer = setTimeout(() => finish(0), 6000);
    element.preload = 'metadata';
    element.onloadedmetadata = () => finish(Number(element.duration));
    element.onerror = () => finish(0);
    element.src = url;
    element.load();
  });
}

function formatTrackDuration(seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  if (!total) return '';
  const minutes = Math.floor(total / 60);
  const remaining = total % 60;
  return `${minutes}:${String(remaining).padStart(2, '0')}`;
}

function privateRpc(portName, payload, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    const port = chrome.runtime.connect({ name: portName });
    const requestId = `dash_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { port.disconnect(); } catch {}
      callback(value);
    };
    const timer = setTimeout(() => finish(reject, new Error('O serviço demorou para responder.')), timeoutMs);
    port.onMessage.addListener((message) => {
      if (message?.requestId === requestId) finish(resolve, message);
    });
    port.onDisconnect.addListener(() => {
      if (!settled) finish(reject, new Error(chrome.runtime.lastError?.message || 'O canal do serviço foi encerrado.'));
    });
    try { port.postMessage({ requestId, ...payload }); }
    catch (error) { finish(reject, error); }
  });
}

const telegramRpc = (payload) => privateRpc('livewel-telegram-rpc-v1', payload);
const audioRpc = (command, config) => privateRpc('livewel-dashboard-audio-rpc-v1', { command, config }, command === 'PLAY' ? 60000 : 12000);
const localControl = (type, payload = {}) => chrome.runtime.sendMessage({ type, url: state.liveosCommandCenterV1?.settings?.companionUrl || LOCAL_APP_URL, ...payload });

function showToast(message, error = false) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.toggle('error', error);
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function navigate(name) {
  document.querySelectorAll('.nav').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
  document.querySelectorAll('.view').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
  $('pageTitle').textContent = pages[name][0];
  $('pageDescription').textContent = pages[name][1];
}

function formatDuration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor(total % 3600 / 60);
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

function productName(product) {
  return product?.name || product?.title || product?.productName || `Produto ${product?.id || ''}`.trim();
}

function renderProducts() {
  const products = snapshot.products.length ? snapshot.products : (Array.isArray(state.playlist) ? state.playlist : []);
  $('productCount').textContent = String(products.length);
  $('productList').innerHTML = products.length ? products.map((product, index) => `
    <div class="product-row"><span>${index + 1}</span><div><strong>${escapeHtml(productName(product))}</strong><small>${escapeHtml(product.id || product.productId || product.shopId || 'Produto da sacola')}</small></div><button data-pin="${index + 1}">Fixar</button></div>`).join('') : '<div class="empty">Abra o TikTok Shop LIVE e importe seus produtos.</div>';
}

function escapeHtml(value) {
  return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

function setDot(id, mode) {
  const dot = $(id);
  dot.classList.toggle('online', mode === 'online');
  dot.classList.toggle('offline', mode === 'offline');
}

function renderHealth(stored) {
  const frameAt = Number(stored.livewelCameraFrameAt || 0);
  const rtcActive = stored.livewelCameraTransport === 'webrtc';
  const playerFresh = stored.livewelPlayerOnline && Date.now() - Number(stored.livewelPlayerUpdatedAt || 0) < 10000;
  const playerPlaying = playerFresh && Boolean(stored.livewelPlayerPlaying);
  const videoFresh = frameAt > 0 && Date.now() - frameAt < 3500;
  const frameCount = Number(stored.livewelCameraFrames || 0);
  if (previousFrameSample.at && frameCount >= previousFrameSample.count) {
    browserDeliveryFps = Math.max(0, Math.min(60, (frameCount - previousFrameSample.count) * 1000 / Math.max(1, Date.now() - previousFrameSample.at)));
  }
  previousFrameSample = { count: frameCount, at: Date.now() };
  const audio = stored.livewelAudioStatus || {};
  const audioReady = audio.playing && Date.now() - Number(audio.updatedAt || 0) < 15000;
  $('cameraStatus').textContent = videoFresh
    ? rtcActive ? 'Vídeo fluido entregue ao TikTok' : 'Vídeo entregue ao TikTok'
    : playerPlaying ? 'Player transmitindo, conectando ao TikTok' : playerFresh ? 'Player pronto, transmissão pausada' : 'Câmera aguardando';
  $('cameraDetail').textContent = videoFresh
    ? rtcActive
      ? 'WebRTC local · codec de vídeo em tempo real · alvo de 30 FPS'
      : `${Number(stored.livewelCameraFrames || 0).toLocaleString('pt-BR')} quadros entregues (modo compatível)`
    : playerPlaying
      ? (stored.livewelCameraError || 'Atualize a página da LIVE se a fonte ainda não apareceu')
      : playerFresh
        ? 'Pressione Iniciar transmissão no Estúdio'
        : 'Abra o Estúdio, dê Play e atualize a página da LIVE';
  $('audioStatus').textContent = audioReady ? 'Áudio contínuo ativo' : audio.loaded ? 'Áudio carregado' : 'Áudio aguardando';
  $('audioDetail').textContent = audioReady ? (audio.currentTrackName || 'Sequência em reprodução') : audio.loaded ? 'Pressione Reproduzir' : 'Importe suas faixas';
  setDot('cameraDot', videoFresh ? 'online' : playerFresh ? '' : 'offline');
  setDot('audioDot', audioReady ? 'online' : audio.loaded ? '' : 'offline');
  $('sideStatus').textContent = videoFresh ? 'Saída de vídeo ativa' : snapshot.onAir ? 'LIVE detectada' : 'TikTok aguardando';
  $('sideDetail').textContent = videoFresh ? 'Quadros entregues à página da LIVE' : 'Abra a LIVE e inicie o Estúdio';
  setDot('sideDot', videoFresh ? 'online' : snapshot.onAir === false ? 'offline' : '');
  $('lastFrame').textContent = frameAt ? new Date(frameAt).toLocaleTimeString('pt-BR') : '—';
  const actualFps = Number(localTelemetry.actualFps ?? localTelemetry.fps ?? browserDeliveryFps);
  $('studioFps').textContent = `${actualFps > 0 ? actualFps.toFixed(1).replace('.', ',') : '—'} / 30`;
  const drops = Number(localTelemetry.droppedFrames ?? localTelemetry.drops ?? 0);
  const restarts = Number(localTelemetry.restartCount ?? localTelemetry.restarts ?? 0);
  $('studioTelemetryDetail').textContent = `Drops: ${drops.toLocaleString('pt-BR')} · reinícios: ${restarts.toLocaleString('pt-BR')}`;
}

async function refreshLocalControls(showMessage = false) {
  if (localControlBusy) return;
  localControlBusy = true;
  try {
    const [telemetryResponse, scenesResponse] = await Promise.all([
      localControl('LIVEOS_CC_TELEMETRY').catch((error) => ({ ok: false, error: String(error) })),
      localControl('LIVEOS_CC_OBS_SCENES').catch((error) => ({ ok: false, error: String(error) }))
    ]);
    if (telemetryResponse?.ok) {
      localTelemetry = telemetryResponse.data || {};
      $('studioControlStatus').textContent = `${localTelemetry.width || 720}×${localTelemetry.height || 1280} · câmera ${localTelemetry.cameraConnected === false ? 'desconectada' : 'ativa'} · watchdog ${state.liveosCommandCenterV1?.settings?.cameraWatchdogEnabled === false ? 'desligado' : 'ligado'}`;
      renderHealth(state);
    } else {
      $('studioControlStatus').textContent = telemetryResponse?.error || 'Abra o LiveStudioCAM na porta 18765.';
    }
    if (scenesResponse?.ok) {
      const data = scenesResponse.data || {};
      const scenes = Array.isArray(data.scenes) ? data.scenes : [];
      const current = String(data.current || '');
      $('obsScene').innerHTML = scenes.length ? scenes.map((scene) => `<option value="${escapeHtml(scene)}" ${scene === current ? 'selected' : ''}>${escapeHtml(scene)}</option>`).join('') : '<option value="">Nenhuma cena encontrada</option>';
      $('obsControlStatus').textContent = scenes.length ? `${scenes.length} cena(s) · atual: ${current || 'não informada'}` : 'OBS não conectado ou sem cenas.';
    } else $('obsControlStatus').textContent = scenesResponse?.error || 'OBS não conectado.';
    if (showMessage) showToast(telemetryResponse?.ok ? 'Telemetria e cenas atualizadas.' : telemetryResponse?.error || 'LiveStudioCAM offline.', !telemetryResponse?.ok);
  } finally { localControlBusy = false; }
}

function audioToneLabel(value) {
  const tone = Number(value) || 0;
  if (tone <= -67) return 'Bem grave';
  if (tone <= -22) return 'Grave';
  if (tone >= 67) return 'Bem agudo';
  if (tone >= 22) return 'Agudo';
  return 'Neutro';
}

function syncAudioControls(stored) {
  const values = {
    audioVolume: Math.round(Number(stored.audioVolume ?? .9) * 100),
    audioSpeed: Math.round(Number(stored.audioVoiceSpeed ?? 1) * 100),
    audioTone: Math.round(Number(stored.audioVoiceTone ?? 0)),
    audioAmbientLevel: Math.round(Number(stored.audioAmbientLevel ?? 10)),
    audioSegmentMin: Number(stored.audioSegmentMinSec ?? 4),
    audioSegmentMax: Number(stored.audioSegmentMaxSec ?? 12),
    audioGap: Number(stored.audioGapSec ?? 1)
  };
  for (const [id, value] of Object.entries(values)) {
    if (document.activeElement !== $(id)) $(id).value = String(value);
  }
  $('audioAmbientEnabled').checked = stored.audioAmbientEnabled !== false;
  $('audioMonitorEnabled').checked = stored.audioMonitorEnabled === true;
  $('audioSegmentsEnabled').checked = stored.audioPlayMode === 'segments';
  $('audioVolumeValue').textContent = `${values.audioVolume}%`;
  $('audioSpeedValue').textContent = `${(values.audioSpeed / 100).toFixed(2).replace('.', ',')}×`;
  $('audioToneValue').textContent = audioToneLabel(values.audioTone);
  $('audioAmbientValue').textContent = `${values.audioAmbientLevel}%`;
  $('audioSegmentMinNumber').value = String(values.audioSegmentMin);
  $('audioSegmentMaxNumber').value = String(values.audioSegmentMax);
  $('audioGapNumber').value = String(values.audioGap);
  $('audioSegmentMinValue').textContent = `${values.audioSegmentMin}s`;
  $('audioSegmentMaxValue').textContent = `${values.audioSegmentMax}s`;
  $('audioGapValue').textContent = `${values.audioGap}s`;
  $('audioSegmentSettings').hidden = !$('audioSegmentsEnabled').checked;
  $('audioAmbientLevel').disabled = !$('audioAmbientEnabled').checked;
}

function renderState(stored = {}) {
  state = { ...state, ...stored };
  const metrics = { ...snapshot.metrics };
  const gmv = Number(metrics.gmv ?? state.gmvCurrent ?? 0);
  const orders = Number(metrics.orders ?? state.gmvOrders ?? 0);
  const liveSec = Number(metrics.liveSec ?? state.liveSec ?? 0);
  $('gmv').textContent = money.format(Number.isFinite(gmv) ? gmv : 0);
  $('orders').textContent = String(Number.isFinite(orders) ? orders : 0);
  $('liveTime').textContent = formatDuration(liveSec);
  $('onAir').textContent = snapshot.onAir ? 'LIVE detectada' : 'LIVE não detectada';
  $('pinnedProduct').textContent = state.currentTitle ? `Fixado: ${state.currentTitle}` : 'Controle pela posição da sacola';
  $('keepFirst').checked = Boolean(state.livewelPinFirstWithoutScroll);
  $('licensePlan').textContent = state.licensePlan || state.licenseTier || 'PRO';
  $('licenseStatus').textContent = state.licenseLocked ? 'Licença bloqueada' : state.licenseValid === false ? 'Licença não validada' : 'Licença disponível';
  $('playerHealth').textContent = state.livewelPlayerOnline && Date.now() - Number(state.livewelPlayerUpdatedAt || 0) < 10000 ? 'Online' : 'Offline';
  $('playerTake').textContent = state.livewelPlayerTake || 'Nenhum take ativo';
  renderProducts();
  renderHealth(state);
  syncAudioControls(state);
}

async function recoverAudioLibrary(library) {
  const recovered = [...library];
  const knownIds = new Set(recovered.map((item) => item?.id).filter(Boolean));
  const storedIds = await idbListAudioIds().catch(() => []);
  for (const id of storedIds) {
    if (knownIds.has(id)) continue;
    const stored = await idbGetAudioMetadata(id).catch(() => null);
    if (!stored?.id) continue;
    recovered.push({
      id: stored.id,
      name: stored.name || 'Áudio recuperado',
      mime: stored.mime || 'audio/mpeg',
      size: Number(stored.size) || 0,
      duration: Number(stored.duration) || 0,
      streaming: Number(stored.duration) >= LONG_AUDIO_MIN_DURATION_SEC || Number(stored.size) >= LONG_AUDIO_MIN_BYTES
    });
    knownIds.add(id);
  }
  return recovered;
}

async function getState() {
  const response = await chrome.runtime.sendMessage({ type: 'GET_STATE' }).catch(() => null);
  const stored = response?.state || response || await chrome.storage.local.get(null);
  renderState(stored);
  if (!audioImporting) {
    let nextLibrary = Array.isArray(stored.audioLibrary) ? stored.audioLibrary : [];
    if (!audioRecoveryDone) {
      audioRecoveryDone = true;
      const recovered = await recoverAudioLibrary(nextLibrary);
      if (recovered.length !== nextLibrary.length) {
        nextLibrary = recovered;
        await chrome.storage.local.set({ audioLibrary: recovered });
      }
    }
    audioLibrary = nextLibrary;
    renderAudio();
  }
}

async function command(action, payload = {}) {
  return chrome.runtime.sendMessage({ type: 'LIVEWEL_DASH_COMMAND', action, payload });
}

async function refresh(showMessage = false) {
  const result = await command('snapshot').catch((error) => ({ ok: false, error: String(error) }));
  if (result?.ok) snapshot = result;
  await getState();
  void refreshLocalControls(false);
  if (showMessage) showToast(result?.ok ? 'Dados atualizados.' : result?.error || 'TikTok ainda não está aberto.', !result?.ok);
}

function renderAudio() {
  const min = Number(state.audioSegmentMinSec ?? 4);
  const max = Number(state.audioSegmentMaxSec ?? 12);
  const gap = Number(state.audioGapSec ?? 1);
  const singleLongTrack = audioLibrary.length === 1 && isLongAudioTrack(audioLibrary[0]);
  const mode = singleLongTrack
    ? 'faixa longa otimizada · loop infinito do início ao fim'
    : state.audioPlayMode === 'segments'
    ? `trechos aleatórios de ${min}s a ${max}s · pausa ${gap}s · loop infinito`
    : 'faixas completas · loop infinito sem pausa';
  $('audioSummary').textContent = audioImportProgress
    ? `Importando ${audioImportProgress.processed}/${audioImportProgress.total} · ${audioLibrary.length} faixa(s) salvas`
    : audioLibrary.length ? `${audioLibrary.length} faixa(s) · ${mode}` : 'Nenhuma faixa importada';
  $('audioList').innerHTML = audioLibrary.length ? audioLibrary.map((track, index) => {
    const longTrack = isLongAudioTrack(track);
    const details = [track.size ? `${(track.size / 1048576).toFixed(1)} MB` : 'Áudio LiveWelPro', formatTrackDuration(track.duration), longTrack ? 'faixa longa · memória otimizada' : ''].filter(Boolean).join(' · ');
    return `<div class="audio-row${longTrack ? ' is-long' : ''}"><span>${index + 1}</span><div><strong>${escapeHtml(track.name)}</strong><small>${escapeHtml(details)}</small></div><button class="text-danger" data-audio-remove="${escapeHtml(track.id)}">Remover</button></div>`;
  }).join('') : '<div class="empty">Importe MP3, WAV, M4A ou OGG.</div>';
  $('clearAudioQueue').disabled = audioImporting || !audioLibrary.length;
  if (singleLongTrack) {
    $('audioSegmentsEnabled').checked = false;
    $('audioSegmentsEnabled').disabled = true;
    $('audioSegmentsEnabled').title = 'Faixas longas são reproduzidas completas para evitar consumo excessivo de memória.';
    $('audioSegmentSettings').hidden = true;
  } else {
    $('audioSegmentsEnabled').disabled = false;
    $('audioSegmentsEnabled').removeAttribute('title');
  }
}

async function uploadAudio(files) {
  const selectedFiles = Array.from(files || []);
  if (!selectedFiles.length) return;
  const stored = await chrome.storage.local.get('audioLibrary');
  const merged = new Map();
  for (const item of [...(stored.audioLibrary || []), ...audioLibrary]) {
    if (item?.id) merged.set(item.id, item);
  }
  const nextLibrary = [...merged.values()];
  const failures = [];
  let imported = 0;
  let longImported = 0;
  audioImporting = true;
  try {
    for (let index = 0; index < selectedFiles.length; index += 1) {
      const file = selectedFiles[index];
      try {
        if (!file?.size) throw new Error('arquivo vazio');
        const unique = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}_${index.toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
        const id = `aud_${unique}`;
        const duration = await inspectAudioFile(file);
        const streaming = duration >= LONG_AUDIO_MIN_DURATION_SEC || file.size >= LONG_AUDIO_MIN_BYTES;
        await idbPutAudio(id, file, { name: file.name, mime: file.type, size: file.size, duration });
        nextLibrary.push({ id, name: file.name, mime: file.type || 'audio/mpeg', size: file.size, duration, streaming });
        imported += 1;
        if (streaming) longImported += 1;
      } catch (error) {
        failures.push({ name: file?.name || `Arquivo ${index + 1}`, error: String(error?.message || error) });
      }
      audioLibrary = [...nextLibrary];
      audioImportProgress = { processed: index + 1, total: selectedFiles.length };
      renderAudio();
      if ((index + 1) % 4 === 0 || index === selectedFiles.length - 1) {
        await chrome.storage.local.set({ audioLibrary: [...nextLibrary] }).catch(() => {});
      }
    }
  } finally {
    audioLibrary = [...nextLibrary];
    audioImporting = false;
    audioImportProgress = null;
  }
  const libraryPatch = { audioLibrary: [...nextLibrary] };
  if (longImported) {
    libraryPatch.audioPlayMode = 'full';
    state.audioPlayMode = 'full';
  }
  await chrome.storage.local.set(libraryPatch);
  renderAudio();
  if (failures.length) {
    const names = failures.slice(0, 3).map((item) => item.name).join(', ');
    showToast(`${imported} áudio(s) importado(s); ${failures.length} falharam (${names}).`, true);
  } else {
    showToast(longImported
      ? `${imported} áudio(s) importado(s). ${longImported} faixa(s) longa(s) pronta(s) para loop direto.`
      : `${imported} áudio(s) importado(s).`);
  }
}

async function clearAudioQueue() {
  if (audioImporting || !audioLibrary.length) return;
  if (!confirm(`Remover os ${audioLibrary.length} áudio(s) da fila e do armazenamento?`)) return;
  $('clearAudioQueue').disabled = true;
  await audioRpc('PAUSE').catch(() => null);
  const storedIds = await idbListAudioIds().catch(() => []);
  const ids = [...new Set([...storedIds, ...audioLibrary.map((item) => item?.id).filter(Boolean)])];
  try {
    await Promise.all(ids.map((id) => idbDeleteAudio(id)));
    audioLibrary = [];
    await chrome.storage.local.set({ audioLibrary: [] });
    await audioRpc('RELOAD').catch(() => null);
    $('audioNow').textContent = 'Aguardando faixas';
    $('audioPlaybackStatus').textContent = 'Fila vazia. Importe um áudio para iniciar uma nova reprodução.';
    renderAudio();
    showToast('Fila de áudio limpa por completo.');
  } catch (error) {
    renderAudio();
    showToast(`Não foi possível limpar toda a fila: ${String(error?.message || error)}`, true);
  }
}

async function audioCommand(name) {
  const result = await audioRpc(name).catch((error) => ({ ok: false, error: String(error?.message || error) }));
  if (!result?.ok) return showToast(result?.error || 'Não foi possível controlar o áudio.', true);
  $('audioNow').textContent = result.currentTrackName || (name === 'PLAY' ? 'Sequência em reprodução' : 'Áudio pausado');
  const monitoring = $('audioMonitorEnabled').checked;
  $('audioPlaybackStatus').textContent = result.playing
    ? monitoring ? 'Enviado à LIVE e reproduzido também neste computador.' : 'Enviado somente à LIVE; o monitor local permanece desligado.'
    : 'Pausado. A biblioteca permanece carregada e o PC fica em silêncio.';
  showToast(result.playing ? 'Áudio contínuo iniciado.' : 'Áudio atualizado.');
}

function scheduleAudioConfig() {
  const settings = {
    audioVolume: Number($('audioVolume').value) / 100,
    audioVoiceSpeed: Number($('audioSpeed').value) / 100,
    audioVoiceTone: Number($('audioTone').value),
    audioAmbientEnabled: $('audioAmbientEnabled').checked,
    audioAmbientLevel: Number($('audioAmbientLevel').value),
    audioMonitorEnabled: $('audioMonitorEnabled').checked,
    audioPlayMode: $('audioSegmentsEnabled').checked ? 'segments' : 'full',
    audioSegmentMinSec: Number($('audioSegmentMin').value),
    audioSegmentMaxSec: Number($('audioSegmentMax').value),
    audioGapSec: Number($('audioGap').value)
  };
  chrome.storage.local.set(settings);
  clearTimeout(audioConfigTimer);
  audioConfigTimer = setTimeout(() => {
    audioRpc('CONFIG', settings).catch(() => {});
  }, 180);
}

function syncRangeNumber(rangeId, numberId, outputId, changedId) {
  const range = $(rangeId);
  const number = $(numberId);
  const changed = $(changedId);
  let value = Number(changed.value);
  value = Math.max(Number(changed.min), Math.min(Number(changed.max), value));
  if (rangeId === 'audioSegmentMin' && value > Number($('audioSegmentMax').value)) {
    $('audioSegmentMax').value = String(value);
    $('audioSegmentMaxNumber').value = String(value);
    $('audioSegmentMaxValue').textContent = `${value}s`;
  }
  if (rangeId === 'audioSegmentMax' && value < Number($('audioSegmentMin').value)) {
    $('audioSegmentMin').value = String(value);
    $('audioSegmentMinNumber').value = String(value);
    $('audioSegmentMinValue').textContent = `${value}s`;
  }
  range.value = String(value);
  number.value = String(value);
  $(outputId).textContent = `${value}s`;
  scheduleAudioConfig();
}

async function loadCycle() {
  const stored = await chrome.storage.local.get('livewelCycleConfig');
  const config = stored.livewelCycleConfig || {};
  $('cycleEnabled').checked = Boolean(config.enabled);
  $('cycleHours').value = Number(config.hours ?? 2);
  $('cycleMinutes').value = Number(config.minutes ?? 0);
  $('cycleProducts').value = config.products || '';
  $('cycleState').textContent = config.lastStatus || (config.enabled ? 'Programado' : 'Desativado');
  $('cycleError').textContent = config.lastError || 'Nenhum erro registrado.';
}

const DEFAULT_AUTO_COMMENTS = [
  'Verifique o carrinho e confira o produto fixado.',
  'Qual dúvida você tem sobre o produto?',
  'Confira as variações e condições disponíveis no carrinho.',
  'Quem chegou agora pode perguntar sobre tamanho, cor ou uso.'
];

async function loadLiveAutomations() {
  const stored = await chrome.storage.local.get(['liveosCommandCenterV1', 'livewelModerationConfig', 'livewelModerationLog', 'livewelCommentPublishStatus', 'livewelAutoReplyStatus', 'livewelCameraWatchdogStatus', 'livewelHighlightStatus']);
  const settings = stored.liveosCommandCenterV1?.settings || {};
  const enabled = settings.engagementReminderEnabled === true && settings.engagementAutoPublish === true;
  const min = Math.max(60, Number(settings.engagementMinSec) || 60);
  const max = Math.max(min, Number(settings.engagementMaxSec) || 120);
  $('autoCommentsEnabled').checked = enabled;
  $('autoCommentsMin').value = String(min);
  $('autoCommentsMax').value = String(max);
  $('autoCommentsPreset').value = min === 60 && max === 120 ? 'max_safety' : min === 120 && max === 300 ? 'super_safe' : 'custom';
  $('autoCommentsTemplates').value = String(settings.engagementTemplates || DEFAULT_AUTO_COMMENTS.join('\n'));
  $('autoCommentsStatus').textContent = enabled ? `Ativo · próximo comentário entre ${min}s e ${max}s` : 'Desativado';
  const publishStatus = stored.livewelCommentPublishStatus;
  if (publishStatus?.at) $('autoCommentsStatus').textContent += ` · último ${publishStatus.ok ? 'enviado' : 'erro'} às ${new Date(publishStatus.at).toLocaleTimeString('pt-BR')}`;
  $('autoRepliesEnabled').checked = settings.autoReplyEnabled === true;
  $('autoRepliesMin').value = String(Math.max(15, Number(settings.autoReplyMinSec) || 20));
  const replyCategories = new Set(String(settings.autoReplyCategories || 'compra,duvida').split(','));
  $('autoReplyCompra').checked = replyCategories.has('compra');
  $('autoReplyDuvida').checked = replyCategories.has('duvida');
  $('autoReplyGeral').checked = replyCategories.has('geral');
  $('autoHighlightEnabled').checked = settings.autoHighlightEnabled === true;
  $('cameraWatchdogEnabled').checked = settings.cameraWatchdogEnabled !== false;
  const replyStatus = stored.livewelAutoReplyStatus;
  const watchdogStatus = stored.livewelCameraWatchdogStatus;
  const highlightStatus = stored.livewelHighlightStatus;
  $('automationExtrasStatus').textContent = [
    replyStatus?.at ? `Resposta ${replyStatus.ok ? 'enviada' : 'falhou'} ${new Date(replyStatus.at).toLocaleTimeString('pt-BR')}` : '',
    watchdogStatus?.at ? `watchdog ${watchdogStatus.ok ? 'reiniciou a câmera' : 'falhou'}` : '',
    highlightStatus?.at ? `destaque ${highlightStatus.ok ? 'salvo' : 'falhou'}` : ''
  ].filter(Boolean).join(' · ') || 'Proteção pronta.';
  $('videoProfile').value = settings.captureProfile === 'low' ? 'low' : 'performance';

  const moderation = stored.livewelModerationConfig || {};
  $('competitorBlockEnabled').checked = moderation.enabled === true;
  $('competitorKeywords').value = (Array.isArray(moderation.keywords) && moderation.keywords.length ? moderation.keywords : ['achadinhos', 'shop', 'mais barato', 'ofertas']).join('\n');
  $('blockedProfiles').value = (Array.isArray(moderation.profiles) ? moderation.profiles : []).map((profile) => profile.startsWith('@') ? profile : `@${profile}`).join('\n');
  const lastLog = Array.isArray(stored.livewelModerationLog) ? stored.livewelModerationLog.at(-1) : null;
  $('moderationStatus').textContent = lastLog
    ? `${lastLog.ok ? 'Bloqueado' : 'Não localizado'}: ${lastLog.author} · ${new Date(lastLog.at).toLocaleTimeString('pt-BR')}`
    : 'Aguardando perfis entrarem na LIVE.';
}

async function saveAutoComments() {
  const enabled = $('autoCommentsEnabled').checked;
  const min = Math.max(60, Math.min(3600, Number($('autoCommentsMin').value) || 60));
  const max = Math.max(min, Math.min(3600, Number($('autoCommentsMax').value) || 120));
  const templates = $('autoCommentsTemplates').value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 100);
  if (enabled && !templates.length) return showToast('Cadastre pelo menos um comentário.', true);
  const stored = await chrome.storage.local.get('liveosCommandCenterV1');
  const current = stored.liveosCommandCenterV1 || { version: 1 };
  await chrome.storage.local.set({
    liveosCommandCenterV1: {
      ...current,
      settings: {
        ...(current.settings || {}),
        engagementReminderEnabled: enabled,
        engagementAutoPublish: enabled,
        engagementMinSec: min,
        engagementMaxSec: max,
        engagementTemplates: templates.join('\n')
      }
    },
    autoCommentEnabled: false,
    autoCommentTemplates: templates,
    autoCommentMinSec: min,
    autoCommentMaxSec: max
  });
  await loadLiveAutomations();
  showToast(enabled ? 'Comentários automáticos ativados.' : 'Comentários automáticos desativados.');
}

async function testAutoComment() {
  const text = $('autoCommentsTemplates').value.split(/\r?\n/).map((line) => line.trim()).find(Boolean);
  if (!text) return showToast('Cadastre pelo menos um comentário para testar.', true);
  const result = await command('send-comment', { text }).catch((error) => ({ ok: false, error: String(error) }));
  await loadLiveAutomations();
  showToast(result?.ok ? 'Comentário de teste publicado e confirmado.' : result?.error || 'O TikTok não confirmou o comentário.', !result?.ok);
}

async function saveAutomationExtras() {
  const stored = await chrome.storage.local.get('liveosCommandCenterV1');
  const current = stored.liveosCommandCenterV1 || { version: 1 };
  const categories = [['autoReplyCompra', 'compra'], ['autoReplyDuvida', 'duvida'], ['autoReplyGeral', 'geral']].filter(([id]) => $(id).checked).map(([, value]) => value).join(',');
  await chrome.storage.local.set({ liveosCommandCenterV1: { ...current, settings: { ...(current.settings || {}), autoReplyEnabled: $('autoRepliesEnabled').checked, autoReplyMinSec: Math.max(15, Math.min(300, Number($('autoRepliesMin').value) || 20)), autoReplyCategories: categories, autoHighlightEnabled: $('autoHighlightEnabled').checked, cameraWatchdogEnabled: $('cameraWatchdogEnabled').checked } } });
  await loadLiveAutomations();
  showToast('Respostas, destaques e watchdog salvos.');
}

async function saveVideoProfile() {
  const profile = $('videoProfile').value === 'low' ? 'low' : 'performance';
  const stored = await chrome.storage.local.get('liveosCommandCenterV1');
  const current = stored.liveosCommandCenterV1 || { version: 1 };
  const settings = { ...(current.settings || {}), captureProfile: profile, outputFps: 30, videoPipelineVersion: 4 };
  await chrome.storage.local.set({ liveosCommandCenterV1: { ...current, settings } });
  const response = await localControl('LIVEOS_CC_OUTPUT_CONFIG', { config: { frameMode: settings.videoFrameMode || 'fit', captureProfile: profile, safeScale: settings.safeScale || 1, outputFps: 30 } }).catch((error) => ({ ok: false, error: String(error) }));
  showToast(response?.ok ? `Perfil ${profile === 'low' ? 'PC fraco 540×960' : '720×1280'} aplicado a 30 FPS.` : response?.error || 'Perfil salvo na extensão; abra o LiveStudioCAM para sincronizar.', !response?.ok);
  void refreshLocalControls(false);
}

async function saveModeration() {
  const normalizeLines = (value) => [...new Set(value.split(/\r?\n|,/).map((line) => line.trim().toLocaleLowerCase('pt-BR')).filter(Boolean))];
  const keywords = normalizeLines($('competitorKeywords').value).map((item) => item.replace(/^@/, ''));
  const profiles = normalizeLines($('blockedProfiles').value).map((item) => item.replace(/^@/, ''));
  const config = { enabled: $('competitorBlockEnabled').checked, keywords, profiles, updatedAt: Date.now() };
  await chrome.storage.local.set({
    livewelModerationConfig: config,
    blockEnabled: false,
    blockKeywords: keywords,
    competitorKeywords: profiles
  });
  await loadLiveAutomations();
  showToast(config.enabled ? 'Bloqueio automático ativado.' : 'Bloqueio automático desativado.');
}

async function loadTelegram() {
  const response = await telegramRpc({ type: 'LIVEOS_TG_GET_CONFIG' }).catch((error) => ({ ok: false, error: String(error?.message || error) }));
  if (!response?.ok) {
    $('telegramStatus').textContent = 'Falha ao carregar';
    $('telegramDetail').textContent = response?.error || 'Tente novamente';
    setDot('telegramDot', 'offline');
    return;
  }
  const config = response.config || {};
  $('telegramEnabled').checked = config.enabled !== false;
  $('telegramChatId').value = config.chatId || '';
  $('telegramSales').checked = config.notifyDetected !== false;
  $('telegramSafety').checked = config.notifySafety !== false;
  $('telegramManual').checked = config.notifyManual !== false;
  $('telegramToken').placeholder = config.hasToken ? 'Token salvo — deixe vazio para manter' : 'Cole o token do @BotFather';
  $('telegramStatus').textContent = config.connected ? 'Telegram conectado e verificado' : config.ready ? 'Credenciais salvas · falta verificar' : 'Configuração pendente';
  $('telegramDetail').textContent = config.connected
    ? `${config.botUsername ? `@${config.botUsername} · ` : ''}Chat ${config.chatId}`
    : config.lastCheckError || (config.ready ? 'Clique em Verificar agora' : 'Informe o token e o Chat ID');
  $('telegramLastCheck').textContent = config.lastCheckAt
    ? `${config.connected ? 'Última verificação confirmada' : 'Última tentativa'}: ${new Date(config.lastCheckAt).toLocaleString('pt-BR')}${config.lastCheckError ? ` · ${config.lastCheckError}` : ''}`
    : 'Ainda não verificado com a API do Telegram.';
  setDot('telegramDot', config.connected ? 'online' : config.lastCheckError ? 'offline' : '');
}

async function saveTelegram() {
  const config = { enabled: $('telegramEnabled').checked, notifyDetected: $('telegramSales').checked, notifySafety: $('telegramSafety').checked, notifyManual: $('telegramManual').checked, botToken: $('telegramToken').value.trim(), chatId: $('telegramChatId').value.trim() };
  const response = await telegramRpc({ type: 'LIVEOS_TG_SAVE_CONFIG', config }).catch((error) => ({ ok: false, error: String(error?.message || error) }));
  if (!response?.ok) return showToast(response?.error || 'Não foi possível salvar o Telegram.', true);
  $('telegramToken').value = '';
  await loadTelegram();
  showToast('Conexão do Telegram salva.');
}

async function saveCycle() {
  const enabled = $('cycleEnabled').checked;
  const current = (await chrome.storage.local.get('livewelCycleConfig')).livewelCycleConfig || {};
  const config = { ...current, enabled, hours: Number($('cycleHours').value) || 0, minutes: Number($('cycleMinutes').value) || 0, products: $('cycleProducts').value.trim(), startedAt: enabled ? Date.now() : 0, lastStatus: enabled ? 'Ciclo programado.' : 'Desativado', lastError: '' };
  await chrome.storage.local.set({ livewelCycleConfig: config });
  await loadCycle();
  showToast('Programação salva.');
}

function updateCountdown() {
  chrome.storage.local.get('livewelCycleConfig').then(({ livewelCycleConfig: config }) => {
    if (!config?.enabled) {
      $('cycleCountdown').textContent = config?.pausedRemainingMs ? formatDuration(config.pausedRemainingMs / 1000) : '00:00:00';
      $('cycleStatus').textContent = config?.pausedRemainingMs ? 'Timer pausado.' : 'Desativado';
      return;
    }
    const duration = Math.max(60000, ((Number(config.hours) || 0) * 60 + (Number(config.minutes) || 0)) * 60000);
    const remaining = Math.max(0, Number(config.startedAt || Date.now()) + duration - Date.now());
    $('cycleCountdown').textContent = formatDuration(remaining / 1000);
    $('cycleStatus').textContent = config.lastStatus || 'Ciclo programado.';
  });
}

async function setQuickTimer(mode) {
  const stored = await chrome.storage.local.get('livewelCycleConfig');
  const current = stored.livewelCycleConfig || {};
  if (mode === 'cancel') {
    await chrome.storage.local.set({ livewelCycleConfig: { ...current, enabled: false, startedAt: 0, lastStatus: 'Desativado', lastError: '' } });
    return showToast('Timer cancelado.');
  }
  if (mode === 'pause') {
    const duration = Math.max(60000, ((Number(current.hours) || 0) * 60 + (Number(current.minutes) || 0)) * 60000);
    const remainingMs = Math.max(0, Number(current.startedAt || Date.now()) + duration - Date.now());
    await chrome.storage.local.set({ livewelCycleConfig: { ...current, enabled: false, pausedRemainingMs: remainingMs, lastStatus: 'Timer pausado.' } });
    return showToast('Timer pausado.');
  }
  const totalMinutes = Math.max(1, Number($('quickTimerMinutes').value) || 240);
  await chrome.storage.local.set({ livewelCycleConfig: { ...current, enabled: true, hours: Math.floor(totalMinutes / 60), minutes: totalMinutes % 60, startedAt: Date.now(), pausedRemainingMs: 0, lastStatus: 'Ciclo programado.', lastError: '' } });
  showToast(`Timer iniciado para ${totalMinutes} minutos.`);
}

document.querySelectorAll('.nav').forEach((item) => item.addEventListener('click', () => navigate(item.dataset.view)));
document.querySelectorAll('[data-go]').forEach((item) => item.addEventListener('click', () => navigate(item.dataset.go)));
$('refresh').addEventListener('click', () => refresh(true));
$('openDownloads').addEventListener('click', () => chrome.tabs.create({ url: 'https://tiktoksupremo.studiooryon.pro/live-studio' }));
$('openTikTok').addEventListener('click', () => chrome.tabs.create({ url: 'https://seller.tiktokglobalshop.com/' }));
$('popPlayer').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'LIVEOS_OPEN_PLAYER_WINDOW' }));
$('importProducts').addEventListener('click', async () => { const result = await command('import-products'); if (result?.ok) { snapshot = result; renderProducts(); showToast(`${result.products.length} produto(s) importado(s).`); } else showToast(result?.error || 'Não foi possível importar.', true); });
$('pinNow').addEventListener('click', async () => { const result = await command('pin-position', { position: $('pinPosition').value }); showToast(result?.ok ? `Posição ${result.position} fixada.` : result?.error || 'Produto não encontrado.', !result?.ok); });
$('productList').addEventListener('click', (event) => { const button = event.target.closest('[data-pin]'); if (button) { $('pinPosition').value = button.dataset.pin; $('pinNow').click(); } });
$('keepFirst').addEventListener('change', async (event) => { const result = await command('pin-first', { enabled: event.target.checked }); showToast(result?.ok ? (event.target.checked ? 'Produto 1 fixado sem repin ou rolagem periódica.' : 'Fixação do produto 1 desativada.') : result?.error, !result?.ok); });
$('clearQueue').addEventListener('click', async () => { if (!confirm('Limpar a fila de produtos do LiveWelPro?')) return; await command('clear-queue'); snapshot.products = []; state.playlist = []; renderProducts(); showToast('Fila limpa.'); });
$('audioInput').addEventListener('change', (event) => { uploadAudio([...event.target.files]).catch((error) => showToast(String(error), true)); event.target.value = ''; });
$('clearAudioQueue').addEventListener('click', () => { clearAudioQueue().catch((error) => showToast(String(error?.message || error), true)); });
$('audioList').addEventListener('click', async (event) => { const button = event.target.closest('[data-audio-remove]'); if (!button) return; await idbDeleteAudio(button.dataset.audioRemove); audioLibrary = audioLibrary.filter((item) => item.id !== button.dataset.audioRemove); await chrome.storage.local.set({ audioLibrary }); renderAudio(); });
$('audioPlay').addEventListener('click', () => audioCommand('PLAY'));
$('audioPause').addEventListener('click', () => audioCommand('PAUSE'));
$('audioNext').addEventListener('click', () => audioCommand('NEXT'));
$('audioVolume').addEventListener('input', (event) => { $('audioVolumeValue').textContent = `${event.target.value}%`; scheduleAudioConfig(); });
$('audioSpeed').addEventListener('input', (event) => { $('audioSpeedValue').textContent = `${(Number(event.target.value) / 100).toFixed(2).replace('.', ',')}×`; scheduleAudioConfig(); });
$('audioTone').addEventListener('input', (event) => { $('audioToneValue').textContent = audioToneLabel(event.target.value); scheduleAudioConfig(); });
$('audioAmbientEnabled').addEventListener('change', () => { $('audioAmbientLevel').disabled = !$('audioAmbientEnabled').checked; scheduleAudioConfig(); });
$('audioAmbientLevel').addEventListener('input', (event) => { $('audioAmbientValue').textContent = `${event.target.value}%`; scheduleAudioConfig(); });
$('audioMonitorEnabled').addEventListener('change', scheduleAudioConfig);
$('audioSegmentsEnabled').addEventListener('change', () => { $('audioSegmentSettings').hidden = !$('audioSegmentsEnabled').checked; scheduleAudioConfig(); });
for (const [rangeId, numberId, outputId] of [['audioSegmentMin', 'audioSegmentMinNumber', 'audioSegmentMinValue'], ['audioSegmentMax', 'audioSegmentMaxNumber', 'audioSegmentMaxValue'], ['audioGap', 'audioGapNumber', 'audioGapValue']]) {
  $(rangeId).addEventListener('input', () => syncRangeNumber(rangeId, numberId, outputId, rangeId));
  $(numberId).addEventListener('change', () => syncRangeNumber(rangeId, numberId, outputId, numberId));
}
$('saveCycle').addEventListener('click', saveCycle);
$('saveAutoComments').addEventListener('click', saveAutoComments);
$('testAutoComment').addEventListener('click', testAutoComment);
$('saveAutomationExtras').addEventListener('click', saveAutomationExtras);
$('saveModeration').addEventListener('click', saveModeration);
$('autoCommentsPreset').addEventListener('change', (event) => {
  const values = event.target.value === 'super_safe' ? [120, 300] : event.target.value === 'max_safety' ? [60, 120] : null;
  if (!values) return;
  $('autoCommentsMin').value = String(values[0]);
  $('autoCommentsMax').value = String(values[1]);
});
$('autoCommentsMin').addEventListener('input', () => { $('autoCommentsPreset').value = 'custom'; });
$('autoCommentsMax').addEventListener('input', () => { $('autoCommentsPreset').value = 'custom'; });
$('runCycle').addEventListener('click', async () => { await saveCycle(); const result = await command('run-cycle'); showToast(result?.ok ? 'Ciclo iniciado.' : result?.error || 'Não foi possível iniciar.', !result?.ok); });
$('reconnect').addEventListener('click', async () => { await chrome.storage.local.remove(['livewelReceiverVideoStatus', 'livewelReceiverAudioStatus']); showToast('Status limpo. Atualize a página da LIVE e selecione as fontes novamente.'); });
$('saveVideoProfile').addEventListener('click', saveVideoProfile);
$('restartCamera').addEventListener('click', async () => { const response = await localControl('LIVEOS_CC_CAMERA_RESTART').catch((error) => ({ ok: false, error: String(error) })); showToast(response?.ok ? 'Câmera virtual reiniciada.' : response?.error || 'Falha ao reiniciar a câmera.', !response?.ok); void refreshLocalControls(false); });
$('saveHighlight').addEventListener('click', async () => { const response = await localControl('LIVEOS_CC_HIGHLIGHT').catch((error) => ({ ok: false, error: String(error) })); showToast(response?.ok ? 'Destaque salvo pelo Replay Buffer do OBS.' : response?.error || 'Ative o Replay Buffer no OBS.', !response?.ok); });
$('switchObsScene').addEventListener('click', async () => { const scene = $('obsScene').value; if (!scene) return showToast('Nenhuma cena do OBS disponível.', true); const response = await localControl('LIVEOS_CC_OBS_SCENE', { scene }).catch((error) => ({ ok: false, error: String(error) })); showToast(response?.ok ? `Cena alterada: ${scene}` : response?.error || 'Falha ao trocar a cena.', !response?.ok); void refreshLocalControls(false); });
$('refreshTelemetry').addEventListener('click', () => void refreshLocalControls(true));
$('openRemotePanel').addEventListener('click', () => chrome.tabs.create({ url: 'http://127.0.0.1:18765/remote' }));
$('quickTimerStart').addEventListener('click', () => setQuickTimer('start'));
$('quickTimerPause').addEventListener('click', () => setQuickTimer('pause'));
$('quickTimerCancel').addEventListener('click', () => setQuickTimer('cancel'));
document.querySelectorAll('[data-timer-min]').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('[data-timer-min]').forEach((item) => item.classList.toggle('active', item === button));
  $('quickTimerMinutes').value = button.dataset.timerMin;
}));
$('telegramSave').addEventListener('click', saveTelegram);
$('telegramCheck').addEventListener('click', async () => { const response = await telegramRpc({ type: 'LIVEOS_TG_CHECK' }).catch((error) => ({ ok: false, error: String(error?.message || error) })); await loadTelegram(); showToast(response?.ok ? 'Bot e chat confirmados pela API do Telegram.' : response?.error || 'A verificação falhou.', !response?.ok); });
$('telegramFind').addEventListener('click', async () => { const response = await telegramRpc({ type: 'LIVEOS_TG_FIND_CHAT' }).catch((error) => ({ ok: false, error: String(error?.message || error) })); if (response?.ok) { await loadTelegram(); showToast(`Chat localizado: ${response.config?.chatName || response.config?.chatId}.`); } else showToast(response?.error || 'Envie uma mensagem ao bot e tente novamente.', true); });
$('telegramTest').addEventListener('click', async () => { const response = await telegramRpc({ type: 'LIVEOS_TG_TEST' }).catch((error) => ({ ok: false, error: String(error?.message || error) })); showToast(response?.ok ? 'Mensagem de teste enviada.' : response?.error || 'O teste falhou.', !response?.ok); });
chrome.storage.onChanged.addListener((changes, area) => { if (area !== 'local') return; const next = {}; for (const [key, value] of Object.entries(changes)) next[key] = value.newValue; renderState(next); if (changes.audioLibrary) { audioLibrary = changes.audioLibrary.newValue || []; renderAudio(); } else if (changes.audioPlayMode || changes.audioSegmentMinSec || changes.audioSegmentMaxSec || changes.audioGapSec) renderAudio(); if (changes.livewelCycleConfig) loadCycle(); if (changes.liveosCommandCenterV1 || changes.livewelModerationConfig || changes.livewelModerationLog || changes.livewelCommentPublishStatus || changes.livewelAutoReplyStatus || changes.livewelCameraWatchdogStatus || changes.livewelHighlightStatus) loadLiveAutomations(); });

await Promise.all([refresh(false), loadCycle(), loadTelegram(), loadLiveAutomations()]);
updateCountdown();
setInterval(updateCountdown, 1000);
setInterval(() => refresh(false), 5000);
